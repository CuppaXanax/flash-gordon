set -euo pipefail
cd '/home/xander/hc-mtp'; sha256sum -c native-q8.gguf.sha256; cd source; sha256sum -c release.sha256
