set -euo pipefail
test ! -e '/home/xander/hc-mtp'; mkdir -p '/home/xander/hc-mtp'; printf '%s\n' 'mtp-acceptance-20261016-retry' > '/home/xander/hc-mtp/lease.id'
