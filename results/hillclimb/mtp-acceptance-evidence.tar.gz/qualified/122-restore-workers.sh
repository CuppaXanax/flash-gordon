set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'mtp-acceptance-20261016-retry'; bash '/home/xander/hc-mtp/lease.sh' restore
