set -euo pipefail
bash '/home/xander/hc-mtp/source/tools/mtp-capture-offline.sh'
