set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'mtp-local-n4-20261016-1956'; bash '/home/xander/hc-mtp/lease.sh' start-serving A0 0 330 1 0 1 440
