set -euo pipefail
mkdir -p /home/xander/hc-mtp/transport
tar -xzf /home/xander/hc-mtp/transport-source.tar.gz -C /home/xander/hc-mtp/transport
cd /home/xander/hc-mtp/transport
gcc -std=c17 -O3 -Wall -Wextra -Werror -D_POSIX_C_SOURCE=200809L -Iinclude -ffunction-sections -fdata-sections -Wl,--gc-sections tools/bench_mtp_transport.c src/protocol.c src/util.c -lm -o bench
if [[ " $(hostname -I) " == *" 192.168.42.48 "* ]]; then
    timeout 90s ./bench server 192.168.42.48 26840
else
    timeout 90s ./bench client 192.168.42.48 26840 | tee /home/xander/hc-mtp/transport.jsonl
fi
