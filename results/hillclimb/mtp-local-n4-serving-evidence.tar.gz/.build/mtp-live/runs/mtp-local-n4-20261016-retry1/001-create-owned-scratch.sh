set -euo pipefail
test ! -e '/home/xander/hc-mtp'; mkdir -p '/home/xander/hc-mtp'; printf '%s\n' 'mtp-local-n4-20261016-retry1' > '/home/xander/hc-mtp/lease.id'
