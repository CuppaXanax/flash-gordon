set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'mtp-local-n4-20261016-retry1'; bash '/home/xander/hc-mtp/lease.sh' restore
