set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'mtp-local-n4-20261016-retry1'; bash '/home/xander/hc-mtp/lease.sh' start-serving F3 3 330 1 3 1 440
