import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path.cwd()
out = root / ".build" / "mtp-live"
out.mkdir(exist_ok=True)
def sha(data):
    return hashlib.sha256(data).hexdigest()
files = {}
with tarfile.open(root / ".build/mtp-local/evidence.tar.gz") as current:
    for member in current.getmembers():
        if member.isfile() and (member.name == "flash-gordon" or
                               member.name.startswith("vulkan/") and member.name.endswith(".spv")):
            files[member.name] = current.extractfile(member).read()
rebuilt = out / "rebuild-result.tar.gz"
if rebuilt.exists():
    with tarfile.open(rebuilt) as archive:
        files["flash-gordon"] = archive.extractfile("flash-gordon").read()
with tarfile.open(root / ".build/mtp-serving-perf-lease/release.tar.gz") as prior:
    files["tools/mtp-embedding"] = prior.extractfile("tools/mtp-embedding").read()
    shaders = {m.name: prior.extractfile(m).read() for m in prior.getmembers()
               if m.isfile() and m.name.endswith(".spv")}
    changed = [n for n, b in shaders.items() if files.get(n) != b]
    print("Changed shaders since prior qualified release:", changed)
files["release.sha256"] = "".join(f"{sha(b)}  {n}\n" for n,b in sorted(files.items())).encode()
with tarfile.open(out / "release.tar.gz", "w:gz") as archive:
    for name, data in files.items():
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = 0o755 if name in ("flash-gordon", "tools/mtp-embedding") else 0o644
        archive.addfile(member, io.BytesIO(data))
release_sha = sha((out / "release.tar.gz").read_bytes())
audit_path = root / ".build/mtp-serving-perf-lease/format-audit.json"
audit = json.loads(audit_path.read_text())
audit["candidate_release_sha256"] = release_sha
audit["current_rebinding"] = dict(
    prior_audit_sha256=sha(audit_path.read_bytes()),
    current_binary_sha256=sha(files["flash-gordon"]),
    compiled_main_source_parent="bc75b750995e9302d309161799541da10b6bcd4c",
    runtime_source_sha256=sha((root/"src/runtime.c").read_bytes().replace(b"\r\n",b"\n")),
    rebuild_archive_sha256=sha(rebuilt.read_bytes()) if rebuilt.exists() else None,
    changed_prior_shaders=changed,
    new_shaders=sorted(set(files)-set(shaders)-{"flash-gordon","tools/mtp-embedding","release.sha256"}),
    new_format_or_quantization=False,
    current_real_native_head_draft_checks=33960,
    current_full_shape_state_fixtures=24,
    new_full_model_quality_claim=False,
    prior_format_gates_inherited=True)
(out / "format-audit.json").write_text(json.dumps(audit, indent=2)+"\n")
prepared = dict(base="bc75b750995e9302d309161799541da10b6bcd4c",
    releaseSha256=release_sha,
    formatAuditSha256=sha((out / "format-audit.json").read_bytes()),
    binarySha256=sha(files["flash-gordon"]), diagnosticOnly=True)
(out / "prepared.json").write_text(json.dumps(prepared, indent=2)+"\n")
head = out / "head.q8"
if not head.exists():
    with tarfile.open(root / ".build/mtp-lease/runs/mtp-acceptance-20261016-retry/baseline-0.tar") as archive:
        with archive.extractfile("head.q8") as source, head.open("wb") as target:
            import shutil
            shutil.copyfileobj(source, target)
assert sha(head.read_bytes()) == "2801d79db74bcae38b47fd5051f03136d8ca7715abeba7d92b49ba46c696bc33"
with tarfile.open(out / "transport-source.tar.gz", "w:gz") as archive:
    for path in sorted((root / "include").glob("*.h")):
        archive.add(path, arcname="include/"+path.name)
    for name in ("tools/bench_mtp_transport.c", "src/protocol.c", "src/util.c"):
        archive.add(root / name, arcname=name)
print(json.dumps(prepared, indent=2))
