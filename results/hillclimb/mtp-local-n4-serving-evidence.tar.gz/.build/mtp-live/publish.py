import hashlib
import json
from pathlib import Path
import tarfile

root = Path(".build") / "mtp-live"
results = Path("results") / "hillclimb"
names = [
    "Makefile", "src/runtime.c", "docs/FLAGS.md", "docs/MTP.md",
    "docs/MTP_TO_PROD.md", "tools/Invoke-MTPServingQualification.ps1",
    "tools/mtp-lease-guard.sh", "tools/mtp_serving_qualify.py",
    "tools/check-flags.sh", "tools/bench_mtp_transport.c",
    "tools/mtp_live_analyze.py", "tests/test_mtp_live_analyze.py",
    "tests/test_mtp_serving_qualify.py",
]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
release = json.loads((root / "release-verified.json").read_text(encoding="utf-8-sig"))
assert len(release) == 8 and all(r["ExitCode"] == 0 for r in release)
assert all("RELEASE_VERIFIED" in r["Stdout"] for r in release)
for name in ("mtp-local-n4-20261016-1956", "mtp-local-n4-20261016-retry1"):
    run = root / "runs" / name
    outcome = json.loads((run / "outcome.json").read_text(encoding="utf-8-sig"))
    assert outcome["productionVerified"] and outcome["scratchRemoved"]
    assert not outcome["complete"] and not outcome["finalizationErrors"]
prepared = json.loads((root / "prepared.json").read_text())
with tarfile.open(root / "rebuild-result.tar.gz") as archive:
    assert hashlib.sha256(archive.extractfile("flash-gordon").read()).hexdigest() == prepared["binarySha256"]

report_path = results / "mtp-local-n4-serving.json"
report = json.loads(report_path.read_text())
report["lease"] = dict(granted="2026-10-16T19:56:06Z",
    absolute_deadline="2026-10-16T20:41:06Z", released_verified="2026-10-16T20:23:07Z",
    final_verification_sha256=sha(root / "release-verified.json"))
report["binary_sha256"] = prepared["binarySha256"]
report["audit_source_sha256"] = sha(Path(r"D:\looking-glass-labs\flash-gordon\results\hillclimb\STRATA_AUDIT.md"))
report_path.write_text(json.dumps(report, indent=2) + "\n")
inputs = [Path(n) for n in names]
inputs += [results / "MTP_LOCAL_N4_SERVING.md", report_path]
inputs += [p for p in (root / "runs").rglob("*")
           if p.is_file() and p.suffix in {".json", ".log", ".gz", ".sh", ".stderr", ".stdout"}]
inputs += [root / n for n in (
    "prepare.py", "publish.py", "prepared.json", "format-audit.json",
    "attempt1-prepared.json", "attempt1-format-audit.json",
    "release.tar.gz", "attempt1-release.tar.gz", "transport-source.tar.gz",
    "rebuild.tar.gz", "rebuild-result.tar.gz", "rebuild-receipt.json",
    "cleanup-51.json", "release-verify.sh", "release-verified.json",
    "final-tests.log", "analyzer-tests.log", "disk-check.json")]
assert all(p.exists() for p in inputs)
archive_path = results / "mtp-local-n4-serving-evidence.tar.gz"
with tarfile.open(archive_path, "w:gz") as archive:
    for p in sorted(set(inputs)):
        assert p.suffix not in {".fgw", ".fgme", ".gguf", ".q8", ".iq4nl"}
        archive.add(p, arcname=str(p), recursive=False)
publication = dict(base=prepared["base"], binary_sha256=prepared["binarySha256"],
    scope="Incomplete diagnostic, no promotion; both failures preserved",
    archive_sha256=sha(archive_path), archive_bytes=archive_path.stat().st_size,
    report_sha256=sha(report_path), source_inputs_sha256={n:sha(n) for n in names},
    release=report["lease"], audit_source_sha256=report["audit_source_sha256"],
    validation="27 targeted Python tests; C17-Werror build, flags gate and bounded TCP-double fixture")
(results / "mtp-local-n4-publication.json").write_text(json.dumps(publication, indent=2) + "\n")
print(json.dumps(publication, indent=2))
