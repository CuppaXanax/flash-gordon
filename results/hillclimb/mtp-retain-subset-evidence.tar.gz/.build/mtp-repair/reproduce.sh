set -eu
cd /home/xander/hc-mtp/repair
mkdir -p source
tar -xzf ../source.tar.gz -C source
cd source
mkdir -p .build
make -j12 tools/bench-decode-fusion > ../before-build.log 2>&1
export FG_EXPERT_Q8_WIDE=1 FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3
export FG_ROOF_EXPERT=33024 FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1
export FG_DECODE_SUBMIT_GROUP=2 FG_SMALL_KERNELS=330
set +e
sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c 'ulimit -l unlimited; exec ./tools/bench-decode-fusion --q4 --mixed-experts --coordinator-state-test --no-clocks' > ../before.jsonl 2> ../before.log
status=$?
set -e
[[ "$status" == 1 ]]
grep -F 'MTP retained QSA frontier mismatch' ../before.log
printf 'REPRODUCED_COORDINATOR_RETAIN_FAILURE status=%s\n' "$status"
tar -czf ../before-evidence.tar.gz ../before-build.log ../before.jsonl ../before.log tools/bench-decode-fusion
