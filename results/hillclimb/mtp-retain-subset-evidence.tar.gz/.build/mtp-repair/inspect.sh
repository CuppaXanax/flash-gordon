set -eu
cd /home/xander/hc-mtp/repair
for name in cold-before-build.log cold-before.log cold-before.jsonl cold-after-build.log cold-after.log cold-after.jsonl head-bench.log head-bench.jsonl; do
    if [[ -f "$name" ]]; then echo "$name"; tail -n 8 "$name"; fi
done
df -B1 .
