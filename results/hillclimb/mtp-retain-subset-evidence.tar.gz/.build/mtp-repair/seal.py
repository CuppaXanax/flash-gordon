import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path.cwd()
out = root / ".build" / "mtp-repair"
sha = lambda data: hashlib.sha256(data).hexdigest()
file_sha = lambda p: hashlib.file_digest(Path(p).open("rb"), "sha256").hexdigest()
expected = {
    "after-evidence.tar.gz": "e3dec5155f3dd2a9a813c0049cff5b268d0a09cf49094a2fe85123b19dd4abc3",
    "head-evidence.tar.gz": "51c7476618c0fe37f3866243785403299f0619918dda9c10e359d6ef56e13f64",
    "final-evidence.tar.gz": "2491672dc08eea6e165991952d6a0a0d85d611949a8dc1537a8b35bb2617f091",
}
for name, digest in expected.items():
    assert file_sha(out / name) == digest
with tarfile.open(out / "final-evidence.tar.gz") as t:
    binary = t.extractfile("source/flash-gordon").read()
    states = [json.loads(line) for line in t.extractfile("final-state.jsonl")
              if b'"kind":"state_commit_test"' in line]
    assert len(states) == 24
    assert all(all(r[k] for k in ("hc_untouched", "stale_rejected",
        "rollback_exact", "journal_full_state_exact", "static_replay_retained",
        "tolerance_ok")) for r in states)
    for native in (6, 7):
        for reject in range(4):
            log = t.extractfile(f"final-ring-{native}-{reject}.log").read()
            assert b"PASS" in log
with tarfile.open(out / "head-evidence.tar.gz") as t:
    assert b"MTP retained QSA frontier mismatch" in t.extractfile("cold-before.log").read()
    head = [json.loads(line) for line in t.extractfile("head-bench.jsonl")]
    assert sha(t.extractfile("source/flash-gordon").read()) == sha(binary)
compiled_sources = {}
with tarfile.open(out / "source.tar.gz") as t:
    for member in t.getmembers():
        if member.isfile() and member.name.startswith(("src/", "include/")):
            contents = t.extractfile(member).read()
            assert contents == (root / member.name).read_bytes().replace(b"\r\n", b"\n")
            compiled_sources[member.name] = sha(contents)
files = {}
with tarfile.open(root / ".build" / "mtp-live" / "release.tar.gz") as t:
    for member in t.getmembers():
        if member.isfile() and member.name != "release.sha256":
            files[member.name] = t.extractfile(member).read()
files["flash-gordon"] = binary
files["release.sha256"] = "".join(f"{sha(b)}  {n}\n"
    for n, b in sorted(files.items())).encode()
with tarfile.open(out / "release.tar.gz", "w:gz") as t:
    for name, data in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = 0o755 if name in ("flash-gordon", "tools/mtp-embedding") else 0o644
        t.addfile(member, io.BytesIO(data))
prior_audit = root / ".build" / "mtp-live" / "format-audit.json"
audit = json.loads(prior_audit.read_text())
release_sha = file_sha(out / "release.tar.gz")
audit["candidate_release_sha256"] = release_sha
audit["current_rebinding"] = dict(
    prior_audit_sha256=file_sha(prior_audit),
    current_binary_sha256=sha(binary),
    compiled_source_parent=subprocess.check_output(
        ["git", "rev-parse", "HEAD"], text=True).strip(),
    source_archive_sha256=file_sha(out / "source.tar.gz"),
    compiled_sources_sha256=compiled_sources,
    changed_prior_shaders=[],
    new_draft_container_format="FGDVOC1", candidate_uses_draft_subset=False,
    new_weight_quantization=False, target_kernels_unchanged=True,
    current_coordinator_state_fixtures=24, current_tcp_cases=8,
    current_real_head_synthetic_vectors_per_shape=8,
    prior_native_draft_checks=33960, prior_format_gates_inherited=True,
    no_new_acceptance_or_full_model_quality_claim=True)
(out / "format-audit.json").write_text(json.dumps(audit, indent=2) + "\n")
prepared = dict(base=audit["current_rebinding"]["compiled_source_parent"],
    releaseSha256=release_sha, formatAuditSha256=file_sha(out / "format-audit.json"),
    binarySha256=sha(binary), diagnosticOnly=True)
(out / "prepared.json").write_text(json.dumps(prepared, indent=2) + "\n")
assert file_sha(out / "head.q8") == "2801d79db74bcae38b47fd5051f03136d8ca7715abeba7d92b49ba46c696bc33"
assert file_sha(root / ".build" / "mtp-lease" / "native-q8.gguf") == "536bab54b0a1bdea23b65871c4cdc38deee5803771501a0c770a0510bcd3283b"
summary = dict(evidence=expected, prepared=prepared, head_measurements=head,
    coordinator_cases=24, tcp_cases=8,
    max_abs_state=max(r["max_abs_state"] for r in states),
    max_abs_continuation=max(r["max_abs_continuation"] for r in states))
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
