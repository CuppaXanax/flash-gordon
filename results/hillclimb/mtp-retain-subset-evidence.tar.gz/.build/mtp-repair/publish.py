import hashlib
import json
from pathlib import Path
import shutil
import tarfile

out = Path(".build") / "mtp-repair"
results = Path("results") / "hillclimb"
sha = lambda p: hashlib.file_digest(Path(p).open("rb"), "sha256").hexdigest()
read = lambda name: json.loads((out / name).read_text(encoding="utf-8-sig"))
summary = read("summary.json")
cleanup = read("cleanup-receipt2.json")
assert cleanup["ExitCode"] == 0 and "root_absent_twice=1" in cleanup["Stdout"]
assert "test_ports_closed=1" in cleanup["Stdout"]
assert "Ran 29 tests" in (out / "python-tests.log").read_text()
report = dict(
    scope="Offline .51 only, default off, no promotion, no active production lease",
    availability="Authentic MTP/full-Q8 head available; FGDVOC1 subset now implemented",
    source_parent=summary["prepared"]["base"],
    retain_reproduction=dict(error="MTP retained QSA frontier mismatch",
        executor="replicated coordinator", prefix=22, first_verify_columns=4,
        warmup_columns=1, fixed_scope="journal.first_layer..last_layer"),
    validation=dict(python_tests=29, coordinator_gpu_cases=24, tcp_cases=8,
        strict_c17_werror=True, environment_registry=True,
        mapped_vocab_replay=True, wrong_parent_rejected=True,
        duplicate_ids_rejected=True, unselected_corruption_rejected=True,
        truncation_rejected=True,
        max_abs_state=summary["max_abs_state"],
        max_abs_continuation=summary["max_abs_continuation"]),
    measurements=summary["head_measurements"],
    measurement_scope=dict(blade="192.168.42.51", reported_cus=24,
        warmups=8, timings_per_shape=100, synthetic_hidden_vectors=8,
        subset_ids="Contiguous low IDs, not curated/language/acceptance qualified",
        three_head_saving="Proxy only, not measured full-chain or round savings"),
    transport=dict(prior_measured_n4_pair_to_ring_model_ms=14.2156938796,
        optional_fp16_scale_model_ms=7.1, optional_saving_ms=7.1156938796,
        conditional=True, requires="sol-roofline quality plus actual N4 codec/framing",
        older_allhop_relative_kl=0.00987737,
        older_allhop_relative_top1=0.9875, older_allhop_pass=False,
        destination_mask224_relative_kl=0.000678952,
        destination_mask224_relative_top1=1.0,
        destination_mask224_is_not_n4_or_original_q8_qualification=True),
    projected=dict(unchanged_offline_round_ms=95.789182,
        code_yield_offline=3.240506, chat_yield_offline=2.392523,
        measured_new_on_tps=None, measured_subset_acceptance=None,
        complete_dual_session_fit=False),
    prepared=summary["prepared"], offline_evidence=summary["evidence"],
    cleanup=cleanup,
    next_lease=dict(request_only=True, active=False, minutes=45,
        work_minutes=30, profile="SingleSessionPerf", arms=["A0","F3","A1"],
        sessions=1, mask=330, draft=3, worker_qsa_mib=440,
        full_head_first=True, typed_subset_controller_support=False,
        restore="Exact pinned current sessions2/wide1, no promotion"),
    pending=["Authentic full-ring retain confirmation and completed warm ledger",
        "Paired on/off chat/code TPS and actual yield",
        "Same-geometry original-Q8/N4 quality and full serving receipts",
        "Curated subset IDs, language/tool coverage and acceptance",
        "Explicit typed-subset controller staging; complete dual-session peaks"])
report_path = results / "mtp-retain-subset.json"
report_path.write_text(json.dumps(report, indent=2) + "\n")
paths = [p for p in out.iterdir() if p.is_file() and (
    p.suffix in {".py", ".sh", ".json", ".log"} or
    p.name in {"source.tar.gz", "release.tar.gz", *summary["evidence"]})]
source_names = ["Makefile", "docs/MTP.md", "docs/MTP_TO_PROD.md",
    "include/fg_mtp_head.h", "src/owner.c", "src/mtp_head.c", "src/mtp_native.c",
    "src/main.c", "tests/test_mtp_vocab.c", "tests/test_mtp_vocab_pack.py",
    "tests/test_mtp_native.c", "tests/test_mtp_ring.c",
    "tools/bench_decode_fusion.c", "tools/bench_mtp_vocab.c",
    "tools/mtp_vocab_pack.py"]
paths += [Path(n) for n in source_names]
paths += [results / "MTP_RETAIN_SUBSET.md", report_path]
archive_path = results / "mtp-retain-subset-evidence.tar.gz"
assert not archive_path.exists()
with tarfile.open(archive_path, "w:gz") as t:
    for path in sorted(set(paths)):
        assert path.suffix not in {".fgw", ".gguf", ".q8", ".fgdv", ".fgme"}
        t.add(path, arcname=str(path), recursive=False)
publication = dict(source_parent=report["source_parent"],
    binary_sha256=summary["prepared"]["binarySha256"],
    diagnostic_release_sha256=summary["prepared"]["releaseSha256"],
    report_sha256=sha(report_path),
    archive_sha256=sha(archive_path), archive_bytes=archive_path.stat().st_size,
    source_sha256={n: sha(n) for n in source_names},
    validation=report["validation"], cleanup_sha256=sha(out / "cleanup-receipt2.json"))
publication_path = results / "mtp-retain-subset-publication.json"
publication_path.write_text(json.dumps(publication, indent=2) + "\n")
canonical = Path(r"D:\looking-glass-labs\flash-gordon\results\hillclimb")
copies = {}
for path in (results / "MTP_RETAIN_SUBSET.md", report_path, archive_path, publication_path):
    destination = canonical / path.name
    assert not destination.exists()
    shutil.copyfile(path, destination)
    assert sha(path) == sha(destination)
    copies[path.name] = sha(path)
(out / "canonical-publication.json").write_text(json.dumps(copies, indent=2) + "\n")
print(json.dumps(publication, indent=2))
