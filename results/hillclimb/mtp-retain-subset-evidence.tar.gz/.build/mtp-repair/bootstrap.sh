set -eu
root=/home/xander/hc-mtp
[[ ! -d "$root/build" && ! -d "$root/repair" ]]
mkdir -p "$root/repair"
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > "$root/repair/governor.sha256"
printf 'OFFLINE_REPAIR_RESERVED_51\n'
