set -eu
cd /home/xander/hc-mtp/repair
tar -xzf ../source.tar.gz -C source
cd source
find src include tools tests -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' \) -exec touch {} +
make -j12 flash-gordon tools/bench-decode-fusion tests/test_mtp_vocab tests/test_mtp_native tests/test_mtp_ring tests/test_mtp > ../after-build.log 2>&1
bash tools/check-flags.sh > ../flags.log
./tests/test_mtp_native > ../native.log 2>&1
./tests/test_mtp > ../cycle.log 2>&1
./tests/test_mtp_vocab > ../vocab.jsonl 2> ../vocab.log
export FG_EXPERT_Q8_WIDE=1 FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3
export FG_ROOF_EXPERT=33024 FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1
export FG_DECODE_SUBMIT_GROUP=2 FG_SMALL_KERNELS=330
sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c 'ulimit -l unlimited; exec ./tools/bench-decode-fusion --q4 --mixed-experts --coordinator-state-test --no-clocks' > ../after.jsonl 2> ../after.log
for native in 7 6; do
    for reject in 0 1 2 3; do
        FG_DECODE_MS=1 ./tests/test_mtp_ring 127.0.0.1 127.0.0.1 "$((18100+reject*20+(7-native)*100))" "$reject" 2 "$native" 1 > "../ring-$native-$reject.log" 2>&1
    done
done
sha256sum flash-gordon > ../binary.sha256
cd ..
tar -czf after-evidence.tar.gz before-evidence.tar.gz before-build.log before.jsonl before.log after-build.log after.jsonl after.log vocab.jsonl vocab.log native.log cycle.log flags.log ring-*.log binary.sha256 source/flash-gordon
tail -n 1 after.jsonl
cat vocab.jsonl
sha256sum after-evidence.tar.gz
