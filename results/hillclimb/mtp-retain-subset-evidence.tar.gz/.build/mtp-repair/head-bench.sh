set -eu
cd /home/xander/hc-mtp/repair
if [[ -f cold-after.log && ! -d head-attempt1 ]]; then
    mkdir head-attempt1
    cp cold-* head-attempt1/
fi
tar -xzf ../source.tar.gz -C source
cd source
cp src/owner.c ../owner-fixed.c
cp _regression/owner-before.c src/owner.c
touch tools/bench_decode_fusion.c
make -j12 tools/bench-decode-fusion > ../cold-before-build.log 2>&1
export FG_EXPERT_Q8_WIDE=1 FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3
export FG_ROOF_EXPERT=33024 FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1
export FG_DECODE_SUBMIT_GROUP=2 FG_SMALL_KERNELS=330
set +e
sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c 'ulimit -l unlimited; exec ./tools/bench-decode-fusion --q4 --mixed-experts --coordinator-state-test --no-clocks' > ../cold-before.jsonl 2> ../cold-before.log
status=$?
set -e
[[ "$status" == 1 ]]
grep -F 'MTP retained QSA frontier mismatch' ../cold-before.log
cp ../owner-fixed.c src/owner.c
touch tools/bench_mtp_vocab.c
make -j12 flash-gordon tools/bench-decode-fusion tools/bench-mtp-vocab > ../cold-after-build.log 2>&1
sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c 'ulimit -l unlimited; exec ./tools/bench-decode-fusion --q4 --mixed-experts --coordinator-state-test --no-clocks' > ../cold-after.jsonl 2> ../cold-after.log
./tools/bench-mtp-vocab ../manifest.fgm ../head.q8 > ../head-bench.jsonl 2> ../head-bench.log
sha256sum flash-gordon > ../binary.sha256
cd ..
tar -czf head-evidence.tar.gz cold-before-build.log cold-before.jsonl cold-before.log cold-after-build.log cold-after.jsonl cold-after.log head-bench.jsonl head-bench.log binary.sha256 source/flash-gordon source/tools/bench-mtp-vocab head-attempt1
tail -n 1 cold-after.jsonl
cat head-bench.jsonl
sha256sum head-evidence.tar.gz
