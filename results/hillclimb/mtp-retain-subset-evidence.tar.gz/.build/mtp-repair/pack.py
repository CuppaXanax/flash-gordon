import io
from pathlib import Path
import subprocess
import tarfile

root = Path.cwd()
names = subprocess.check_output(["git","ls-files","--cached","--others","--exclude-standard","-z"]).decode().split("\0")
with tarfile.open(root / ".build" / "mtp-repair" / "source.tar.gz", "w:gz") as target:
    for name in names:
        if not name or name.startswith(("results/",".github/",".claude/")):
            continue
        p=root / name
        if not p.is_file(): continue
        raw=p.read_bytes()
        if b"\0" not in raw: raw=raw.replace(b"\r\n",b"\n")
        m=tarfile.TarInfo(name);m.size=len(raw)
        m.mode=0o755 if name=="glslc" or name.endswith(".sh") else 0o644
        target.addfile(m,io.BytesIO(raw))
    with tarfile.open(root / ".build" / "mtp-live" / "release.tar.gz") as previous:
        for m in previous:
            if m.isfile() and m.name.startswith("vulkan/") and m.name.endswith(".spv"):
                target.addfile(m,previous.extractfile(m))
    old=root / ".build" / "mtp-repair" / "owner-before.c"
    if old.exists():
        raw=old.read_bytes();m=tarfile.TarInfo("_regression/owner-before.c");m.size=len(raw)
        target.addfile(m,io.BytesIO(raw))
