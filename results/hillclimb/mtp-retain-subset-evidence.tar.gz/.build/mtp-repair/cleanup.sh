set -eu
root=/home/xander/hc-mtp
cd "$root/repair"
if [[ -s governor.sha256 ]]; then
    sha256sum -c governor.sha256 --quiet
    cat governor.sha256
else
    [[ -z "$(find /sys/devices/system/cpu/cpufreq -name scaling_governor -print -quit)" ]]
    echo 'GOVERNOR_BASELINE_EMPTY_AND_STILL_NO_EXPOSED_GOVERNORS'
fi
for exe in /proc/[0-9]*/exe; do
    path=$(readlink "$exe" 2>/dev/null || true)
    if [[ "$path" == "$root/repair/"* ]]; then
        echo "OWNED_PROCESS_STILL_RUNNING:$exe:$path"
        exit 1
    fi
done
for base in 18100 18120 18140 18160 18200 18220 18240 18260; do
    for offset in 0 1 2 3 4 5 6 7; do
        [[ -z "$(ss -Hlnt "sport = $((base+offset))")" ]]
    done
done
for path in "$root"/* "$root"/.[!.]*; do
    [[ -e "$path" ]] || continue
    name=${path##*/}
    case "$name" in repair|source.tar.gz|.fleet-*.sh) ;; *) echo "UNEXPECTED_ROOT_ENTRY:$name"; exit 1 ;; esac
done
cd /home/xander
rm -rf -- "$root"
[[ ! -e "$root" ]]
sleep 1
[[ ! -e "$root" ]]
printf 'OFFLINE_51_RELEASED %s root_absent_twice=1 owned_processes=0 test_ports_closed=1 governors_unchanged=1\n' "$(date -u +%FT%TZ)"
