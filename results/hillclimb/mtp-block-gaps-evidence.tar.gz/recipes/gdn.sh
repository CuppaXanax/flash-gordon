set -eu
cd /home/xander/hc-mtp/block
tar -xzf update.tar.gz -C source
cd source
find src include tools -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' \) -exec touch {} +
touch shaders/fg_small_gate_up.glsl shaders/fg_small_reuse_rows.glsl shaders/fg_gdn_small_cached.comp
make -j12 tools/bench-decode-fusion > ../gdn-build.log 2>&1
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
run(){
    sudo -n --preserve-env=RADV_DEBUG,MESA_SHADER_CACHE_DISABLE,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
for mask in 330 65866; do
    export FG_SMALL_KERNELS="$mask"
    run --q4 --mixed-experts --small-test --allow-reassociation --no-clocks > "../gdn-oracle-$mask.jsonl" 2> "../gdn-oracle-$mask.log"
done
for round in 1 2 3; do
    for mask in 330 65866 330; do
        export FG_SMALL_KERNELS="$mask"
        stamp="$(date +%s%N)"
        run --q4 --mixed-experts --small-n --batch 4 --warmup 66 --iterations 54 --windows 1 --allow-reassociation --no-clocks > "../gdn-cost-$round-$mask-$stamp.jsonl" 2> "../gdn-cost-$round-$mask-$stamp.log"
    done
done
for mask in 328 330 65866 8522 33098 16714; do
    export FG_SMALL_KERNELS="$mask" RADV_DEBUG=shaderstats MESA_SHADER_CACHE_DISABLE=true
    run --q4 --mixed-experts --small-n --batch 4 --warmup 0 --iterations 1 --windows 1 --allow-reassociation --no-clocks > "../isa-$mask.jsonl" 2> "../isa-$mask.log"
done
unset RADV_DEBUG MESA_SHADER_CACHE_DISABLE
for mask in 330 65866; do
    export FG_SMALL_KERNELS="$mask"
    run --q4 --mixed-experts --small-n --batch 4 --warmup 66 --iterations 1 --windows 1 --profile --allow-reassociation --no-clocks > "../gdn-profile-$mask.jsonl" 2> "../gdn-profile-$mask.log"
done
cd ..
tar -czf gdn-evidence.tar.gz gdn-build.log gdn-oracle-* gdn-cost-* isa-* gdn-profile-*
printf 'GDN_PARTITION_AND_ISA_COMPLETE\n'
