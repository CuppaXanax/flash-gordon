set -eu
cd /home/xander/hc-mtp/block
export TMPDIR="$PWD/source-final/.build/scratch"
test -f authentic-preparation.tar.gz
tar -xf hc-update.tar -C source-final
touch source-final/src/vk.c
make -C source-final -j12 flash-gordon tools/bench-decode-fusion tools/mtp-residency tests/test_fg_vk > authentic-final-build.log 2>&1
(cd source-final && sha256sum flash-gordon tools/bench-decode-fusion tools/mtp-residency tests/test_fg_vk) > final-binaries.sha256
export FG_SHADER_DIR="$PWD/source-final/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_NGRAM_LOCAL_CACHE=1
export FG_DECODE_SUBMIT_GROUP=2 FG_QSA_WORKER_CACHE_MIB=128
export XDG_CACHE_HOME="$PWD/source-final/.build/cache"
run(){
    sudo -n --preserve-env=XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_NGRAM_LOCAL_CACHE,FG_DECODE_SUBMIT_GROUP,FG_QSA_WORKER_CACHE_MIB bash -c \
        'ulimit -l unlimited; exec source-final/tools/mtp-residency real-rank7/manifest.fgm native-q8.gguf real-rank7/embedding.fgme "$1" --local-head head.q8 --verify-bench' bash "$1"
}
export FG_SMALL_KERNELS=393546
FG_TEST_Q8_DOWN_TENSOR="$PWD/authentic-q8-down.bin" DS4_REMOTE_TEST_FILTER=small_q8_down_union \
    source-final/tests/test_fg_vk > authentic-final-q8-oracle.jsonl 2> authentic-final-q8-oracle.log
cd source-final
sudo -n --preserve-env=FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
    'ulimit -l unlimited; exec ./tools/bench-decode-fusion --q4 --mixed-experts --small-test --allow-reassociation --no-clocks' > ../hc-block-oracle.jsonl 2> ../hc-block-oracle.log
cd ..
for round in 1 2 3; do
    for mask in 330 131402 393546 330; do
        export FG_SMALL_KERNELS="$mask"
        rm -f real-rank7/residency-qsa-s0.state real-rank7/residency-qsa-s1.state
        stamp="$(date +%s%N)"
        run 2 > "authentic-cost-$round-$mask-$stamp.jsonl" 2> "authentic-cost-$round-$mask-$stamp.log"
    done
done
cd source-final
RADV_DEBUG=shaderstats MESA_SHADER_CACHE_DISABLE=true \
    DS4_REMOTE_TEST_FILTER=small_q8_down_union ./tests/test_fg_vk > ../final-q8-isa.jsonl 2> ../final-q8-isa.log
cd ..
tar -czf authentic-evidence.tar.gz authentic-cost-* authentic-final-q8-oracle.* final-q8-isa.* final-binaries.sha256 authentic-final-build.log hc-block-oracle.*
printf 'FULL_HEAD_TWO_SESSION_AUTHENTIC_BRACKETS_COMPLETE\n'
