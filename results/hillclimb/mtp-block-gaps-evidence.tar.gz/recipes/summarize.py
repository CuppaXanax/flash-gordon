import hashlib
import json
import re
import statistics
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tools"))
from analyze_mtp_block import compare, read_profile


def text(archive, name):
    with tarfile.open(HERE / archive) as bundle:
        return bundle.extractfile(name).read().decode()


def names(archive):
    with tarfile.open(HERE / archive) as bundle:
        return bundle.getnames()


def rows(archive, name):
    return [json.loads(line) for line in text(archive, name).splitlines()
            if line.startswith("{")]


def evidence():
    return {p.name: {"bytes": p.stat().st_size,
                     "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in HERE.glob("*evidence.tar.gz")}


def replay(archive, name):
    data = rows(archive, name)
    times = [r["wall_us"] for r in data if r.get("kind") == "sample"]
    if not times:
        samples = [r for r in data if "sample" in r]
        raise ValueError((name, samples[:1], data[:2]))
    return {"median_us": statistics.median(times), "samples": len(times),
            "config": next(r for r in data if r.get("kind") == "config")}


def components(archive, name):
    data = re.findall(
        r"SMALL_Q8_DOWN_UNION source=(\w+) pattern=(\d+) n=(\d+) "
        r"bit_exact=(\d+) cpu_basis_max_rel=(\S+) native_max_rel=(\S+)",
        text(archive, name))
    if len(data) != 9:
        raise ValueError((archive, name, len(data)))
    return {"cases": len(data), "source": data[0][0],
            "max_native_normalized_error": max(float(r[5]) for r in data),
            "max_cpu_basis_normalized_error": max(float(r[4]) for r in data),
            "bound": 0.0001, "bit_exact": all(r[3] == "1" for r in data)}


def main():
    n1, p1 = read_profile(HERE / "scoped-profile-330-1.jsonl")
    n4, p4 = read_profile(HERE / "scoped-profile-330-4.jsonl", small=True)
    report = {"schema": "flash-gordon.mtp-block-gaps.v1",
              "baseline_commit": "06e71c2e45ad3b87448df3205d1e310c1fe239c0",
              "host": "192.168.42.51",
              "production_access": False, "clocks_changed": False,
              "reported_cus": 24,
              "flags": {"FG_ROOFLINE": 2047, "FG_ROOF_DENSE": 19,
                        "FG_ROOF_QSA": 3, "FG_ROOF_EXPERT": 33024,
                        "FG_ROOF_HC": 96, "FG_ROOF_RECURRENT": 3,
                        "FG_ROOF_GDN": 1, "FG_DECODE_SUBMIT_GROUP": 2,
                        "FG_EXPERT_Q8_WIDE": 1},
              "attribution": {"intrusive_only": True, "n1_profile": p1,
                              "n4_profile": p4, "operations": compare(n1, n4)},
              "evidence": evidence()}
    archive = "baseline-evidence.tar.gz"
    baseline = {n: replay(archive, n) for n in names(archive)
                if n.startswith("baseline-n") and n.endswith(".jsonl")}
    b1 = [r["median_us"] for n, r in baseline.items() if "baseline-n1" in n]
    b4 = next(r["median_us"] for n, r in baseline.items() if "baseline-n4" in n)
    report["synthetic_baseline"] = {
        "files": baseline, "n1_bracket_us": statistics.mean(b1),
        "n4_us": b4, "ratio": b4 / statistics.mean(b1)}
    route_rows = rows(archive, "routes-330-4.jsonl")
    report["profiled_frontier_union"] = {
        "first_token": 264, "n1_unique_per_layer": 10,
        "n4_unique_per_layer": {
            layer: len({expert for row in route_rows if row["layer"] == layer
                        for expert in row["experts"]}) for layer in range(6, 12)},
        "cardinality_not_weighted_bytes": True}
    report["rejected_matrix"] = []
    for mask, label in (
            (330, "baseline"),
            (8522, "FP32 dense dot"),
            (33098, "dense split columns"),
            (41290, "dot+split"),
            (16714, "singleton GU bucket"),
            (24906, "singleton+dot"),
            (49482, "singleton+split"),
            (57674, "singleton+dot+split")):
        a = replay("candidates-evidence.tar.gz", f"candidate-{mask}-1.jsonl")
        b = replay("candidates-evidence.tar.gz", f"candidate-{mask}-4.jsonl")
        report["rejected_matrix"].append({
            "experimental_mask": mask, "variant": label,
            "n1_us": a["median_us"], "n4_us": b["median_us"],
            "ratio": b["median_us"] / a["median_us"]})
    report["q8_union_synthetic_brackets"] = []
    for round_id in (1, 2, 3):
        group = {}
        for name in names("q8-evidence.tar.gz"):
            match = re.fullmatch(
                rf"q8-cost-{round_id}-(\d+)-(\d+)-([14])\.jsonl", name)
            if match:
                mask, stamp, n = map(int, match.groups())
                group.setdefault(stamp, {"mask": mask})[n] = replay(
                    "q8-evidence.tar.gz", name)["median_us"]
        a0, b, a1 = (group[k] for k in sorted(group))
        assert (a0["mask"], b["mask"], a1["mask"]) == (330, 131402, 330)
        report["q8_union_synthetic_brackets"].append({
            "round": round_id, "a0": a0, "b": b, "a1": a1,
            "n1_b_over_a": b[1] / statistics.mean((a0[1], a1[1])),
            "n4_b_over_a": b[4] / statistics.mean((a0[4], a1[4])),
            "candidate_n4_over_n1": b[4] / b[1]})
    report["gdn_eight_way_brackets"] = []
    for round_id in (1, 2, 3):
        group = {}
        for name in names("gdn-evidence.tar.gz"):
            match = re.fullmatch(
                rf"gdn-cost-{round_id}-(\d+)-(\d+)\.jsonl", name)
            if match:
                mask, stamp = map(int, match.groups())
                group[stamp] = {"mask": mask, **replay("gdn-evidence.tar.gz", name)}
        a0, b, a1 = (group[k] for k in sorted(group))
        report["gdn_eight_way_brackets"].append({
            "round": round_id, "a0": a0["median_us"], "b": b["median_us"],
            "a1": a1["median_us"],
            "b_over_a": b["median_us"] / statistics.mean((
                a0["median_us"], a1["median_us"]))})
    report["q8_union_component_gates"] = {
        "synthetic": components("q8-evidence.tar.gz", "q8-small_q8_down_union.log"),
        "authentic": components(
            "authentic-preparation.tar.gz", "authentic-q8-oracle.log"),
        "normalization": "abs(candidate-reference)/max(1,abs(reference))"}
    half_archive = "half-dot-evidence.tar.gz"
    if (HERE / half_archive).exists():
        half_brackets = []
        for round_id in (1, 2, 3):
            group = {}
            for name in names(half_archive):
                match = re.fullmatch(
                    rf"half-dot-cost-{round_id}-(\d+)-(\d+)-([14])\.jsonl", name)
                if match:
                    mask, stamp, n = map(int, match.groups())
                    result = replay(half_archive, name)
                    parity = next(r for r in rows(half_archive, name)
                                  if r.get("kind") == "parity")
                    group.setdefault(stamp, {"mask": mask})[n] = {
                        "median_us": result["median_us"], "parity": parity}
            a0, b, a1 = (group[k] for k in sorted(group))
            assert [r["mask"] for r in (a0, b, a1)] == [131402, 131914, 131402]
            half_brackets.append({
                "round": round_id, "a0": a0, "b": b, "a1": a1,
                "n4_b_over_a": b[4]["median_us"] / statistics.mean((
                    a0[4]["median_us"], a1[4]["median_us"])),
                "n1_b_over_a": b[1]["median_us"] / statistics.mean((
                    a0[1]["median_us"], a1[1]["median_us"])),
                "candidate_ratio": b[4]["median_us"] / b[1]["median_us"],
                "same_n4_parity": a0[4]["parity"] == b[4]["parity"] ==
                                   a1[4]["parity"]})
        isa = text(half_archive, "half-dot-isa.log")
        report["fp16_integer_operands_fp32_accumulation"] = {
            "not_shipping": True, "prototype_reuses_bit512_only_in_isolated_source": True,
            "native_v_dot2_instructions": isa.count("v_dot2"),
            "brackets": half_brackets,
            "median_n4_b_over_a": statistics.median(
                b["n4_b_over_a"] for b in half_brackets),
            "quality": "component/block fixtures only; not full-model/fleet qualified"}
    authentic_archive = "authentic-evidence.tar.gz"
    if (HERE / authentic_archive).exists():
        processes = {}
        for name in names(authentic_archive):
            match = re.fullmatch(r"authentic-cost-(\d+)-(\d+)-(\d+)\.jsonl", name)
            if not match:
                continue
            round_id, mask, stamp = map(int, match.groups())
            data = rows(authentic_archive, name)
            fits = [r for r in data if r.get("stage") == "native_graph_warmed"]
            assert len(fits) == 2, (name, fits)
            measurements = {}
            for slot in (0, 1):
                for n in (1, 2, 3, 4):
                    samples = [r for r in data if r.get("kind") ==
                               "authentic_weight_synthetic_hc_block"
                               and r["slot"] == slot and r["n"] == n]
                    assert len(samples) == 216 // n, (name, slot, n, len(samples))
                    assert all(r["first_token"] == 264 + i * n
                               and r["warmup_tokens"] == 264
                               and r["timed_tokens"] == 216
                               for i, r in enumerate(samples)), name
                    measurements[f"slot{slot}_n{n}_ms"] = statistics.median(
                        r["ms"] for r in samples)
            processes.setdefault(round_id, {})[stamp] = {
                "mask": mask, "file": name, "medians": measurements,
                "final_fits": fits}
        brackets = []
        assert set(processes) == {1, 2, 3}
        for round_id, process in sorted(processes.items()):
            a0, q8, combined, a1 = (process[k] for k in sorted(process))
            assert [r["mask"] for r in (a0, q8, combined, a1)] == [
                330, 131402, 393546, 330]
            assert all(fit["requested"] == 14427790128
                       and fit["allocated"] == 14427790144
                       for process in (a0, q8, combined, a1)
                       for fit in process["final_fits"])
            for slot in (0, 1):
                prefix = f"slot{slot}_n"
                baseline4 = statistics.mean((a0["medians"][prefix+"4_ms"],
                                             a1["medians"][prefix+"4_ms"]))
                baseline1 = statistics.mean((a0["medians"][prefix+"1_ms"],
                                             a1["medians"][prefix+"1_ms"]))
                brackets.append({
                    "round": round_id, "slot": slot,
                    "a0_n1_ms": a0["medians"][prefix+"1_ms"],
                    "a1_n1_ms": a1["medians"][prefix+"1_ms"],
                    "a0_n4_ms": a0["medians"][prefix+"4_ms"],
                    "a1_n4_ms": a1["medians"][prefix+"4_ms"],
                    "q8_n1_ms": q8["medians"][prefix+"1_ms"],
                    "q8_n4_ms": q8["medians"][prefix+"4_ms"],
                    "combined_n1_ms": combined["medians"][prefix+"1_ms"],
                    "combined_n4_ms": combined["medians"][prefix+"4_ms"],
                    "baseline_n4_over_n1": baseline4 / baseline1,
                    "q8_n4_over_n1": q8["medians"][prefix+"4_ms"] /
                                       q8["medians"][prefix+"1_ms"],
                    "combined_n4_over_n1": combined["medians"][prefix+"4_ms"] /
                                             combined["medians"][prefix+"1_ms"],
                    "q8_n4_vs_baseline": q8["medians"][prefix+"4_ms"] / baseline4,
                    "combined_n4_vs_baseline": combined["medians"][prefix+"4_ms"] /
                                                baseline4,
                    "combined_n4_vs_q8": combined["medians"][prefix+"4_ms"] /
                                          q8["medians"][prefix+"4_ms"]})
        report["authentic_full_head_sessions2"] = {
            "cache_mib": 128, "token_window": [264, 479], "processes": processes,
            "brackets": brackets, "natural_text": False, "zero_ngram": True,
            "production_qualified": False,
            "stable_rounds_2_3_median_n4_cost_ratio": statistics.median(
                b["q8_n4_vs_baseline"] for b in brackets if b["round"] > 1),
            "warm_second_slot_median_n4_over_n1": statistics.median(
                b["q8_n4_over_n1"] for b in brackets if b["slot"] == 1)}
        report["q8_union_component_gates"]["final_authentic"] = components(
            authentic_archive, "authentic-final-q8-oracle.log")
    report["gates"] = {
        "python_tests": 75, "native_q8_bit_exact_cases": 9,
        "synthetic_cpu_dense_cases": 90, "coordinator_rollback_cases": 24,
        "synthetic_tcp_ring_cases": 8,
        "full_model_quality": False, "powered_fleet_serving": False}
    report["policy"] = {
        "target_quantization_floor": "Q4", "full_draft_head_preferred": True,
        "subset_used_in_this_experiment": False, "new_optimizations_default_off": True}
    final_archive = "close-evidence.tar.gz"
    source_manifest = text(final_archive, "close-source.sha256")
    shader_manifest = text(final_archive, "close-shaders.sha256")
    sources = [line.split(None, 1) for line in source_manifest.splitlines()]
    assert all(hashlib.sha256((ROOT / name.strip()).read_bytes().replace(
        b"\r\n", b"\n")).hexdigest() == sha for sha, name in sources)
    report["final_build"] = {
        "c17_werror": True, "source_inputs": len(sources),
        "source_inputs_match_worktree": True,
        "source_manifest_sha256": hashlib.sha256(source_manifest.encode()).hexdigest(),
        "spirv_files": len(shader_manifest.splitlines()),
        "shader_manifest_sha256": hashlib.sha256(shader_manifest.encode()).hexdigest(),
        "binary_sha256": {name.strip(): sha for sha, name in
                          (line.split(None, 1) for line in text(
                              final_archive, "close-binaries.sha256").splitlines())},
        "packages": text(final_archive, "close-packages.log").splitlines(),
        "flags_gate": text(final_archive, "close-flags.log").strip(),
        "toolchain": text(final_archive, "close-toolchain.log").splitlines()}
    report["q8_union_component_gates"]["exact_final_source_authentic"] = components(
        final_archive, "close-small_q8_down_union.log")
    release = (HERE / "release-retry.log").read_text(encoding="utf-8")
    released = re.search(r"RELEASED_51 owned_root_absent_twice (\S+)", release)
    assert released and '"owned_processes_root_visible": 0' in release
    report["release"] = {
        "host": "192.168.42.51", "at_utc": released[1],
        "owned_root_absent_twice": True, "root_visible_owned_processes": 0,
        "owned_test_listeners": 0,
        "initial_and_final_cpu_governor_nodes": 0,
        "root_owned_cache_cleanup_required_bounded_sudo_retry": True,
        "no_access_after_release": True}
    report["result"] = {
        "whole_block_n4_over_n1_le_1_5": False, "bounded_search_exhausted": True,
        "not_a_physical_impossibility_claim": True,
        "retained_optimization_bit": 131072, "retained_mask": 131402,
        "removed_hc_experimental_bit": 262144}
    raw = ROOT / "results" / "hillclimb" / "mtp-block-gaps-evidence.tar.gz"
    if raw.exists():
        report["raw_archive"] = {"file": raw.name, "bytes": raw.stat().st_size,
                                 "sha256": hashlib.sha256(raw.read_bytes()).hexdigest()}
    target = ROOT / "results" / "hillclimb" / "mtp-block-gaps.json"
    target.write_text(json.dumps(report, indent=2) + "\n")
    print(target)


if __name__ == "__main__":
    main()
