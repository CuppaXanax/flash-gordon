from pathlib import Path
import io
import tarfile

root = Path.cwd()
build = root / ".build"
destination = build / "mtp-block"
with tarfile.open(destination / "assets.tar", "w") as out:
    for path, name in (
        (build / "mtp-residency" / "source-coverage.json", "metadata/source-coverage.json"),
        (build / "mtp-residency" / "metadata-source" / "manifest.fgm", "metadata/manifest.fgm"),
        (build / "mtp-residency" / "rank7-mix04-source.tar.gz", "rank7-mix04-source.tar.gz"),
        (build / "mtp-lease" / "native-q8.gguf", "native-q8.gguf"),
    ):
        out.add(path, arcname=name)
    with tarfile.open(build / "mtp-lease" / "runs" /
                      "mtp-acceptance-20261016-retry" / "baseline-0.tar") as previous:
        member = previous.getmember("head.q8")
        out.addfile(member, previous.extractfile(member))
    for path, name in (
        (build / "mtp-residency" / "place-mixed-52.py", "place-mixed.py"),
        (build / "mtp-goodput" / "auxiliary.py", "auxiliary.py"),
    ):
        text = path.read_text().replace("/home/xander/hc-mtp/goodput", "/home/xander/hc-mtp/block")
        if name == "place-mixed.py":
            text = text.replace("/home/xander/hc-mtp", "/home/xander/hc-mtp/block")
            text = text.replace("residency-source", "source")
        data = text.encode()
        member = tarfile.TarInfo(name)
        member.size = len(data)
        out.addfile(member, io.BytesIO(data))
print((destination / "assets.tar").stat().st_size)
