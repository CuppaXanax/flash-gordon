set -eu
cd /home/xander/hc-mtp/block/source-final
sha256sum -c ../close-shaders.sha256 > ../close-release-check.log
if command -v rpm >/dev/null; then
    rpm -q mesa-vulkan-drivers vulkan-loader shaderc glslang gcc > ../close-packages.log || true
fi
cd ..
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > governor-now.sha256
cmp governor.sha256 governor-now.sha256
if test -s governor.sha256; then
    sha256sum -c governor.sha256 >> close-release-check.log
else
    echo 'CPU governor node inventory unchanged: empty before/after' >> close-release-check.log
fi
tar -czf close-evidence.tar.gz close-*.log close-*.jsonl close-*.sha256 governor*.sha256
tar -czf final-bundle.tar.gz close-evidence.tar.gz block-release.tar.gz
printf 'FINAL_SOURCE_SHADER_PACKAGES_GOVERNORS_AUTHENTICATED\n'
