set -eu
root=/home/xander/hc-mtp
test ! -d "$root/goodput"
test -f "$root/block/source.tar.gz"
mkdir -p "$root/block/source"
cd "$root/block"
test -f governor.sha256
tar -xzf source.tar.gz -C source
cd source
mkdir -p .build ../baseline-vulkan
cp vulkan/*.spv ../baseline-vulkan/
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=330
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
for mask in 330 328; do
    export FG_SMALL_KERNELS="$mask"
    for n in 1 4; do
        sudo -n --preserve-env=FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
            'ulimit -l unlimited; exec ./baseline-bench --q4 --mixed-experts --small-n --batch "$1" --warmup "$((264/$1))" --iterations 1 --windows 1 --profile --routing-trace ../routes-"$2"-"$1".jsonl --allow-reassociation --no-clocks' bash "$n" "$mask" > "../profile-$mask-$n.jsonl" 2> "../profile-$mask-$n.log"
    done
done
for n in 1 4 1; do
    tag=$(date +%s%N)
    FG_SMALL_KERNELS=330 sudo -n --preserve-env=FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./baseline-bench --q4 --mixed-experts --small-n --batch "$1" --warmup "$((264/$1))" --iterations "$((216/$1))" --windows 1 --allow-reassociation --no-clocks' bash "$n" > "../baseline-n$n-$tag.jsonl" 2> "../baseline-n$n-$tag.log"
done
cd ..
tar -czf baseline-evidence.tar.gz profile-*.jsonl profile-*.log routes-*.jsonl baseline-n*.jsonl baseline-n*.log
printf 'BLOCK_BASELINE_READY\n'
