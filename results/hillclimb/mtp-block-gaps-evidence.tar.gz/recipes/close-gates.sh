set -eu
cd /home/xander/hc-mtp/block
tar -xzf close-update.tar.gz -C source-final
cd source-final
export TMPDIR="$PWD/.build/scratch" XDG_CACHE_HOME="$PWD/.build/cache"
{
    uname -a
    cc --version | head -1
    if command -v glslc >/dev/null; then glslc --version; fi
    if command -v glslangValidator >/dev/null; then glslangValidator --version; fi
    dpkg-query -W mesa-vulkan-drivers libvulkan1 2>/dev/null || true
} > ../close-toolchain.log
touch src/vk.c src/runtime.c tests/test_fg_vk.c
touch shaders/fg_small_down_q8_union.comp
make -j12 flash-gordon tools/bench-decode-fusion tools/mtp-residency tests/test_fg_vk tests/test_mtp_ring > ../close-build.log 2>&1
make test-mtp test-mtp-vocab > ../close-cpu.log 2>&1
bash tools/check-flags.sh > ../close-flags.log
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
export FG_SMALL_KERNELS=131402
for oracle in small_q8_down_native small_q8_down_union; do
    FG_TEST_Q8_DOWN_TENSOR="$PWD/../authentic-q8-down.bin" DS4_REMOTE_TEST_FILTER="$oracle" \
        ./tests/test_fg_vk > "../close-$oracle.jsonl" 2> "../close-$oracle.log"
done
run(){
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
run --q4 --mixed-experts --small-test --allow-reassociation --no-clocks > ../close-block.jsonl 2> ../close-block.log
run --q4 --mixed-experts --session-test --allow-reassociation --warmup 8 --iterations 8 --windows 1 --no-clocks > ../close-sessions.jsonl 2> ../close-sessions.log
run --q4 --mixed-experts --coordinator-state-test --allow-reassociation --no-clocks > ../close-state.jsonl 2> ../close-state.log
for native in 7 6; do
    for reject in 0 1 2 3; do
        ./tests/test_mtp_ring 127.0.0.1 127.0.0.1 "$((18100+reject*20+(7-native)*100))" "$reject" 2 "$native" 1 > "../close-ring-$native-$reject.log" 2>&1
    done
done
sha256sum flash-gordon tools/bench-decode-fusion tools/mtp-residency tests/test_fg_vk > ../close-binaries.sha256
find src include shaders tools tests -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' -o -name '*.glsl' -o -name '*.comp' -o -name '*.py' \) -print0 |
    sort -z | xargs -0 sha256sum > ../close-source.sha256
find vulkan -type f -name '*.spv' -print0 | sort -z | xargs -0 sha256sum > ../close-shaders.sha256
cd ..
tar -czf close-evidence.tar.gz close-*.log close-*.jsonl close-*.sha256
tar -czf block-release.tar.gz -C source-final flash-gordon tools/bench-decode-fusion tools/mtp-residency tests/test_fg_vk vulkan
echo FINAL_SOURCE_COMPONENT_PROTOCOL_GATES_PASS
