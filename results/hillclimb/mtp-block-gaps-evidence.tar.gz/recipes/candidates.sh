set -eu
cd /home/xander/hc-mtp/block
tar -xzf update.tar.gz -C source
cd source
find src include tools -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' \) -exec touch {} +
touch shaders/fg_small_gate_up.glsl shaders/fg_small_reuse_rows.glsl
make -j12 tools/bench-decode-fusion > ../candidate-build.log 2>&1
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
run(){
    sudo -n --preserve-env=FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
for mask in 8522 33098 41290 16714 24906 49482 57674; do
    export FG_SMALL_KERNELS="$mask"
    run --q4 --mixed-experts --small-test --allow-reassociation --no-clocks > "../oracle-$mask.jsonl" 2> "../oracle-$mask.log"
done
for mask in 330 8522 33098 41290 16714 24906 49482 57674; do
    export FG_SMALL_KERNELS="$mask"
    for n in 1 4; do
        run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" --iterations "$((216/n))" --windows 1 --allow-reassociation --no-clocks > "../candidate-$mask-$n.jsonl" 2> "../candidate-$mask-$n.log"
    done
done
for n in 1 4; do
    export FG_SMALL_KERNELS=330
    run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" --iterations 1 --windows 1 --profile --allow-reassociation --no-clocks > "../scoped-profile-330-$n.jsonl" 2> "../scoped-profile-330-$n.log"
done
cd ..
tar -czf candidates-evidence.tar.gz candidate-*.log candidate-*.jsonl oracle-*.jsonl oracle-*.log scoped-profile-*.jsonl scoped-profile-*.log
printf 'CANDIDATE_MATRIX_COMPLETE\n'
