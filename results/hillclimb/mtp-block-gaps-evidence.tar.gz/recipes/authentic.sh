set -eu
cd /home/xander/hc-mtp/block
test "$(df -B1 --output=avail . | tail -1)" -ge 25769803776
tar -xf assets.tar
rm assets.tar
mkdir real-rank7
test "$(sha256sum native-q8.gguf | cut -d' ' -f1)" = 536bab54b0a1bdea23b65871c4cdc38deee5803771501a0c770a0510bcd3283b
test "$(sha256sum head.q8 | cut -d' ' -f1)" = 2801d79db74bcae38b47fd5051f03136d8ca7715abeba7d92b49ba46c696bc33
make -C source -j12 tools/mtp-real-place tools/mtp-embedding tools/mtp-residency > authentic-build.log 2>&1
python3 source/tools/mtp_rank_source.py --coverage metadata/source-coverage.json --manifest metadata/manifest.fgm --placer source/tools/mtp-real-place --directory real-rank7 > authentic-public-source.log 2>&1
python3 place-mixed.py > authentic-mixed-source.log 2>&1
python3 auxiliary.py > authentic-auxiliary.log 2>&1
source/tools/mtp-embedding real-rank7/manifest.fgm real-rank7/embedding.fgme > authentic-embedding.log 2>&1
python3 - <<'PY'
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,"source/tools")
from mtp_format_audit import load_manifest
m=load_manifest("real-rank7/manifest.fgm")
r=next(t for t in m["records"] if t["name"]=="blk.46.ffn_down_exps.weight.rank7")
assert r["type"]==8
digest=hashlib.sha256()
with open("real-rank7/rank-07.fgw","rb") as f,open("authentic-q8-down.bin","xb") as out:
    f.seek(r["offset"]);remaining=r["bytes"]
    while remaining:
        b=f.read(min(16*1024*1024,remaining))
        assert b
        digest.update(b);out.write(b);remaining-=len(b)
assert digest.hexdigest()==r["sha256"]
Path("authentic-q8-down.json").write_text(json.dumps(dict(tensor=r,readback_sha256=digest.hexdigest()))+"\n")
PY
export FG_SHADER_DIR="$PWD/source/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=131402
FG_TEST_Q8_DOWN_TENSOR="$PWD/authentic-q8-down.bin" DS4_REMOTE_TEST_FILTER=small_q8_down_union \
    source/tests/test_fg_vk > authentic-q8-oracle.jsonl 2> authentic-q8-oracle.log
tar -czf authentic-preparation.tar.gz authentic-*.log authentic-*.jsonl authentic-q8-down.json real-rank7/*source.json* real-rank7/placer-negative.json
printf 'AUTHENTIC_RANK7_AND_Q8_COMPONENT_READY\n'
