set -eu
cd /home/xander/hc-mtp/block
tar -xzf update.tar.gz -C source
cd source
find src include tools tests -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' \) -exec touch {} +
touch shaders/fg_small_gate_up.glsl shaders/fg_small_reuse_rows.glsl shaders/fg_gdn_small_cached.comp
make -j12 tools/bench-decode-fusion tests/test_fg_vk > ../q8-union-build.log 2>&1
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
export FG_SMALL_KERNELS=131402
for oracle in small_q8_down_native small_q8_down_union; do
    DS4_REMOTE_TEST_FILTER="$oracle" ./tests/test_fg_vk > "../q8-$oracle.jsonl" 2> "../q8-$oracle.log"
done
run(){
    sudo -n --preserve-env=FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
run --q4 --mixed-experts --small-test --allow-reassociation --no-clocks > ../q8-block-oracle.jsonl 2> ../q8-block-oracle.log
run --q4 --mixed-experts --session-test --allow-reassociation --warmup 8 --iterations 8 --windows 1 --no-clocks > ../q8-session-oracle.jsonl 2> ../q8-session-oracle.log
run --q4 --mixed-experts --coordinator-state-test --allow-reassociation --no-clocks > ../q8-state-oracle.jsonl 2> ../q8-state-oracle.log
for round in 1 2 3; do
    for mask in 330 131402 330; do
        export FG_SMALL_KERNELS="$mask"
        stamp="$(date +%s%N)"
        for n in 1 4; do
            run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" --iterations "$((216/n))" --windows 1 --allow-reassociation --no-clocks > "../q8-cost-$round-$mask-$stamp-$n.jsonl" 2> "../q8-cost-$round-$mask-$stamp-$n.log"
        done
    done
done
for mask in 330 131402; do
    export FG_SMALL_KERNELS="$mask"
    run --q4 --mixed-experts --small-n --batch 4 --warmup 66 --iterations 1 --windows 1 --profile --allow-reassociation --no-clocks > "../q8-profile-$mask.jsonl" 2> "../q8-profile-$mask.log"
done
cd ..
tar -czf q8-evidence.tar.gz q8-*.log q8-*.jsonl
printf 'Q8_UNION_GATES_AND_REPLAY_COMPLETE\n'
