set -eu
test ! -d /home/xander/hc-mtp/goodput
test ! -d /home/xander/hc-mtp/block
mkdir -p /home/xander/hc-mtp/block
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > /home/xander/hc-mtp/block/governor.sha256
echo BLOCK_RESERVED_51
