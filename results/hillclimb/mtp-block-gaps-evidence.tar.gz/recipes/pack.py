import io
from pathlib import Path
import subprocess
import tarfile

root=Path.cwd()
names=subprocess.check_output(["git","ls-files","--cached","--others","--exclude-standard","-z"]).decode().split("\0")
with tarfile.open(root/".build"/"mtp-block"/"source.tar.gz","w:gz") as out:
    for name in names:
        if not name or name.startswith(("results/",".github/",".claude/")):
            continue
        path=root/name
        if not path.is_file():
            continue
        raw=path.read_bytes()
        if b"\0" not in raw:
            raw=raw.replace(b"\r\n",b"\n")
        member=tarfile.TarInfo(name);member.size=len(raw)
        member.mode=0o755 if name.endswith(".sh") or name=="glslc" else 0o644
        out.addfile(member,io.BytesIO(raw))
    with tarfile.open(root/".build"/"mtp-goodput"/"candidate-release.tar.gz") as old:
        for member in old:
            if member.isfile() and (member.name.startswith("vulkan/") or member.name=="tools/bench-decode-fusion"):
                name=member.name
                data=old.extractfile(member)
                if name=="tools/bench-decode-fusion":
                    member.name="baseline-bench"
                out.addfile(member,data)
