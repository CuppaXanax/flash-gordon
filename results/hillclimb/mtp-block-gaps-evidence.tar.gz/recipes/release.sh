set -eu
root=/home/xander/hc-mtp
test -d "$root/block"
cd "$root/block"
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > governor-now.sha256
cmp governor.sha256 governor-now.sha256
if test -s governor.sha256; then sha256sum -c governor.sha256
else echo 'CPU governor node inventory unchanged: empty before/after'; fi
cd /home/xander
sudo -n python3 - "$0" <<'PY'
import json, os, pathlib, subprocess, sys
root = pathlib.Path("/home/xander/hc-mtp")
allowed = {"block", pathlib.Path(sys.argv[1]).name}
entries = {p.name for p in root.iterdir()}
if entries != allowed:
    raise SystemExit("unexpected owned-root entries: " + repr(entries))
running = []
for p in pathlib.Path("/proc").iterdir():
    if not p.name.isdigit() or int(p.name) in {os.getpid(), os.getppid()}:
        continue
    try:
        exe, cwd = os.readlink(p/"exe"), os.readlink(p/"cwd")
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        continue
    if exe.startswith(str(root)+"/") or cwd.startswith(str(root)+"/block"):
        running.append({"pid": int(p.name), "exe": exe, "cwd": cwd})
if running:
    raise SystemExit("owned process still running: " + repr(running))
ports = {18100 + reject*20 + (7-native)*100 + rank
         for native in (7,6) for reject in range(4) for rank in range(8)}
listeners = subprocess.check_output(["ss", "-H", "-ltn"], text=True).splitlines()
for line in listeners:
    local = line.split()[3]
    if int(local.rsplit(":",1)[1]) in ports:
        raise SystemExit("owned test listener remains: " + line)
print(json.dumps({"owned_processes":0, "owned_test_listeners":0,
                  "governors_match_reservation":True,
                  "root_entries_before_removal":sorted(entries)}))
PY
sudo -n rm -rf -- /home/xander/hc-mtp
test ! -e /home/xander/hc-mtp
sleep 2
test ! -e /home/xander/hc-mtp
printf 'RELEASED_51 owned_root_absent_twice %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
