set -eu
cd /home/xander/hc-mtp/block/source
export TMPDIR="$PWD/.build/scratch" XDG_CACHE_HOME="$PWD/.build/cache"
mkdir -p "$TMPDIR"
cp ../half-dot.glsl shaders/fg_small_gate_up.glsl
touch shaders/fg_small_gate_up.glsl
make -j8 vulkan/fg_small_gate_up_half.spv vulkan/fg_small_gate_up_four_half.spv > ../half-dot-build.log 2>&1
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
run(){
    sudo -n --preserve-env=RADV_DEBUG,MESA_SHADER_CACHE_DISABLE,TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
export FG_SMALL_KERNELS=131914
run --q4 --mixed-experts --small-test --allow-reassociation --no-clocks > ../half-dot-oracle.jsonl 2> ../half-dot-oracle.log
for round in 1 2 3; do
    for mask in 131402 131914 131402; do
        export FG_SMALL_KERNELS="$mask"
        stamp="$(date +%s%N)"
        for n in 1 4; do
            run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" --iterations "$((216/n))" --windows 1 --allow-reassociation --no-clocks > "../half-dot-cost-$round-$mask-$stamp-$n.jsonl" 2> "../half-dot-cost-$round-$mask-$stamp-$n.log"
        done
    done
done
export FG_SMALL_KERNELS=131914
RADV_DEBUG=shaders,shaderstats MESA_SHADER_CACHE_DISABLE=true \
    run --q4 --mixed-experts --small-n --batch 4 --warmup 1 --iterations 1 --windows 1 --allow-reassociation --no-clocks > ../half-dot-isa.jsonl 2> ../half-dot-isa.log
sha256sum shaders/fg_small_gate_up.glsl vulkan/fg_small_gate_up_half.spv vulkan/fg_small_gate_up_four_half.spv > ../half-dot-shaders.sha256
cd ..
tar -czf half-dot-evidence.tar.gz half-dot-*.log half-dot-*.jsonl half-dot-shaders.sha256 half-dot.glsl
echo EXACT_INTEGER_FP16_INPUT_FP32_ACCUMULATION_PROBE_COMPLETE
