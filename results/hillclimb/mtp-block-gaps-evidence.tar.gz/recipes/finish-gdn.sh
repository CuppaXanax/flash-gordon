set -eu
cd /home/xander/hc-mtp/block/source
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
run(){
    sudo -n --preserve-env=RADV_DEBUG,MESA_SHADER_CACHE_DISABLE,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
for mask in 328 330 65866 8522 33098 16714; do
    export FG_SMALL_KERNELS="$mask" RADV_DEBUG=shaderstats MESA_SHADER_CACHE_DISABLE=true
    run --q4 --mixed-experts --small-n --batch 4 --warmup 1 --iterations 1 --windows 1 --allow-reassociation --no-clocks > "../isa-$mask.jsonl" 2> "../isa-$mask.log"
done
unset RADV_DEBUG MESA_SHADER_CACHE_DISABLE
for mask in 330 65866; do
    export FG_SMALL_KERNELS="$mask"
    run --q4 --mixed-experts --small-n --batch 4 --warmup 66 --iterations 1 --windows 1 --profile --allow-reassociation --no-clocks > "../gdn-profile-$mask.jsonl" 2> "../gdn-profile-$mask.log"
done
cd ..
tar -czf gdn-evidence.tar.gz gdn-build.log gdn-oracle-* gdn-cost-* isa-* gdn-profile-*
printf 'GDN_PARTITION_AND_ISA_COMPLETE\n'
