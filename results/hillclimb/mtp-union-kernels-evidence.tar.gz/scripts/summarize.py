import hashlib
import json
import statistics
import tarfile
from pathlib import Path

root = Path(".build/mtp-op-floor")


def entries(archive):
    with tarfile.open(root / archive) as tar:
        for member in tar:
            if member.isfile() and member.name.endswith(".jsonl"):
                rows = [json.loads(line) for line in tar.extractfile(member).read().decode().splitlines()
                        if line.startswith("{")]
                yield member.name, rows


replays = []
for name, rows in entries("final-evidence.tar.gz"):
    if not name.startswith("final-replay-"):
        continue
    bracket, mask, tag, n = map(int, name[:-6].split("-")[-4:])
    samples = [row["wall_us"] for row in rows if row["kind"] == "sample"]
    parity = next(row for row in rows if row["kind"] == "parity")
    replays.append(dict(name=name, bracket=bracket, mask=mask, tag=tag, n=n,
                        median_us=statistics.median(samples), mean_us=statistics.mean(samples),
                        samples=len(samples), parity=parity))
brackets = []
for bracket in range(1, 4):
    groups = sorted({r["tag"] for r in replays if r["bracket"] == bracket})
    value = dict(bracket=bracket)
    for n in (1, 4):
        triplet = [next(r for r in replays if r["bracket"] == bracket and r["n"] == n
                        and r["tag"] == tag) for tag in groups]
        assert [r["mask"] for r in triplet] == [131402, 393546, 131402]
        assert len({r["parity"]["output_hash"] for r in triplet}) == 1
        assert len({r["parity"]["gdn_state_hash"] for r in triplet}) == 1
        baseline = statistics.mean([triplet[0]["median_us"], triplet[2]["median_us"]])
        value[f"n{n}"] = dict(a0_us=triplet[0]["median_us"], b_us=triplet[1]["median_us"],
                             a1_us=triplet[2]["median_us"], b_over_bracket_a=triplet[1]["median_us"]/baseline)
    value["candidate_n4_over_n1"] = value["n4"]["b_us"]/value["n1"]["b_us"]
    brackets.append(value)

floor = []
for ratio in (1, 1.8, 3, 4):
    ideal = 437.84*ratio + 296.16*ratio + 1.1*(854.20+434.44) + 671.24
    current = ideal + 1055.72-671.24
    floor.append(dict(assumed_gu_and_down_byte_ratio=ratio, ideal_other_us=ideal,
                      current_other_us=current, ideal_n4_over_n1=ideal/2693.88,
                      current_other_n4_over_n1=current/2693.88))

result = dict(
    status="offline research candidate; actual real-draft target unions unavailable",
    real_draft_union_measured=False,
    real_draft_union_blocker="Retained authentic captures lack N4 target routes; fresh explicit capture lease needed.",
    device="AMD BC-250 (RADV GFX1013), .51 only, Vulkan reports24 CUs",
    target_weights_unchanged=True,
    draft_vocab_unchanged=True,
    selected_mask=393546,
    baseline_mask=131402,
    selected_kernel="N2..4 native HC up+mix: one packed fragment, N FP32 accumulators, fused mix/injection",
    source_baseline="4b002778f21d9c1e63a5f246be572638637f827b",
    replay_geometry=dict(layers=list(range(6, 12)), warmup_tokens=264, timed_tokens=216,
                         origin="synthetic input/weights; not authentic rank7 or fleet"),
    brackets=brackets,
    median_n4_b_over_a=statistics.median(b["n4"]["b_over_bracket_a"] for b in brackets),
    median_n1_b_over_a=statistics.median(b["n1"]["b_over_bracket_a"] for b in brackets),
    median_candidate_n4_over_n1=statistics.median(b["candidate_n4_over_n1"] for b in brackets),
    replay_rows=replays,
    conditional_op_weighted_floor=dict(measured_real_ceiling=False,
                                      source="Published intrusive six-layer N1 proxy, not authentic service",
                                      dense_and_hc_ratio_assumption=1.1,
                                      scenarios=floor),
    rejected_experiments=[
        dict(name="shared-LDS HC up/mix", result="slower than register fusion; removed"),
        dict(name="shared-LDS dense tiles", result="N4 representative dense2.2–2.5x slower; whole block~29% slower; removed"),
    ],
    excluded_evidence=[
        dict(name="first-evidence.tar.gz microbench", reason="baseline did not enable small-N mode; component results valid, microbench speedups not serving comparisons"),
        dict(name="compute-evidence.tar.gz", reason="private nominal arithmetic probe; not used to establish an attainable quantized-kernel ceiling"),
    ],
)
result["raw_archives"] = [
    dict(path=name, bytes=(root/name).stat().st_size,
         sha256=hashlib.sha256((root/name).read_bytes()).hexdigest())
    for name in ("hc-ab-evidence.tar.gz", "dense-ab-evidence.tar.gz",
                 "rejected-kernel-sources.tar.gz", "final-evidence.tar.gz", "close-evidence.tar.gz")
]
(root/"summary.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({k: result[k] for k in
                  ("median_n4_b_over_a", "median_n1_b_over_a", "median_candidate_n4_over_n1")}))
