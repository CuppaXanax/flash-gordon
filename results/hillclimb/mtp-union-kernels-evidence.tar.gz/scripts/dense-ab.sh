set -eu
cd /home/xander/hc-mtp/op-floor
export TMPDIR="$PWD/cache" XDG_CACHE_HOME="$PWD/cache"
tar -xzf source.tar.gz -C source
cd source
touch src/vk.c src/expert.c src/mtp_capture.c src/runtime.c tests/test_fg_vk.c shaders/fg_dense_soa_impl.glsl
make -j12 flash-gordon tools/bench-decode-fusion tests/test_fg_vk test-mtp-capture shaders > ../dense-build.log 2>&1
mkdir -p .build
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
for type in 12 13 20; do
    for mask in 393546 1442122 393546; do
        tag=$(date +%s%N)
        FG_SMALL_KERNELS=$mask ./tools/bench-decode-fusion --dense-only --dense-type "$type" \
            --dense-shape 2560 10240 --allow-reassociation --no-clocks \
            > "../dense-$type-$mask-$tag.jsonl" 2> "../dense-$type-$mask-$tag.log"
    done
done
for mask in 393546 1442122 393546; do
    tag=$(date +%s%N)
    FG_SMALL_KERNELS=$mask ./tools/bench-decode-fusion --q4 --mixed-experts --small-n \
        --batch 4 --warmup 66 --iterations 54 --windows 1 --allow-reassociation --no-clocks \
        > "../dense-block-$mask-$tag.jsonl" 2> "../dense-block-$mask-$tag.log"
done
cd ..
tar -czf dense-ab-evidence.tar.gz dense-build.log dense-*.jsonl dense-*.log
printf 'DENSE_LDS_AB_READY\n'
