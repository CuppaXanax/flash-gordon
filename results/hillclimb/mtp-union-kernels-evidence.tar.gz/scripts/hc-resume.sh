set -eu
cd /home/xander/hc-mtp/op-floor/source
mkdir -p .build
export TMPDIR="$PWD/../cache" XDG_CACHE_HOME="$PWD/../cache"
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
for mask in 131402 393546 655690; do
    for n in 1 4; do
        FG_SMALL_KERNELS=$mask ./tools/bench-decode-fusion --q4 --mixed-experts --small-n \
            --batch "$n" --warmup "$((264/n))" --iterations 1 --windows 1 --profile \
            --allow-reassociation --no-clocks > "../hc-profile-$mask-$n.jsonl" 2> "../hc-profile-$mask-$n.log"
    done
done
for round in 1 2 3; do
    for mask in 131402 393546 655690 131402; do
        tag=$(date +%s%N)
        FG_SMALL_KERNELS=$mask ./tools/bench-decode-fusion --q4 --mixed-experts --small-n \
            --batch 4 --warmup 66 --iterations 54 --windows 1 --allow-reassociation --no-clocks \
            > "../hc-replay-$round-$mask-$tag.jsonl" 2> "../hc-replay-$round-$mask-$tag.log"
    done
done
cd ..
tar -czf hc-ab-evidence.tar.gz hc-ab-build.log hc-small-*.jsonl hc-small-*.log hc-profile-*.jsonl hc-profile-*.log hc-replay-*.jsonl hc-replay-*.log
printf 'HC_BATCH_AB_READY\n'
