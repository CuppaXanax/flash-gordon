set -eu
cd /home/xander/hc-mtp/op-floor
mkdir source-final
export TMPDIR="$PWD/cache" XDG_CACHE_HOME="$PWD/cache"
tar -xzf source.tar.gz -C source-final
cd source-final
mkdir -p .build
find src include shaders tests tools -type f -exec touch {} +
make -j12 flash-gordon tools/bench-decode-fusion tests/test_fg_vk tests/test_mtp_ring test-mtp-capture shaders > ../final-build.log 2>&1
make test-mtp test-mtp-vocab > ../final-cpu.log 2>&1
python3 -m unittest discover -s tools -p 'test_analyze_mtp*.py' > ../final-analyzer.log 2>&1
bash tools/check-flags.sh > ../final-flags.log
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
export FG_SMALL_KERNELS=393546
for oracle in small_hc_up_mix roof_hc_up_mix small_q8_down_native small_q8_down_union; do
    DS4_REMOTE_TEST_FILTER="$oracle" ./tests/test_fg_vk > "../final-$oracle.jsonl" 2> "../final-$oracle.log"
done
run(){
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
run --q4 --mixed-experts --small-n --batch 4 --small-test --allow-reassociation \
    --routing-trace ../final-synthetic-routes.jsonl --warmup 8 --iterations 8 --windows 1 \
    --no-clocks > ../final-block.jsonl 2> ../final-block.log
run --q4 --mixed-experts --session-test --allow-reassociation --warmup 8 --iterations 8 --windows 1 --no-clocks > ../final-sessions.jsonl 2> ../final-sessions.log
run --q4 --mixed-experts --coordinator-state-test --allow-reassociation --no-clocks > ../final-state.jsonl 2> ../final-state.log
for native in 7 6; do
    for reject in 0 1 2 3; do
        ./tests/test_mtp_ring 127.0.0.1 127.0.0.1 "$((18100+reject*20+(7-native)*100))" "$reject" 2 "$native" 1 > "../final-ring-$native-$reject.log" 2>&1
    done
done
for round in 1 2 3; do
    for mask in 131402 393546 131402; do
        export FG_SMALL_KERNELS=$mask
        tag=$(date +%s%N)
        for n in 1 4; do
            run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" \
                --iterations "$((216/n))" --windows 1 --allow-reassociation --no-clocks \
                > "../final-replay-$round-$mask-$tag-$n.jsonl" 2> "../final-replay-$round-$mask-$tag-$n.log"
        done
    done
done
sha256sum flash-gordon tools/bench-decode-fusion tests/test_fg_vk > ../final-binaries.sha256
find src include shaders tools tests -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' -o -name '*.glsl' -o -name '*.comp' -o -name '*.py' \) -print0 | sort -z | xargs -0 sha256sum > ../final-source.sha256
find vulkan -type f -name '*.spv' -print0 | sort -z | xargs -0 sha256sum > ../final-shaders.sha256
cd ..
tar -czf final-evidence.tar.gz final-*.log final-*.jsonl final-*.sha256
tar -czf candidate-release.tar.gz -C source-final flash-gordon tools/bench-decode-fusion tests/test_fg_vk vulkan
printf 'FINAL_HC_ROUTE_COMPONENT_STATE_RING_GATES_PASS\n'
