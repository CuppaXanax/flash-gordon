set -eu
cd /home/xander/hc-mtp/op-floor
test -s candidate-release.tar.gz
sha256sum candidate-release.tar.gz
test -s close-evidence.tar.gz
grep -q '"record_callback_skipped":true,"ids_equal":true' restored-block.jsonl
echo FINAL_CANDIDATE_RETAINED
