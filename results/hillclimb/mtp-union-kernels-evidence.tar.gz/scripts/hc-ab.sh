set -eu
cd /home/xander/hc-mtp/op-floor
export TMPDIR="$PWD/cache" XDG_CACHE_HOME="$PWD/cache"
tar -xzf source.tar.gz -C source
cd source
touch src/vk.c src/owner.c tests/test_fg_vk.c
make -j12 tools/bench-decode-fusion tests/test_fg_vk shaders > ../hc-ab-build.log 2>&1
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
for mask in 393546 655690; do
    FG_SMALL_KERNELS=$mask DS4_REMOTE_TEST_FILTER=small_hc_up_mix FG_BENCH_HC_INJECT=1 \
        ./tests/test_fg_vk > "../hc-small-$mask.jsonl" 2> "../hc-small-$mask.log"
done
export FG_SMALL_KERNELS=131402
for mask in 131402 393546 655690; do
    for n in 1 4; do
        FG_SMALL_KERNELS=$mask ./tools/bench-decode-fusion --q4 --mixed-experts --small-n \
            --batch "$n" --warmup "$((264/n))" --iterations 1 --windows 1 --profile \
            --allow-reassociation --no-clocks > "../hc-profile-$mask-$n.jsonl" 2> "../hc-profile-$mask-$n.log"
    done
done
for round in 1 2 3; do
    for mask in 131402 393546 655690 131402; do
        tag=$(date +%s%N)
        FG_SMALL_KERNELS=$mask ./tools/bench-decode-fusion --q4 --mixed-experts --small-n \
            --batch 4 --warmup 66 --iterations 54 --windows 1 --allow-reassociation --no-clocks \
            > "../hc-replay-$round-$mask-$tag.jsonl" 2> "../hc-replay-$round-$mask-$tag.log"
    done
done
cd ..
tar -czf hc-ab-evidence.tar.gz hc-ab-build.log hc-small-*.jsonl hc-small-*.log hc-profile-*.jsonl hc-profile-*.log hc-replay-*.jsonl hc-replay-*.log
printf 'HC_BATCH_AB_READY\n'
