import io
import subprocess
import tarfile
from pathlib import Path

root = Path.cwd()
names = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"]
).decode().split("\0")
with tarfile.open(root / ".build/mtp-op-floor/source.tar.gz", "w:gz") as out:
    for name in names:
        if not name or name.startswith(("results/", ".github/", ".claude/")):
            continue
        path = root / name
        if not path.is_file():
            continue
        data = path.read_bytes()
        if b"\0" not in data:
            data = data.replace(b"\r\n", b"\n")
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = 0o755 if name.endswith(".sh") or name == "glslc" else 0o644
        out.addfile(member, io.BytesIO(data))
    with tarfile.open(root / ".build/mtp-block/block-release.tar.gz") as old:
        for member in old:
            if member.isfile() and member.name.startswith("vulkan/"):
                out.addfile(member, old.extractfile(member))
