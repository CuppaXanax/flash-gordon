set -eu
cd /home/xander/hc-mtp/op-floor
mkdir -p source cache
export TMPDIR="$PWD/cache" XDG_CACHE_HOME="$PWD/cache"
tar -xzf source.tar.gz -C source
cd source
touch src/vk.c src/owner.c tests/test_fg_vk.c
make -j12 tools/bench-decode-fusion tests/test_fg_vk shaders > ../build.log 2>&1
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
DS4_REMOTE_TEST_FILTER=small_hc_up_mix FG_BENCH_HC_INJECT=1 \
    ./tests/test_fg_vk > ../hc-up-test.jsonl 2> ../hc-up-test.log
tar -czf ../first-evidence.tar.gz -C .. build.log hc-up-test.jsonl hc-up-test.log
printf 'SMALL_HC_UP_FIRST_READY\n'
