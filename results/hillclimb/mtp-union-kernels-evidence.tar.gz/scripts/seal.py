import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

root = Path(".build/mtp-op-floor")
output = Path("results/hillclimb")
data = json.loads((root/"summary.json").read_text())
data["validation"] = dict(
    c17_werror=True, analyzer_tests=15, lease_identity_tests=2,
    hc_cpu_oracle_cases=12, hc_max_normalized_error=6.70552e-8,
    state_retain_fixtures=24, localhost_ring_configurations=8,
    route_replay_shape=dict(old_guard_failure_reproduced=True,
                            corrected_guard_passes=True,
                            recording_callback_skipped=True,
                            cached_route_ids_equal=True),
    local_compiled_source_inputs_authenticated=716,
)
data["source_inputs_manifest_sha256"] = hashlib.sha256(
    (root/"closing/close-source.sha256").read_bytes()).hexdigest()
files = [(root/name, "raw/"+name) for name in
         ("hc-ab-evidence.tar.gz", "dense-ab-evidence.tar.gz",
          "rejected-kernel-sources.tar.gz", "final-evidence.tar.gz",
          "close-evidence.tar.gz", "release.log")]
files += [(root/name, "scripts/"+name) for name in
          ("pack.py", "bootstrap.sh", "build.sh", "hc-ab.sh", "hc-resume.sh",
           "dense-ab.sh", "final.sh", "close.sh", "retain.sh", "release.sh",
           "summarize.py", "seal.py")]
changed = subprocess.check_output(
    ["git", "diff", "--name-only", "HEAD"], text=True).splitlines()
new = subprocess.check_output(
    ["git", "ls-files", "--others", "--exclude-standard"], text=True).splitlines()
for name in sorted(set(changed+new)):
    path = Path(name)
    if name.startswith(("src/", "include/", "shaders/", "tests/", "tools/")) or name == "Makefile":
        files.append((path, "selected-source/"+name))
archive = output/"mtp-union-kernels-evidence.tar.gz"
with tarfile.open(archive, "w:gz") as tar:
    for path, name in files:
        info = tar.gettarinfo(path, name)
        info.mtime = 0
        with path.open("rb") as source:
            tar.addfile(info, source)
    content = (json.dumps(data, indent=2)+"\n").encode()
    info = tarfile.TarInfo("analysis.json")
    info.size = len(content)
    tar.addfile(info, io.BytesIO(content))
data["evidence"] = dict(path=archive.name, bytes=archive.stat().st_size,
                        sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(output/"mtp-union-kernels.json").write_text(json.dumps(data, indent=2)+"\n")
print(json.dumps(data["evidence"]))
