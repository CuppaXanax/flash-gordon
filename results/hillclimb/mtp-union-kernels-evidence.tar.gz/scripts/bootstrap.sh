set -eu
test ! -d /home/xander/hc-mtp/block
test ! -d /home/xander/hc-mtp/goodput
test ! -d /home/xander/hc-mtp/op-floor
mkdir -p /home/xander/hc-mtp/op-floor
cd /home/xander/hc-mtp/op-floor
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > governor.sha256
printf 'OP_FLOOR_RESERVED_51\n'
