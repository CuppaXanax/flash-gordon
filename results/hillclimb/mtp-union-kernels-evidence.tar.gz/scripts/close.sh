set -eu
cd /home/xander/hc-mtp/op-floor/source-final
export TMPDIR="$PWD/../cache" XDG_CACHE_HOME="$PWD/../cache"
tar -xf ../close.tar
touch src/expert.c
make -j12 flash-gordon tools/bench-decode-fusion test-mtp-capture > ../close-build.log 2>&1
python3 -m unittest discover -s tools -p 'test_analyze_mtp*.py' > ../close-analyzer.log 2>&1
python3 -m unittest discover -s tests -p 'test_mtp_lease_identity.py' > ../close-lease-tests.log 2>&1
bash -n tools/mtp-lease-guard.sh
bash tools/check-flags.sh > ../close-flags.log
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
run(){
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
cp src/expert.c ../expert-final.c
python3 - <<'PY'
from pathlib import Path
p=Path("src/expert.c");s=p.read_text()
old="tokens>executor->max_tokens||!executor->route_tokens[layer]"
assert s.count(old)==1
p.write_text(s.replace(old,"tokens!=executor->route_tokens[layer]"))
PY
diff -u ../expert-final.c src/expert.c > ../negative-guard.patch || test "$?" -eq 1
make -j12 tools/bench-decode-fusion > ../negative-build.log 2>&1
set +e
run --q4 --mixed-experts --small-n --batch 4 --small-test --allow-reassociation \
    --routing-trace ../negative-synthetic-routes.jsonl --warmup 8 --iterations 8 --windows 1 \
    --no-clocks > ../negative-block.jsonl 2> ../negative-block.log
rc=$?
set -e
test "$rc" -ne 0
grep -q 'routing trace layer/shape is unavailable' ../negative-block.log
grep -q '"small_causal_test","prefix_bit_exact":true' ../negative-block.jsonl
cp ../expert-final.c src/expert.c
touch src/expert.c
make -j12 flash-gordon tools/bench-decode-fusion > ../restored-build.log 2>&1
run --q4 --mixed-experts --small-n --batch 4 --small-test --allow-reassociation \
    --routing-trace ../restored-synthetic-routes.jsonl --warmup 8 --iterations 8 --windows 1 \
    --no-clocks > ../restored-block.jsonl 2> ../restored-block.log
for round in 1 2 3; do
    for mask in 131402 393546 131402; do
        export FG_SMALL_KERNELS=$mask
        tag=$(date +%s%N)
        for n in 1 4; do
            run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" \
                --iterations 1 --windows 1 --profile --allow-reassociation --no-clocks \
                > "../close-profile-$round-$mask-$tag-$n.jsonl" 2> "../close-profile-$round-$mask-$tag-$n.log"
        done
    done
done
sha256sum flash-gordon tools/bench-decode-fusion tests/test_fg_vk > ../close-binaries.sha256
find src include shaders tools tests -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' -o -name '*.glsl' -o -name '*.comp' -o -name '*.py' -o -name '*.sh' \) -print0 | sort -z | xargs -0 sha256sum > ../close-source.sha256
find vulkan -type f -name '*.spv' -print0 | sort -z | xargs -0 sha256sum > ../close-shaders.sha256
cd ..
tar -czf close-evidence.tar.gz close-*.log close-*.jsonl close-*.sha256 negative-*.log negative-*.jsonl negative-guard.patch restored-*.log restored-*.jsonl expert-final.c
tar -czf candidate-release.tar.gz -C source-final flash-gordon tools/bench-decode-fusion tests/test_fg_vk vulkan
printf 'OLD_GUARD_REPRODUCED_FINAL_GUARD_REPLAY_SHAPE_PASS\n'
