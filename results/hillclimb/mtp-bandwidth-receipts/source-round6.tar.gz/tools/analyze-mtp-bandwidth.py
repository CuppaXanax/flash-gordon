#!/usr/bin/env python3
"""Summarize paired stock-clock small-N research receipts."""
import argparse
import collections
import hashlib
import json
import math
import pathlib
import re
import statistics


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines()
            if line.startswith("{")]


def summary(values):
    mean = statistics.mean(values)
    ci = 2.776445105 * statistics.stdev(values) / math.sqrt(len(values)) if len(values) == 5 else None
    return {"mean": mean, "ci95_half": ci, "rounds": values}


def median(path):
    return statistics.median(r["wall_us"] for r in records(path) if r["kind"] == "sample")


def family(name):
    if "gate_up" in name:
        return "expert_gate_up"
    if "small_down" in name or "moe_decode_down" in name:
        return "expert_down"
    if any(s in name for s in ("dense", "reuse", "small_q4", "small_q5",
                               "small_iq4", "small_q8", "small_f32",
                               "small_index_bf16", "small_router_bf16")):
        return "dense"
    if "qsa" in name or "topk_reduce" in name:
        return "qsa"
    if "gdn_small" in name or "gdn_recurrent" in name:
        return "recurrence"
    return "other"


def analyze(directory):
    result = {"paired": {}, "profiles": {}}
    for kind in ("short", "long"):
        root = directory / ("paired-" + kind)
        groups = collections.defaultdict(list)
        for path in sorted(root.glob("r*-n*-b*-f*.jsonl")):
            match = re.fullmatch(r"r(\d+)-n(\d+)-b(\d+)-f(\d+)\.jsonl", path.name)
            round_, n, index, flags = map(int, match.groups())
            before = root / f"r{round_}-n{n}-a{index}-f330.jsonl"
            after = root / f"r{round_}-n{n}-a{index+1}-f330.jsonl"
            ref = (median(before) + median(after)) / 2
            base = (median(root / f"r{round_}-n1-before-f0.jsonl") +
                    median(root / f"r{round_}-n1-after-f0.jsonl")) / 2
            candidate = median(path)
            groups[(n, flags)].append({
                "round": round_, "baseline_us": ref, "candidate_us": candidate,
                "n1_us": base, "baseline_ratio": ref / base,
                "candidate_ratio": candidate / base,
                "reduction_percent": 100 * (1 - candidate / ref)})
        result["paired"][kind] = [
            {"n": n, "flags": flags, "samples": rows,
             **{key: summary([r[key] for r in rows])
                for key in ("baseline_us", "candidate_us", "n1_us",
                            "baseline_ratio", "candidate_ratio", "reduction_percent")}}
            for (n, flags), rows in sorted(groups.items())]
        profile_groups = collections.defaultdict(list)
        for path in sorted(root.glob("profile-r*-n*-f*.jsonl")):
            match = re.fullmatch(r"profile-r(\d+)-n(\d+)-f(\d+)\.jsonl", path.name)
            round_, n, flags = map(int, match.groups())
            times = collections.defaultdict(float)
            kernels = {}
            for row in records(path):
                if row["kind"] == "kernel":
                    times[family(row["name"])] += row["gpu_us"]
                    kernels[row["name"]] = row["gpu_us"]
            routes = root / f"routes-r{round_}-n{n}-f{flags}.jsonl"
            ids = collections.defaultdict(set)
            for row in records(routes):
                ids[row["layer"]].update(row["experts"])
            union = sum(len(value) for value in ids.values())
            weight_bytes = {"dense": 302110208,
                            "expert_gate_up": union * 2 * 921600,
                            "expert_down": union * 1228800}
            profile_groups[(n, flags)].append({
                "round": round_, "gpu_us": dict(times), "kernels": kernels,
                "expert_union_per_layer": {str(k): len(v) for k, v in ids.items()},
                "compulsory_weight_bytes": weight_bytes,
                "effective_weight_GBs": {k: v / times[k] / 1000
                                          for k, v in weight_bytes.items() if times[k]}})
        result["profiles"][kind] = [
            {"n": n, "flags": flags, "samples": rows,
             "gpu_us": {k: summary([r["gpu_us"].get(k, 0) for r in rows])
                        for k in sorted({k for r in rows for k in r["gpu_us"]})},
             "effective_weight_GBs": {
                 k: summary([r["effective_weight_GBs"][k] for r in rows])
                 for k in rows[0]["effective_weight_GBs"]}}
            for (n, flags), rows in sorted(profile_groups.items())]
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=pathlib.Path, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    args = parser.parse_args()
    report = {
        "scope": "Opt-in synthetic six-layer research; no real-model or serving promotion",
        "method": "Five seed-matched alternating candidate orders; each B bracketed by A=330; N1 bracket per round",
        "operating_point": "Stock dynamic governor, unchanged clocks/CU configuration",
        "roof_GBs": 450,
        "byte_metric": "Compulsory selected cooked-weight bytes, not measured bus traffic; activation/state traffic excluded",
        "blades": {name: analyze(args.input / name) for name in ("50", "53")},
    }
    report["archives"] = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(args.input.glob("*.tar.gz"))}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
