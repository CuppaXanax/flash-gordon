#extension GL_KHR_shader_subgroup_basic : require
#extension GL_KHR_shader_subgroup_arithmetic : require
#extension GL_EXT_shader_explicit_arithmetic_types_int32 : require
#extension GL_EXT_shader_explicit_arithmetic_types_int8 : require

layout(local_size_x=128,local_size_y=1,local_size_z=1)in;
layout(set=0,binding=0)readonly buffer Weights{uint wb[];};
layout(set=0,binding=0)readonly buffer WeightsVector{uvec4 wb4[];};
layout(set=0,binding=1)readonly buffer Input{vec4 x4[];};
layout(set=0,binding=2)writeonly buffer Output{float y[];};
#ifdef FG_SHARED_SWIGLU
layout(set=0,binding=3)readonly buffer UpWeights{uint uw[];};
layout(set=0,binding=3)readonly buffer UpWeightsVector{uvec4 uw4[];};
uint projection;
#define W(i) (projection==0u?wb[i]:uw[i])
#define W4(i) (projection==0u?wb4[i]:uw4[i])
#else
#define W(i) wb[i]
#define W4(i) wb4[i]
#endif
#ifdef FG_DENSE_ARGMAX
layout(set=0,binding=3)readonly buffer TokenIds{uint token_ids[];};
layout(set=0,binding=4)writeonly buffer BestIds{uint best_ids[];};
#endif
layout(push_constant)uniform Push{uint out_dim;uint n_tok;uint blocks;uint tile_bytes;float scale;}pc;
shared vec4 subgroup_sum0[64],subgroup_sum1[64];

void main(){
#ifdef FG_SHARED_SWIGLU
    vec4 gate0=vec4(0.0),gate1=vec4(0.0);
    for(projection=0u;projection<2u;projection++){
#endif
    uint local_id=gl_LocalInvocationID.x;
    uint cohort=local_id>>3u,cohort_lane=local_id&7u;
#ifdef FG_DENSE_STREAMS4
    uint first_row=(gl_WorkGroupID.x>>2u)*8u,token=gl_WorkGroupID.x&3u;
#else
    uint first_row=gl_WorkGroupID.x*8u,token=gl_WorkGroupID.y;
#endif
    if(first_row>=pc.out_dim||token>=pc.n_tok)return;
    uint tile_base=(first_row>>4u)*pc.tile_bytes,tile_row=first_row&15u;
    uint quant_offset=(16u*pc.blocks*2u+63u)&~63u;
    uvec4 rows0=uvec4(tile_row,tile_row+1u,tile_row+2u,tile_row+3u),rows1=rows0+4u;
    uvec4 quant_base0=tile_base+quant_offset+rows0*pc.blocks*32u,quant_base1=tile_base+quant_offset+rows1*pc.blocks*32u;
    uint input_base=token*pc.blocks*8u,cohorts=(pc.blocks+15u)/16u;
    vec4 accumulator0=vec4(0.0),accumulator1=vec4(0.0);
    for(uint group=0u;group<cohorts;group++){
        uint block=group*16u+cohort;bool live=block<pc.blocks;
        uint safe_block=live?block:(pc.blocks-1u);
        uint scale_word=(tile_base>>2u)+safe_block*8u+(tile_row>>1u);
        uvec4 scales=W4(scale_word>>2u);
        vec4 delta0=live?vec4(unpackHalf2x16(scales.x),unpackHalf2x16(scales.y)):vec4(0.0);
        vec4 delta1=live?vec4(unpackHalf2x16(scales.z),unpackHalf2x16(scales.w)):vec4(0.0);
        uint word_offset=safe_block*32u+cohort_lane*4u;
        uvec4 packed0=uvec4(W((quant_base0.x+word_offset)>>2u),W((quant_base0.y+word_offset)>>2u),W((quant_base0.z+word_offset)>>2u),W((quant_base0.w+word_offset)>>2u));
        uvec4 packed1=uvec4(W((quant_base1.x+word_offset)>>2u),W((quant_base1.y+word_offset)>>2u),W((quant_base1.z+word_offset)>>2u),W((quant_base1.w+word_offset)>>2u));
        vec4 input_value=live?x4[input_base+safe_block*8u+cohort_lane]:vec4(0.0);
        vec4 products0=vec4(dot(vec4(unpack8(int32_t(packed0.x))),input_value),dot(vec4(unpack8(int32_t(packed0.y))),input_value),dot(vec4(unpack8(int32_t(packed0.z))),input_value),dot(vec4(unpack8(int32_t(packed0.w))),input_value));
        vec4 products1=vec4(dot(vec4(unpack8(int32_t(packed1.x))),input_value),dot(vec4(unpack8(int32_t(packed1.y))),input_value),dot(vec4(unpack8(int32_t(packed1.z))),input_value),dot(vec4(unpack8(int32_t(packed1.w))),input_value));
        accumulator0=fma(delta0,products0,accumulator0);accumulator1=fma(delta1,products1,accumulator1);
    }
    vec4 reduced0=vec4(subgroupAdd(accumulator0.x),subgroupAdd(accumulator0.y),subgroupAdd(accumulator0.z),subgroupAdd(accumulator0.w));
    vec4 reduced1=vec4(subgroupAdd(accumulator1.x),subgroupAdd(accumulator1.y),subgroupAdd(accumulator1.z),subgroupAdd(accumulator1.w));
    if(subgroupElect()){subgroup_sum0[gl_SubgroupID]=reduced0;subgroup_sum1[gl_SubgroupID]=reduced1;}
    barrier();
    if(local_id==0u){
        vec4 total0=vec4(0.0),total1=vec4(0.0);
        for(uint subgroup=0u;subgroup<gl_NumSubgroups;subgroup++){total0+=subgroup_sum0[subgroup];total1+=subgroup_sum1[subgroup];}
#ifdef FG_SHARED_SWIGLU
        total0*=pc.scale;total1*=pc.scale;
        if(projection==0u){gate0=total0;gate1=total1;}
        else for(uint row=0u;row<4u;row++){
            y[first_row+row]=(gate0[row]/(1.0+exp(-gate0[row])))*total0[row];
            y[first_row+4u+row]=(gate1[row]/(1.0+exp(-gate1[row])))*total1[row];
        }
#elif defined(FG_DENSE_ARGMAX)
        float best=uintBitsToFloat(0xff800000u);uint best_id=0xffffffffu;bool invalid=false;
        for(uint row=0u;row<8u;row++){
            if(first_row+row>=pc.out_dim)break;
            float score=(row<4u?total0[row&3u]:total1[row&3u])*pc.scale;
            uint id=token_ids[first_row+row];invalid=invalid||isnan(score)||isinf(score);
            if(score>best||(score==best&&id<best_id)){best=score;best_id=id;}
        }
        y[gl_WorkGroupID.x]=invalid?uintBitsToFloat(0x7f800000u):best;
        best_ids[gl_WorkGroupID.x]=invalid?token_ids[first_row]:best_id;
#else
        for(uint row=0u;row<4u;row++){
            y[token*pc.out_dim+first_row+row]=total0[row]*pc.scale;
            y[token*pc.out_dim+first_row+4u+row]=total1[row]*pc.scale;
        }
#endif
    }
#ifdef FG_SHARED_SWIGLU
    barrier();
    }
#endif
}
