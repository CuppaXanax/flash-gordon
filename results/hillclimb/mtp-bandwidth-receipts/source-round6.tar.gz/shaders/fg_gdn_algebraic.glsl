layout(local_size_x=128,local_size_y=1,local_size_z=1)in;
layout(set=0,binding=0)readonly buffer QKV{float qkv[];};
layout(set=0,binding=1)readonly buffer ZGate{float z[];};
layout(set=0,binding=2)readonly buffer Alpha{float alpha[];};
layout(set=0,binding=3)readonly buffer Beta{float beta[];};
layout(set=0,binding=4)readonly buffer ADecay{float a_decay[];};
layout(set=0,binding=5)readonly buffer DtBias{float dt_bias[];};
layout(set=0,binding=6)readonly buffer NormWeight{float norm_weight[];};
layout(set=0,binding=7)buffer RecurrentState{float recurrent[];};
layout(set=0,binding=8)writeonly buffer Output{float output_value[];};
#ifdef SMALL_N
layout(push_constant)uniform Push{uint value_heads;uint key_heads;uint head_dim;uint tokens;float epsilon;}pc;
#else
layout(push_constant)uniform Push{uint value_heads;uint key_heads;uint head_dim;float epsilon;}pc;
#endif
shared float query[128],key[128],delta[128],attention[128],sum_q[128],sum_k[128],dot_qk[128],sum_out[128];
float softplus(float value){return max(value,0.0)+log(1.0+exp(-abs(value)));}
void main(){
    uint lane=gl_LocalInvocationID.x,head=gl_WorkGroupID.x;
    if(head>=pc.value_heads||lane>=pc.head_dim)return;
    uint key_head=head%pc.key_heads,key_width=pc.key_heads*pc.head_dim,value_base=2u*key_width;
#ifdef SMALL_N
    for(uint token=0u;token<pc.tokens;token++){
    uint qbase=token*(value_base+pc.value_heads*pc.head_dim),
        zbase=token*pc.value_heads*pc.head_dim,hbase=token*pc.value_heads;
#else
    uint qbase=0u,zbase=0u,hbase=0u;
#endif
    query[lane]=qkv[qbase+key_head*pc.head_dim+lane];key[lane]=qkv[qbase+key_width+key_head*pc.head_dim+lane];
    float value=qkv[qbase+value_base+head*pc.head_dim+lane];sum_q[lane]=query[lane]*query[lane];sum_k[lane]=key[lane]*key[lane];
    barrier();
    for(uint stride=64u;stride>0u;stride>>=1u){if(lane<stride){sum_q[lane]+=sum_q[lane+stride];sum_k[lane]+=sum_k[lane+stride];}barrier();}
    float qscale=inversesqrt(sum_q[0]+pc.epsilon)/sqrt(float(pc.head_dim)),kscale=inversesqrt(sum_k[0]+pc.epsilon);
    query[lane]*=qscale;key[lane]*=kscale;dot_qk[lane]=query[lane]*key[lane];
    barrier();
    for(uint stride=64u;stride>0u;stride>>=1u){if(lane<stride)dot_qk[lane]+=dot_qk[lane+stride];barrier();}
    float decay=exp(a_decay[head]*softplus(alpha[hbase+head]+dt_bias[head])),mix=1.0/(1.0+exp(-beta[hbase+head]));
    uint state_base=head*pc.head_dim*pc.head_dim;
    float memory=0.0,prior_result=0.0;
    uint index=0u;
    for(;index+8u<=pc.head_dim;index+=8u){
        uint base0=state_base+index*pc.head_dim+lane,stride=pc.head_dim;
        float old0=recurrent[base0],old1=recurrent[base0+stride],old2=recurrent[base0+2u*stride],old3=recurrent[base0+3u*stride];
        float old4=recurrent[base0+4u*stride],old5=recurrent[base0+5u*stride],old6=recurrent[base0+6u*stride],old7=recurrent[base0+7u*stride];
        float d0=old0*decay,d1=old1*decay,d2=old2*decay,d3=old3*decay,d4=old4*decay,d5=old5*decay,d6=old6*decay,d7=old7*decay;
        memory=fma(d0,key[index],memory);memory=fma(d1,key[index+1u],memory);memory=fma(d2,key[index+2u],memory);memory=fma(d3,key[index+3u],memory);
        memory=fma(d4,key[index+4u],memory);memory=fma(d5,key[index+5u],memory);memory=fma(d6,key[index+6u],memory);memory=fma(d7,key[index+7u],memory);
        prior_result=fma(d0,query[index],prior_result);prior_result=fma(d1,query[index+1u],prior_result);prior_result=fma(d2,query[index+2u],prior_result);prior_result=fma(d3,query[index+3u],prior_result);
        prior_result=fma(d4,query[index+4u],prior_result);prior_result=fma(d5,query[index+5u],prior_result);prior_result=fma(d6,query[index+6u],prior_result);prior_result=fma(d7,query[index+7u],prior_result);
    }
    for(;index+4u<=pc.head_dim;index+=4u){
        uint base0=state_base+index*pc.head_dim+lane,stride=pc.head_dim;
        float old0=recurrent[base0],old1=recurrent[base0+stride],old2=recurrent[base0+2u*stride],old3=recurrent[base0+3u*stride];
        float decayed0=old0*decay,decayed1=old1*decay,decayed2=old2*decay,decayed3=old3*decay;
        memory=fma(decayed0,key[index],memory);memory=fma(decayed1,key[index+1u],memory);memory=fma(decayed2,key[index+2u],memory);memory=fma(decayed3,key[index+3u],memory);
        prior_result=fma(decayed0,query[index],prior_result);prior_result=fma(decayed1,query[index+1u],prior_result);prior_result=fma(decayed2,query[index+2u],prior_result);prior_result=fma(decayed3,query[index+3u],prior_result);
    }
    for(;index<pc.head_dim;index++){float old=recurrent[state_base+index*pc.head_dim+lane],decayed=old*decay;memory=fma(decayed,key[index],memory);prior_result=fma(decayed,query[index],prior_result);}
    delta[lane]=(value-memory)*mix;
    barrier();
    index=0u;
    for(;index+8u<=pc.head_dim;index+=8u){
        uint base0=state_base+index*pc.head_dim+lane,stride=pc.head_dim;
        float old0=recurrent[base0],old1=recurrent[base0+stride],old2=recurrent[base0+2u*stride],old3=recurrent[base0+3u*stride];
        float old4=recurrent[base0+4u*stride],old5=recurrent[base0+5u*stride],old6=recurrent[base0+6u*stride],old7=recurrent[base0+7u*stride];
        recurrent[base0]=old0*decay+key[index]*delta[lane];
        recurrent[base0+stride]=old1*decay+key[index+1u]*delta[lane];
        recurrent[base0+2u*stride]=old2*decay+key[index+2u]*delta[lane];
        recurrent[base0+3u*stride]=old3*decay+key[index+3u]*delta[lane];
        recurrent[base0+4u*stride]=old4*decay+key[index+4u]*delta[lane];
        recurrent[base0+5u*stride]=old5*decay+key[index+5u]*delta[lane];
        recurrent[base0+6u*stride]=old6*decay+key[index+6u]*delta[lane];
        recurrent[base0+7u*stride]=old7*decay+key[index+7u]*delta[lane];
    }
    for(;index+4u<=pc.head_dim;index+=4u){
        uint base0=state_base+index*pc.head_dim+lane,stride=pc.head_dim;
        float old0=recurrent[base0],old1=recurrent[base0+stride],old2=recurrent[base0+2u*stride],old3=recurrent[base0+3u*stride];
        recurrent[base0]=old0*decay+key[index]*delta[lane];
        recurrent[base0+stride]=old1*decay+key[index+1u]*delta[lane];
        recurrent[base0+2u*stride]=old2*decay+key[index+2u]*delta[lane];
        recurrent[base0+3u*stride]=old3*decay+key[index+3u]*delta[lane];
    }
    for(;index<pc.head_dim;index++){uint state_index=state_base+index*pc.head_dim+lane;recurrent[state_index]=recurrent[state_index]*decay+key[index]*delta[lane];}
    float result=fma(delta[lane],dot_qk[0],prior_result);attention[lane]=result;sum_out[lane]=result*result;
    barrier();
    for(uint stride=64u;stride>0u;stride>>=1u){if(lane<stride)sum_out[lane]+=sum_out[lane+stride];barrier();}
    float normalized=attention[lane]*inversesqrt(sum_out[0]/float(pc.head_dim)+pc.epsilon)*norm_weight[lane],gate=z[zbase+head*pc.head_dim+lane];
    output_value[zbase+head*pc.head_dim+lane]=normalized*(1.0/(1.0+exp(-gate)));
#ifdef SMALL_N
    barrier();
    }
#endif
}
