#extension GL_KHR_shader_subgroup_basic : require
#extension GL_KHR_shader_subgroup_arithmetic : require
/* Batch-1 decode split-K QSA attention, stage 1: the prefill batch geometry
 * adapted to a single query token.
 *
 * One workgroup owns (kv head, split) and its 768 threads form up to 24
 * subgroups; subgroup s < 12 owns query head kv_head*12+s, so the twelve heads
 * that share a KV head reuse one shared-memory copy of the decoded key/value
 * records instead of re-decoding them per head (the old per-head kernel
 * decoded each record 12x).  Eight records are decoded from q8_0 to fp32 in
 * shared memory per tile by the whole workgroup; the online softmax then runs
 * entirely inside a subgroup, so the only barriers are the two staging
 * barriers per tile.  The selected count and split count arrive as push
 * constants, so the decode path needs no host-written count tensor.
 *
 * Lane ownership inside a subgroup is strided vec4 blocks
 *   { lane + i*subgroup_size | i < 64/subgroup_size }
 * which covers the 256-wide head for any subgroup size 8/16/32/64.  The
 * 64-lane path (BC-250 RADV default) keeps the accumulators in registers;
 * smaller subgroup sizes (lavapipe reports 8) take a dynamic-index path.
 *
 * Layout per (head, split) is unchanged from fg_qsa_attention_split:
 *   partials[(head*splits+split)*258 + 0..255] = weighted values
 *   partials[... + 256] = running maximum
 *   partials[... + 257] = running denominator */

#ifndef HEADS_PER_WG
#define HEADS_PER_WG 12u
#endif
layout(local_size_x=HEADS_PER_WG*64u,local_size_y=1,local_size_z=1)in;
layout(set=0,binding=0)readonly buffer Records{uint records[];};
layout(set=0,binding=1)readonly buffer Query{vec4 query4[];};
layout(set=0,binding=2)buffer Partials{float partials[];};
layout(push_constant)uniform Push{uint selected_count;uint splits;}pc;

const uint RECORD_BYTES=1236u;
const uint TILE=8u;
const uint TILE_GROUPS=TILE*128u;
const uint HEADS_PER_KV=12u;
const float L2E=1.4426950408889634;
const float NEG_INF=-3.402823466e38;

shared vec4 key_tile[TILE*64u];
shared vec4 value_tile[TILE*64u];
shared vec4 query_tile[HEADS_PER_WG*64u];

/* Decode one vec4 of q8_0 data (4 consecutive quantized elements).  The q8
 * block scale is the half at the block start; the four bytes may straddle two
 * words because 34-byte blocks alternate 2/0 mod 4. */
void decode_group(uint group,uint tile_token,uint kv_head,uint end_token){
    uint record=group>>7u;
    uint within=group&127u;
    uint slot=within&63u;
    uint block=slot>>3u;
    uint sub=slot&7u;
    uint token=tile_token+record;
    vec4 decoded=vec4(0.0);
    if(token<end_token){
        uint base=token*RECORD_BYTES;
        uint offset=(within<64u?0u:544u)+kv_head*272u+block*34u;
        uint scale_at=base+offset;
        uint packed_at=scale_at+2u+sub*4u;
        uint lo=records[packed_at>>2u];
        uint hi=records[(packed_at>>2u)+1u];
        uint shift=(packed_at&3u)*8u;
        uint packed=(lo>>shift)|((hi<<((32u-shift)&31u))&(shift==0u?0u:0xffffffffu));
        float scale=unpackHalf2x16(records[scale_at>>2u]>>((scale_at&3u)*8u)).x;
        decoded=unpackSnorm4x8(packed)*(scale*127.0);
    }
    if(within<64u)key_tile[record*64u+slot]=decoded;
    else value_tile[record*64u+slot]=decoded;
}

void main(){
    uint head_groups=HEADS_PER_KV/HEADS_PER_WG;
    uint kv_head=gl_WorkGroupID.x/head_groups,split=gl_WorkGroupID.y;
    uint first_head=(gl_WorkGroupID.x%head_groups)*HEADS_PER_WG;
    if(kv_head>=2u||pc.splits==0u||split>=pc.splits||pc.selected_count==0u)return;
    uint local=gl_LocalInvocationIndex;
    uint subgroup=gl_SubgroupID,lane=gl_SubgroupInvocationID,lanes=gl_SubgroupSize;
    bool owns_head=subgroup<HEADS_PER_WG;
    /* The twelve query heads of this KV head are a straight one-to-one copy
     * out of the 6144-wide decode query. */
    query_tile[local]=query4[(kv_head*HEADS_PER_KV+first_head)*64u+local];
    uint begin=(pc.selected_count*split)/pc.splits;
    uint end=(pc.selected_count*(split+1u))/pc.splits;
    uint head=kv_head*HEADS_PER_KV+first_head+subgroup;
    uint partial_base=(head*pc.splits+split)*258u;
    barrier();

    float running_max=NEG_INF,running_den=0.0;
    if(lanes==64u){
        /* BC-250 / RADV wave64: one vec4 of the head per lane, query row and
         * all state in registers, scores unrolled so no local array is needed. */
        vec4 accumulator=vec4(0.0);
        vec4 query_value=query_tile[subgroup*64u+lane];
        for(uint tile=begin;tile<end;tile+=TILE){
            uint span=end-tile;if(span>TILE)span=TILE;
            barrier();
            for(uint group=local;group<TILE_GROUPS;group+=HEADS_PER_WG*64u)
                decode_group(group,tile,kv_head,end);
            barrier();
            if(owns_head){
                float s0=NEG_INF,s1=NEG_INF,s2=NEG_INF,s3=NEG_INF;
                float s4=NEG_INF,s5=NEG_INF,s6=NEG_INF,s7=NEG_INF;
                if(0u<span)s0=subgroupAdd(dot(query_value,key_tile[0u*64u+lane]))*0.0625;
                if(1u<span)s1=subgroupAdd(dot(query_value,key_tile[1u*64u+lane]))*0.0625;
                if(2u<span)s2=subgroupAdd(dot(query_value,key_tile[2u*64u+lane]))*0.0625;
                if(3u<span)s3=subgroupAdd(dot(query_value,key_tile[3u*64u+lane]))*0.0625;
                if(4u<span)s4=subgroupAdd(dot(query_value,key_tile[4u*64u+lane]))*0.0625;
                if(5u<span)s5=subgroupAdd(dot(query_value,key_tile[5u*64u+lane]))*0.0625;
                if(6u<span)s6=subgroupAdd(dot(query_value,key_tile[6u*64u+lane]))*0.0625;
                if(7u<span)s7=subgroupAdd(dot(query_value,key_tile[7u*64u+lane]))*0.0625;
                float tile_max=max(max(max(s0,s1),max(s2,s3)),
                                   max(max(s4,s5),max(s6,s7)));
                float next_max=max(running_max,tile_max);
                float scale=running_max<-3.0e38?0.0:exp2((running_max-next_max)*L2E);
                accumulator*=scale;
                float denominator=running_den*scale;
                {
                    float weight=exp2((s0-next_max)*L2E);
                    denominator+=weight;
                    accumulator=fma(vec4(weight),value_tile[0u*64u+lane],accumulator);
                }
                {
                    float weight=exp2((s1-next_max)*L2E);
                    denominator+=weight;
                    accumulator=fma(vec4(weight),value_tile[1u*64u+lane],accumulator);
                }
                {
                    float weight=exp2((s2-next_max)*L2E);
                    denominator+=weight;
                    accumulator=fma(vec4(weight),value_tile[2u*64u+lane],accumulator);
                }
                {
                    float weight=exp2((s3-next_max)*L2E);
                    denominator+=weight;
                    accumulator=fma(vec4(weight),value_tile[3u*64u+lane],accumulator);
                }
                {
                    float weight=exp2((s4-next_max)*L2E);
                    denominator+=weight;
                    accumulator=fma(vec4(weight),value_tile[4u*64u+lane],accumulator);
                }
                {
                    float weight=exp2((s5-next_max)*L2E);
                    denominator+=weight;
                    accumulator=fma(vec4(weight),value_tile[5u*64u+lane],accumulator);
                }
                {
                    float weight=exp2((s6-next_max)*L2E);
                    denominator+=weight;
                    accumulator=fma(vec4(weight),value_tile[6u*64u+lane],accumulator);
                }
                {
                    float weight=exp2((s7-next_max)*L2E);
                    denominator+=weight;
                    accumulator=fma(vec4(weight),value_tile[7u*64u+lane],accumulator);
                }
                running_max=next_max;
                running_den=denominator;
            }
        }
        if(owns_head){
            partials[partial_base+4u*lane+0u]=accumulator.x;
            partials[partial_base+4u*lane+1u]=accumulator.y;
            partials[partial_base+4u*lane+2u]=accumulator.z;
            partials[partial_base+4u*lane+3u]=accumulator.w;
            if(lane==0u){
                partials[partial_base+256u]=running_max;
                partials[partial_base+257u]=running_den;
            }
        }
    }else{
        /* Generic subgroup size: lane owns several strided vec4 blocks;
         * dynamic loops keep the code size bounded. */
        uint v4=64u/lanes;
        uint query_row=subgroup*64u+lane;
        vec4 accumulator[8];
        for(uint i=0u;i<8u;i++)accumulator[i]=vec4(0.0);
        for(uint tile=begin;tile<end;tile+=TILE){
            uint span=end-tile;if(span>TILE)span=TILE;
            barrier();
            for(uint group=local;group<TILE_GROUPS;group+=HEADS_PER_WG*64u)
                decode_group(group,tile,kv_head,end);
            barrier();
            if(owns_head){
                float scores[TILE];
                float tile_max=NEG_INF;
                for(uint record=0u;record<TILE;record++){
                    float score=NEG_INF;
                    if(record<span){
                        float partial=0.0;
                        for(uint i=0u;i<v4;i++){
                            uint at=query_row+i*lanes;
                            partial+=dot(query_tile[at],key_tile[record*64u+lane+i*lanes]);
                        }
                        score=subgroupAdd(partial)*0.0625;
                    }
                    scores[record]=score;
                    tile_max=max(tile_max,score);
                }
                float next_max=max(running_max,tile_max);
                float scale=running_max<-3.0e38?0.0:exp2((running_max-next_max)*L2E);
                float denominator=running_den*scale;
                for(uint i=0u;i<v4;i++)accumulator[i]*=scale;
                for(uint record=0u;record<TILE;record++){
                    float weight=exp2((scores[record]-next_max)*L2E);
                    denominator+=weight;
                    for(uint i=0u;i<v4;i++)
                        accumulator[i]=fma(vec4(weight),value_tile[record*64u+lane+i*lanes],accumulator[i]);
                }
                running_max=next_max;
                running_den=denominator;
            }
        }
        if(owns_head){
            for(uint i=0u;i<v4;i++){
                uint at=4u*(lane+i*lanes);
                partials[partial_base+at+0u]=accumulator[i].x;
                partials[partial_base+at+1u]=accumulator[i].y;
                partials[partial_base+at+2u]=accumulator[i].z;
                partials[partial_base+at+3u]=accumulator[i].w;
            }
            if(lane==0u){
                partials[partial_base+256u]=running_max;
                partials[partial_base+257u]=running_den;
            }
        }
    }
}
