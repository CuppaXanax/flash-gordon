#include "fg_uring.h"

#ifdef __linux__
#include <errno.h>
#include <linux/io_uring.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <unistd.h>

struct fg_uring {
    int fd; fg_ring_class ring_class; uint32_t entries;
    void *sq_map,*cq_map;size_t sq_map_bytes,cq_map_bytes;struct io_uring_sqe *sqes;size_t sqes_bytes;
    unsigned *sq_head,*sq_tail,*sq_mask,*sq_entries,*sq_flags,*sq_dropped,*sq_array;
    unsigned *cq_head,*cq_tail,*cq_mask,*cq_entries,*cq_overflow;struct io_uring_cqe *cqes;
    uint32_t file_count;
    void *fixed_buffer;uint64_t fixed_buffer_bytes;bool buffer_registered;
};
static int uring_setup(unsigned entries,struct io_uring_params *p){return (int)syscall(__NR_io_uring_setup,entries,p);}
static int uring_enter(int fd,unsigned submit,unsigned wait,unsigned flags){return (int)syscall(__NR_io_uring_enter,fd,submit,wait,flags,NULL,0);}
static int uring_register(int fd,unsigned op,const void *arg,unsigned nr){return (int)syscall(__NR_io_uring_register,fd,op,arg,nr);}

fg_status fg_uring_create(fg_uring **out,fg_ring_class cls,uint32_t entries,fg_error *err){
    if(!out||entries<8){fg_error_set(err,FG_ERR_ARGUMENT,"io_uring requires at least 8 entries");return FG_ERR_ARGUMENT;}*out=NULL;fg_uring *r=calloc(1,sizeof(*r));if(!r){fg_error_set(err,FG_ERR_OOM,"allocate io_uring");return FG_ERR_OOM;}r->fd=-1;r->ring_class=cls;
    struct io_uring_params p={0};p.flags=IORING_SETUP_CLAMP;if(cls==FG_RING_FABRIC)p.flags|=IORING_SETUP_COOP_TASKRUN;
    r->fd=uring_setup(entries,&p);if(r->fd<0){fg_error_set(err,FG_ERR_UNAVAILABLE,"io_uring_setup: %s",strerror(errno));free(r);return FG_ERR_UNAVAILABLE;}r->entries=p.sq_entries;
    r->sq_map_bytes=p.sq_off.array+p.sq_entries*sizeof(unsigned);r->cq_map_bytes=p.cq_off.cqes+p.cq_entries*sizeof(struct io_uring_cqe);
    if(p.features&IORING_FEAT_SINGLE_MMAP){size_t n=r->sq_map_bytes>r->cq_map_bytes?r->sq_map_bytes:r->cq_map_bytes;r->sq_map=mmap(NULL,n,PROT_READ|PROT_WRITE,MAP_SHARED|MAP_POPULATE,r->fd,IORING_OFF_SQ_RING);r->cq_map=r->sq_map;r->sq_map_bytes=r->cq_map_bytes=n;}else{r->sq_map=mmap(NULL,r->sq_map_bytes,PROT_READ|PROT_WRITE,MAP_SHARED|MAP_POPULATE,r->fd,IORING_OFF_SQ_RING);r->cq_map=mmap(NULL,r->cq_map_bytes,PROT_READ|PROT_WRITE,MAP_SHARED|MAP_POPULATE,r->fd,IORING_OFF_CQ_RING);}
    r->sqes_bytes=p.sq_entries*sizeof(struct io_uring_sqe);r->sqes=mmap(NULL,r->sqes_bytes,PROT_READ|PROT_WRITE,MAP_SHARED|MAP_POPULATE,r->fd,IORING_OFF_SQES);
    if(r->sq_map==MAP_FAILED||r->cq_map==MAP_FAILED||r->sqes==MAP_FAILED){fg_error_set(err,FG_ERR_IO,"mmap io_uring: %s",strerror(errno));fg_uring_destroy(r);return FG_ERR_IO;}
#define SQP(field) (unsigned *)((char *)r->sq_map+p.sq_off.field)
    r->sq_head=SQP(head);r->sq_tail=SQP(tail);r->sq_mask=SQP(ring_mask);r->sq_entries=SQP(ring_entries);r->sq_flags=SQP(flags);r->sq_dropped=SQP(dropped);r->sq_array=SQP(array);
#undef SQP
#define CQP(field) (unsigned *)((char *)r->cq_map+p.cq_off.field)
    r->cq_head=CQP(head);r->cq_tail=CQP(tail);r->cq_mask=CQP(ring_mask);r->cq_entries=CQP(ring_entries);r->cq_overflow=CQP(overflow);r->cqes=(struct io_uring_cqe *)((char *)r->cq_map+p.cq_off.cqes);
#undef CQP
    int files[256];for(size_t i=0;i<256;i++)files[i]=-1;if(uring_register(r->fd,IORING_REGISTER_FILES,files,256)<0){fg_error_set(err,FG_ERR_UNAVAILABLE,"register fixed files: %s",strerror(errno));fg_uring_destroy(r);return FG_ERR_UNAVAILABLE;}*out=r;return FG_OK;
}
void fg_uring_destroy(fg_uring *r){if(!r)return;if(r->buffer_registered)uring_register(r->fd,IORING_UNREGISTER_BUFFERS,NULL,0);if(r->sqes&&r->sqes!=MAP_FAILED)munmap(r->sqes,r->sqes_bytes);if(r->sq_map&&r->sq_map!=MAP_FAILED)munmap(r->sq_map,r->sq_map_bytes);if(r->cq_map&&r->cq_map!=MAP_FAILED&&r->cq_map!=r->sq_map)munmap(r->cq_map,r->cq_map_bytes);if(r->fd>=0)close(r->fd);free(r);}
fg_status fg_uring_register_file(fg_uring *r,int fd,uint32_t *slot,fg_error *err){if(!r||fd<0||r->file_count>=256){fg_error_set(err,FG_ERR_LIMIT,"invalid or exhausted fixed-file table");return FG_ERR_LIMIT;}struct io_uring_files_update u={.offset=r->file_count,.fds=(uint64_t)(uintptr_t)&fd};if(uring_register(r->fd,IORING_REGISTER_FILES_UPDATE,&u,1)!=1){fg_error_set(err,FG_ERR_IO,"update fixed file: %s",strerror(errno));return FG_ERR_IO;}if(slot)*slot=r->file_count;r->file_count++;return FG_OK;}
fg_status fg_uring_register_buffer(fg_uring *r,void *buffer,uint64_t bytes,fg_error *err){if(!r||!buffer||!bytes||r->buffer_registered||bytes>SIZE_MAX){fg_error_set(err,FG_ERR_ARGUMENT,"invalid fixed-buffer registration");return FG_ERR_ARGUMENT;}struct iovec vector={.iov_base=buffer,.iov_len=(size_t)bytes};if(uring_register(r->fd,IORING_REGISTER_BUFFERS,&vector,1)!=0){fg_error_set(err,FG_ERR_UNAVAILABLE,"register fixed buffer: %s",strerror(errno));return FG_ERR_UNAVAILABLE;}r->fixed_buffer=buffer;r->fixed_buffer_bytes=bytes;r->buffer_registered=true;return FG_OK;}
static fg_status submit_once(fg_uring *r,uint8_t op,uint32_t slot,void *buffer,uint32_t bytes,uint64_t offset,int *completed,fg_error *err){
    if(!r||!buffer||!bytes||slot>=r->file_count){fg_error_set(err,FG_ERR_ARGUMENT,"invalid io_uring I/O request");return FG_ERR_ARGUMENT;}bool fixed_rw=op==IORING_OP_READ||op==IORING_OP_WRITE;if(fixed_rw){uintptr_t begin=(uintptr_t)r->fixed_buffer,address=(uintptr_t)buffer;uint64_t displacement=address>=begin?(uint64_t)(address-begin):UINT64_MAX;if(!r->buffer_registered||displacement>r->fixed_buffer_bytes||bytes>r->fixed_buffer_bytes-displacement){fg_error_set(err,FG_ERR_ARGUMENT,"direct I/O is outside the registered fixed buffer");return FG_ERR_ARGUMENT;}op=op==IORING_OP_READ?IORING_OP_READ_FIXED:IORING_OP_WRITE_FIXED;}unsigned tail=atomic_load_explicit((_Atomic unsigned *)r->sq_tail,memory_order_relaxed);unsigned head=atomic_load_explicit((_Atomic unsigned *)r->sq_head,memory_order_acquire);if(tail-head>=*r->sq_entries){fg_error_set(err,FG_ERR_LIMIT,"io_uring submission queue full");return FG_ERR_LIMIT;}unsigned index=tail&*r->sq_mask;struct io_uring_sqe *sqe=&r->sqes[index];memset(sqe,0,sizeof(*sqe));sqe->opcode=op;sqe->flags=IOSQE_FIXED_FILE;sqe->fd=(int)slot;sqe->addr=(uint64_t)(uintptr_t)buffer;sqe->len=bytes;sqe->off=offset;sqe->buf_index=0;sqe->user_data=((uint64_t)offset<<16)^bytes;r->sq_array[index]=index;atomic_store_explicit((_Atomic unsigned *)r->sq_tail,tail+1,memory_order_release);
    if(uring_enter(r->fd,1,1,IORING_ENTER_GETEVENTS)<0){fg_error_set(err,FG_ERR_IO,"io_uring_enter: %s",strerror(errno));return FG_ERR_IO;}unsigned cq_head=atomic_load_explicit((_Atomic unsigned *)r->cq_head,memory_order_acquire);while(cq_head==atomic_load_explicit((_Atomic unsigned *)r->cq_tail,memory_order_acquire)){if(uring_enter(r->fd,0,1,IORING_ENTER_GETEVENTS)<0){fg_error_set(err,FG_ERR_IO,"wait io_uring: %s",strerror(errno));return FG_ERR_IO;}}struct io_uring_cqe *cqe=&r->cqes[cq_head&*r->cq_mask];int result=cqe->res;atomic_store_explicit((_Atomic unsigned *)r->cq_head,cq_head+1,memory_order_release);if(result<0){fg_error_set(err,FG_ERR_IO,"io_uring operation: %s",strerror(-result));return FG_ERR_IO;}if(completed)*completed=result;return FG_OK;
}
static fg_status submit_rw(fg_uring *r,uint8_t op,uint32_t slot,void *b,uint32_t n,uint64_t off,fg_error *e){int done=0;fg_status rc=submit_once(r,op,slot,b,n,off,&done,e);if(rc==FG_OK&&(uint32_t)done!=n){fg_error_set(e,FG_ERR_IO,"short direct I/O: got %d of %u bytes",done,n);rc=FG_ERR_IO;}return rc;}
fg_status fg_uring_pread(fg_uring *r,uint32_t slot,void *b,uint32_t n,uint64_t off,fg_error *e){return submit_rw(r,IORING_OP_READ,slot,b,n,off,e);}
fg_status fg_uring_pread_batch_results(fg_uring *r,uint32_t slot,
                                       const fg_uring_read *reads,uint32_t count,
                                       int32_t *results,uint32_t result_capacity,
                                       fg_error *err){
    if(!r||slot>=r->file_count||!reads||!count||!results||
       result_capacity<count){
        fg_error_set(err,FG_ERR_ARGUMENT,"invalid io_uring read batch");
        return FG_ERR_ARGUMENT;
    }
    for(uint32_t i=0;i<count;i++){
        uintptr_t begin=(uintptr_t)r->fixed_buffer,address=(uintptr_t)reads[i].buffer;
        uint64_t displacement=address>=begin?(uint64_t)(address-begin):UINT64_MAX;
        if(!reads[i].buffer||!reads[i].bytes||!r->buffer_registered||
           displacement>r->fixed_buffer_bytes||
           reads[i].bytes>r->fixed_buffer_bytes-displacement){
            fg_error_set(err,FG_ERR_ARGUMENT,
                         "read batch item %u is outside the fixed buffer",i);
            return FG_ERR_ARGUMENT;
        }
        results[i]=INT32_MIN;
    }
    fg_status status=FG_OK;for(uint32_t base=0;base<count&&status==FG_OK;){uint32_t batch=count-base;if(batch>r->entries)batch=r->entries;unsigned tail=atomic_load_explicit((_Atomic unsigned *)r->sq_tail,memory_order_relaxed),head=atomic_load_explicit((_Atomic unsigned *)r->sq_head,memory_order_acquire);if(tail-head+batch>*r->sq_entries){fg_error_set(err,FG_ERR_LIMIT,"io_uring batch exceeds submission queue");status=FG_ERR_LIMIT;break;}for(uint32_t i=0;i<batch;i++){uint32_t request=base+i,index=(tail+i)&*r->sq_mask;struct io_uring_sqe *sqe=&r->sqes[index];memset(sqe,0,sizeof(*sqe));sqe->opcode=IORING_OP_READ_FIXED;sqe->flags=IOSQE_FIXED_FILE;sqe->fd=(int)slot;sqe->addr=(uint64_t)(uintptr_t)reads[request].buffer;sqe->len=reads[request].bytes;sqe->off=reads[request].offset;sqe->buf_index=0;sqe->user_data=(uint64_t)request+1u;r->sq_array[index]=index;}atomic_store_explicit((_Atomic unsigned *)r->sq_tail,tail+batch,memory_order_release);int submitted=uring_enter(r->fd,batch,batch,IORING_ENTER_GETEVENTS);if(submitted!=(int)batch){fg_error_set(err,FG_ERR_IO,"submit io_uring read batch: %s",submitted<0?strerror(errno):"partial submission");status=FG_ERR_IO;break;}uint32_t completed=0;while(completed<batch){unsigned cq_head=atomic_load_explicit((_Atomic unsigned *)r->cq_head,memory_order_acquire),cq_tail=atomic_load_explicit((_Atomic unsigned *)r->cq_tail,memory_order_acquire);if(cq_head==cq_tail){if(uring_enter(r->fd,0,1,IORING_ENTER_GETEVENTS)<0){fg_error_set(err,FG_ERR_IO,"wait io_uring read batch: %s",strerror(errno));status=FG_ERR_IO;break;}continue;}while(cq_head<cq_tail&&completed<batch){struct io_uring_cqe *cqe=&r->cqes[cq_head&*r->cq_mask];uint64_t tag=cqe->user_data;uint32_t request=tag?(uint32_t)(tag-1u):UINT32_MAX;if(request>=count)status=FG_ERR_FORMAT;else results[request]=cqe->res;cq_head++;completed++;}atomic_store_explicit((_Atomic unsigned *)r->cq_head,cq_head,memory_order_release);}if(status==FG_ERR_FORMAT)fg_error_set(err,status,"invalid io_uring completion tag");base+=batch;}
    return status;
}
fg_status fg_uring_pread_batch(fg_uring *r,uint32_t slot,const fg_uring_read *reads,uint32_t count,fg_error *err){
    if(!reads||!count){
        fg_error_set(err,FG_ERR_ARGUMENT,"invalid io_uring read batch");
        return FG_ERR_ARGUMENT;
    }
    for(uint32_t base=0;base<count;){
        int32_t results[256];
        uint32_t batch=count-base;
        if(batch>256u)batch=256u;
        fg_status status=fg_uring_pread_batch_results(
            r,slot,reads+base,batch,results,256u,err);
        if(status!=FG_OK)return status;
        for(uint32_t i=0;i<batch;i++){
            if(results[i]<0){
                fg_error_set(err,FG_ERR_IO,"io_uring read batch item %u: %s",
                             base+i,strerror(-results[i]));
                return FG_ERR_IO;
            }
            if((uint32_t)results[i]!=reads[base+i].bytes){
                fg_error_set(err,FG_ERR_IO,
                             "short read batch item %u: got %d of %u bytes",
                             base+i,results[i],reads[base+i].bytes);
                return FG_ERR_IO;
            }
        }
        base+=batch;
    }
    return FG_OK;
}
fg_status fg_uring_pwrite_batch(fg_uring *r,uint32_t slot,const fg_uring_read *writes,uint32_t count,fg_error *err){
    if(!r||slot>=r->file_count||!writes||!count){fg_error_set(err,FG_ERR_ARGUMENT,"invalid io_uring write batch");return FG_ERR_ARGUMENT;}int *results=malloc((size_t)count*sizeof(*results));if(!results){fg_error_set(err,FG_ERR_OOM,"allocate io_uring completion batch");return FG_ERR_OOM;}for(uint32_t i=0;i<count;i++){uintptr_t begin=(uintptr_t)r->fixed_buffer,address=(uintptr_t)writes[i].buffer;uint64_t displacement=address>=begin?(uint64_t)(address-begin):UINT64_MAX;if(!writes[i].buffer||!writes[i].bytes||!r->buffer_registered||displacement>r->fixed_buffer_bytes||writes[i].bytes>r->fixed_buffer_bytes-displacement){free(results);fg_error_set(err,FG_ERR_ARGUMENT,"write batch item %u is outside the fixed buffer",i);return FG_ERR_ARGUMENT;}results[i]=INT32_MIN;}
    fg_status status=FG_OK;for(uint32_t base=0;base<count&&status==FG_OK;){uint32_t batch=count-base;if(batch>r->entries)batch=r->entries;unsigned tail=atomic_load_explicit((_Atomic unsigned *)r->sq_tail,memory_order_relaxed),head=atomic_load_explicit((_Atomic unsigned *)r->sq_head,memory_order_acquire);if(tail-head+batch>*r->sq_entries){fg_error_set(err,FG_ERR_LIMIT,"io_uring batch exceeds submission queue");status=FG_ERR_LIMIT;break;}for(uint32_t i=0;i<batch;i++){uint32_t request=base+i,index=(tail+i)&*r->sq_mask;struct io_uring_sqe *sqe=&r->sqes[index];memset(sqe,0,sizeof(*sqe));sqe->opcode=IORING_OP_WRITE_FIXED;sqe->flags=IOSQE_FIXED_FILE;sqe->fd=(int)slot;sqe->addr=(uint64_t)(uintptr_t)writes[request].buffer;sqe->len=writes[request].bytes;sqe->off=writes[request].offset;sqe->buf_index=0;sqe->user_data=(uint64_t)request+1u;r->sq_array[index]=index;}atomic_store_explicit((_Atomic unsigned *)r->sq_tail,tail+batch,memory_order_release);if(uring_enter(r->fd,batch,batch,IORING_ENTER_GETEVENTS)<0){fg_error_set(err,FG_ERR_IO,"submit io_uring write batch: %s",strerror(errno));status=FG_ERR_IO;break;}uint32_t completed=0;while(completed<batch){unsigned cq_head=atomic_load_explicit((_Atomic unsigned *)r->cq_head,memory_order_acquire),cq_tail=atomic_load_explicit((_Atomic unsigned *)r->cq_tail,memory_order_acquire);if(cq_head==cq_tail){if(uring_enter(r->fd,0,1,IORING_ENTER_GETEVENTS)<0){fg_error_set(err,FG_ERR_IO,"wait io_uring write batch: %s",strerror(errno));status=FG_ERR_IO;break;}continue;}while(cq_head<cq_tail&&completed<batch){struct io_uring_cqe *cqe=&r->cqes[cq_head&*r->cq_mask];uint64_t tag=cqe->user_data;uint32_t request=tag?(uint32_t)(tag-1u):UINT32_MAX;if(request>=count)status=FG_ERR_FORMAT;else results[request]=cqe->res;cq_head++;completed++;}atomic_store_explicit((_Atomic unsigned *)r->cq_head,cq_head,memory_order_release);}if(status==FG_ERR_FORMAT)fg_error_set(err,status,"invalid io_uring completion tag");base+=batch;}
    for(uint32_t i=0;status==FG_OK&&i<count;i++){if(results[i]<0){fg_error_set(err,FG_ERR_IO,"io_uring write batch item %u: %s",i,strerror(-results[i]));status=FG_ERR_IO;}else if((uint32_t)results[i]!=writes[i].bytes){fg_error_set(err,FG_ERR_IO,"short write batch item %u: got %d of %u bytes",i,results[i],writes[i].bytes);status=FG_ERR_IO;}}free(results);return status;
}
fg_status fg_uring_pwrite(fg_uring *r,uint32_t slot,const void *b,uint32_t n,uint64_t off,fg_error *e){return submit_rw(r,IORING_OP_WRITE,slot,(void *)b,n,off,e);}
static fg_status socket_all(fg_uring *r,uint8_t op,uint32_t slot,void *b,uint32_t n,fg_error *e){uint32_t done=0;while(done<n){int one=0;fg_status rc=submit_once(r,op,slot,(uint8_t *)b+done,n-done,0,&one,e);if(rc!=FG_OK)return rc;if(one==0){fg_error_set(e,FG_ERR_IO,"peer closed fabric socket");return FG_ERR_IO;}done+=(uint32_t)one;}return FG_OK;}
fg_status fg_uring_send_all(fg_uring *r,uint32_t slot,const void *b,uint32_t n,fg_error *e){return socket_all(r,IORING_OP_SEND,slot,(void *)b,n,e);}
fg_status fg_uring_recv_all(fg_uring *r,uint32_t slot,void *b,uint32_t n,fg_error *e){return socket_all(r,IORING_OP_RECV,slot,b,n,e);}

fg_status fg_uring_prep_recv(fg_uring *r,uint32_t slot,void *buf,uint32_t bytes,uint64_t tag,fg_error *err){
    if(!r||!buf||!bytes||slot>=r->file_count){fg_error_set(err,FG_ERR_ARGUMENT,"invalid async recv arguments");return FG_ERR_ARGUMENT;}
    unsigned tail=atomic_load_explicit((_Atomic unsigned *)r->sq_tail,memory_order_relaxed);
    unsigned head=atomic_load_explicit((_Atomic unsigned *)r->sq_head,memory_order_acquire);
    if(tail-head>=*r->sq_entries){fg_error_set(err,FG_ERR_LIMIT,"SQ full in prep_recv");return FG_ERR_LIMIT;}
    unsigned index=tail&*r->sq_mask;
    struct io_uring_sqe *sqe=&r->sqes[index];
    memset(sqe,0,sizeof(*sqe));
    sqe->opcode=IORING_OP_RECV;
    sqe->flags=IOSQE_FIXED_FILE;
    sqe->fd=(int)slot;
    sqe->addr=(uint64_t)(uintptr_t)buf;
    sqe->len=bytes;
    sqe->msg_flags=MSG_WAITALL;
    sqe->user_data=tag;
    r->sq_array[index]=index;
    atomic_store_explicit((_Atomic unsigned *)r->sq_tail,tail+1,memory_order_release);
    return FG_OK;
}
fg_status fg_uring_prep_read(fg_uring *r,int fd,void *buf,uint32_t bytes,uint64_t offset,uint64_t tag,fg_error *err){
    if(!r||fd<0||!buf||!bytes){fg_error_set(err,FG_ERR_ARGUMENT,"invalid async read arguments");return FG_ERR_ARGUMENT;}
    unsigned tail=atomic_load_explicit((_Atomic unsigned *)r->sq_tail,memory_order_relaxed);
    unsigned head=atomic_load_explicit((_Atomic unsigned *)r->sq_head,memory_order_acquire);
    if(tail-head>=*r->sq_entries){fg_error_set(err,FG_ERR_LIMIT,"SQ full in prep_read");return FG_ERR_LIMIT;}
    unsigned index=tail&*r->sq_mask;
    struct io_uring_sqe *sqe=&r->sqes[index];
    memset(sqe,0,sizeof(*sqe));
    sqe->opcode=IORING_OP_READ;
    sqe->fd=fd;
    sqe->addr=(uint64_t)(uintptr_t)buf;
    sqe->len=bytes;
    sqe->off=offset;
    sqe->user_data=tag;
    r->sq_array[index]=index;
    atomic_store_explicit((_Atomic unsigned *)r->sq_tail,tail+1,memory_order_release);
    return FG_OK;
}
fg_status fg_uring_flush(fg_uring *r,uint32_t pending,fg_error *err){
    if(!r||!pending){fg_error_set(err,FG_ERR_ARGUMENT,"invalid flush arguments");return FG_ERR_ARGUMENT;}
    int submitted=uring_enter(r->fd,pending,0,0);
    if(submitted<0){fg_error_set(err,FG_ERR_IO,"io_uring flush: %s",strerror(errno));return FG_ERR_IO;}
    if((uint32_t)submitted!=pending){
        fg_error_set(err,FG_ERR_IO,"io_uring flush submitted %d of %u",submitted,pending);
        return FG_ERR_IO;
    }
    return FG_OK;
}
fg_status fg_uring_reap(fg_uring *r,uint32_t min_count,fg_uring_cqe *out,uint32_t capacity,uint32_t *completed,fg_error *err){
    if(!r||!min_count||!out||!capacity||capacity<min_count||!completed){fg_error_set(err,FG_ERR_ARGUMENT,"invalid reap arguments");return FG_ERR_ARGUMENT;}
    *completed=0;
    while(*completed<min_count){
        unsigned cq_head=atomic_load_explicit((_Atomic unsigned *)r->cq_head,memory_order_acquire);
        unsigned cq_tail=atomic_load_explicit((_Atomic unsigned *)r->cq_tail,memory_order_acquire);
        if(cq_head==cq_tail){
            if(uring_enter(r->fd,0,1,IORING_ENTER_GETEVENTS)<0){fg_error_set(err,FG_ERR_IO,"reap wait: %s",strerror(errno));return FG_ERR_IO;}
            continue;
        }
        while(cq_head<cq_tail&&*completed<capacity){
            struct io_uring_cqe *cqe=&r->cqes[cq_head&*r->cq_mask];
            out[*completed].tag=cqe->user_data;
            out[*completed].result=cqe->res;
            (*completed)++;
            cq_head++;
        }
        atomic_store_explicit((_Atomic unsigned *)r->cq_head,cq_head,memory_order_release);
    }
    return FG_OK;
}
fg_status fg_uring_peek(fg_uring *r,fg_uring_cqe *out,uint32_t capacity,uint32_t *completed,fg_error *err){
    if(!r||!out||!capacity||!completed){fg_error_set(err,FG_ERR_ARGUMENT,"invalid peek arguments");return FG_ERR_ARGUMENT;}
    *completed=0;
    unsigned cq_head=atomic_load_explicit((_Atomic unsigned *)r->cq_head,memory_order_acquire);
    unsigned cq_tail=atomic_load_explicit((_Atomic unsigned *)r->cq_tail,memory_order_acquire);
    while(cq_head<cq_tail&&*completed<capacity){
        struct io_uring_cqe *cqe=&r->cqes[cq_head&*r->cq_mask];
        out[*completed].tag=cqe->user_data;
        out[*completed].result=cqe->res;
        (*completed)++;
        cq_head++;
    }
    if(*completed)atomic_store_explicit((_Atomic unsigned *)r->cq_head,cq_head,memory_order_release);
    return FG_OK;
}
uint64_t fg_uring_host_bytes(const fg_uring *r){
    if(!r)return 0u;
    uint64_t bytes=sizeof(*r)+r->sqes_bytes;
    if(r->sq_map)bytes+=r->sq_map_bytes;
    if(r->cq_map&&r->cq_map!=r->sq_map)bytes+=r->cq_map_bytes;
    return bytes;
}
#else
struct fg_uring{int unavailable;};
fg_status fg_uring_create(fg_uring **out,fg_ring_class c,uint32_t n,fg_error *e){(void)out;(void)c;(void)n;fg_error_set(e,FG_ERR_UNAVAILABLE,"Flash Gordon requires Linux io_uring");return FG_ERR_UNAVAILABLE;}
void fg_uring_destroy(fg_uring *r){(void)r;}fg_status fg_uring_register_file(fg_uring*r,int f,uint32_t*s,fg_error*e){(void)r;(void)f;(void)s;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_register_buffer(fg_uring*r,void*b,uint64_t n,fg_error*e){(void)r;(void)b;(void)n;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_pread(fg_uring*r,uint32_t s,void*b,uint32_t n,uint64_t o,fg_error*e){(void)r;(void)s;(void)b;(void)n;(void)o;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_pread_batch(fg_uring*r,uint32_t s,const fg_uring_read*q,uint32_t n,fg_error*e){(void)r;(void)s;(void)q;(void)n;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_pwrite_batch(fg_uring*r,uint32_t s,const fg_uring_read*q,uint32_t n,fg_error*e){(void)r;(void)s;(void)q;(void)n;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_pwrite(fg_uring*r,uint32_t s,const void*b,uint32_t n,uint64_t o,fg_error*e){(void)r;(void)s;(void)b;(void)n;(void)o;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_send_all(fg_uring*r,uint32_t s,const void*b,uint32_t n,fg_error*e){(void)r;(void)s;(void)b;(void)n;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_recv_all(fg_uring*r,uint32_t s,void*b,uint32_t n,fg_error*e){(void)r;(void)s;(void)b;(void)n;return fg_uring_create(NULL,0,0,e);}
fg_status fg_uring_pread_batch_results(fg_uring*r,uint32_t s,const fg_uring_read*q,uint32_t n,int32_t*x,uint32_t c,fg_error*e){(void)r;(void)s;(void)q;(void)n;(void)x;(void)c;return fg_uring_create(NULL,0,0,e);}
fg_status fg_uring_prep_recv(fg_uring*r,uint32_t s,void*b,uint32_t n,uint64_t t,fg_error*e){(void)r;(void)s;(void)b;(void)n;(void)t;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_prep_read(fg_uring*r,int f,void*b,uint32_t n,uint64_t o,uint64_t t,fg_error*e){(void)r;(void)f;(void)b;(void)n;(void)o;(void)t;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_flush(fg_uring*r,uint32_t n,fg_error*e){(void)r;(void)n;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_reap(fg_uring*r,uint32_t m,fg_uring_cqe*o,uint32_t c,uint32_t*d,fg_error*e){(void)r;(void)m;(void)o;(void)c;(void)d;return fg_uring_create(NULL,0,0,e);}fg_status fg_uring_peek(fg_uring*r,fg_uring_cqe*o,uint32_t c,uint32_t*d,fg_error*e){(void)r;(void)o;(void)c;(void)d;return fg_uring_create(NULL,0,0,e);}
uint64_t fg_uring_host_bytes(const fg_uring*r){(void)r;return 0u;}
#endif
