#ifndef FLASH_GORDON_VK_H
#define FLASH_GORDON_VK_H

#include "fg.h"

typedef struct fg_vk_context fg_vk_context;
typedef struct fg_vk_tensor fg_vk_tensor;
typedef struct fg_vk_expert_graph fg_vk_expert_graph;

#define FG_VK_PREFILL_PAIR_TILE 4u
#define FG_VK_PREFILL_TILE_WORDS (1u+FG_VK_PREFILL_PAIR_TILE)
#define FG_VK_PREFILL_ROW_TILE 32u
#define FG_VK_GDN_CHUNKED_PREFILL_MAX_TOKENS 256u
#define FG_VK_GDN_CHUNKED_PREFILL_DISPATCHES 3u

typedef enum fg_vk_tensor_format {
    FG_VK_TENSOR_FORMAT_DEFAULT = 0,
    FG_VK_TENSOR_FORMAT_Q8_0_COOKED = 1,
    FG_VK_TENSOR_FORMAT_K_QUANT_EXPERT_COOKED = 2,
    FG_VK_TENSOR_FORMAT_Q5_1_EXPERT_COOKED = 3,
    FG_VK_TENSOR_FORMAT_Q8_0_EXPERT_COOKED = 4,
    FG_VK_TENSOR_FORMAT_Q4_K = 5,
    FG_VK_TENSOR_FORMAT_Q5_K = 6,
    FG_VK_TENSOR_FORMAT_Q6_K = 7,
    FG_VK_TENSOR_FORMAT_IQ4_NL = 8,
    FG_VK_TENSOR_FORMAT_DENSE_Q4_K_COOKED = 9,
    FG_VK_TENSOR_FORMAT_DENSE_Q5_K_COOKED = 10,
    FG_VK_TENSOR_FORMAT_BF16_ROUTER = 11,
    FG_VK_TENSOR_FORMAT_DENSE_SOA_Q4_K = 12,
    FG_VK_TENSOR_FORMAT_DENSE_SOA_Q5_K = 13,
    FG_VK_TENSOR_FORMAT_DENSE_SOA_IQ4_NL = 14,
    FG_VK_TENSOR_FORMAT_DENSE_COMPACT_Q4_K = 15,
    FG_VK_TENSOR_FORMAT_DENSE_COMPACT_Q5_K = 16,
    FG_VK_TENSOR_FORMAT_DENSE_COMPACT_IQ4_NL = 17
} fg_vk_tensor_format;

fg_vk_tensor_format fg_vk_dense_format(uint32_t ggml_type);
fg_vk_tensor_format fg_vk_dense_saved_format(uint32_t ggml_type,uint32_t layout);
fg_status fg_vk_dense_quant(fg_vk_context *context,fg_vk_tensor *out,
                            const fg_vk_tensor *weights,const fg_vk_tensor *input,
                            uint32_t input_width,uint32_t output_width,
                            uint32_t tokens,float scale,fg_error *err);
fg_status fg_vk_mtp_vocab_q8(fg_vk_context *context,fg_vk_tensor *scores,
    fg_vk_tensor *best_ids,const fg_vk_tensor *weights,const fg_vk_tensor *hidden,
    const fg_vk_tensor *token_ids,uint32_t input_width,uint32_t rows,fg_error *err);
fg_status fg_vk_mtp_fc_hidden(fg_vk_context *context,fg_vk_tensor *output,
    const fg_vk_tensor *weights,const fg_vk_tensor *input,fg_error *err);
fg_status fg_vk_mtp_hc_norm(fg_vk_context *context,fg_vk_tensor *output,
    const fg_vk_tensor *input,const fg_vk_tensor *weights,fg_error *err);
fg_status fg_vk_mtp_attention_split(fg_vk_context *context,fg_vk_tensor *output,
    fg_vk_tensor *partials,fg_vk_tensor *keys,fg_vk_tensor *values,
    const fg_vk_tensor *query,const fg_vk_tensor *gate,const fg_vk_tensor *key,
    const fg_vk_tensor *value,const fg_vk_tensor *position,uint32_t capacity,
    uint32_t splits,fg_error *err);
fg_status fg_vk_mtp_attention_window(fg_vk_context *context,fg_vk_tensor *output,
    fg_vk_tensor *partials,fg_vk_tensor *keys,fg_vk_tensor *values,
    const fg_vk_tensor *query,const fg_vk_tensor *gate,const fg_vk_tensor *key,
    const fg_vk_tensor *value,const fg_vk_tensor *position,uint32_t capacity,
    uint32_t splits,uint32_t window,fg_error *err);
fg_status fg_vk_mtp_cache_kv(fg_vk_context *context,fg_vk_tensor *keys,
    fg_vk_tensor *values,const fg_vk_tensor *raw_key,const fg_vk_tensor *raw_value,
    const fg_vk_tensor *key_norm,const fg_vk_tensor *position,uint32_t capacity,
    fg_error *err);

#define FG_VK_PROFILE_MAX_KERNELS 64u
/* Pre-recorded token-invariant runs; each slot owns a private descriptor set
 * window so a dynamic epoch reset can never rewrite its bindings. */
#define FG_VK_OWNER_STATIC_SLOTS 8u
#define FG_VK_MTP_STATIC_SLOT FG_VK_OWNER_STATIC_SLOTS
#define FG_VK_MTP_VOCAB_STATIC_SLOT (FG_VK_OWNER_STATIC_SLOTS+1u)
#define FG_VK_STATIC_SLOTS (FG_VK_OWNER_STATIC_SLOTS+4u)
/* Explicit research path; ordinary decode and prefill remain unchanged. */
void fg_vk_small_n_mode(fg_vk_context *context,bool enabled);
/* Diagnostic geometry override, before creating any small-N pipeline.
 * Zero preserves the shape-selected default; IQ4 retains four output rows. */
fg_status fg_vk_small_n_tune(fg_vk_context *context,uint32_t workgroup,
    uint32_t rows,fg_error *err);
bool fg_vk_small_n_active(const fg_vk_context *context);
fg_status fg_vk_small_n_schedule(fg_vk_context *context,fg_vk_tensor *tiles,
    const fg_vk_tensor *selected,uint32_t tokens,fg_error *err);
fg_status fg_vk_small_n_experts(fg_vk_context *context,fg_vk_tensor *mid,fg_vk_tensor *down_parts,
    fg_vk_tensor *reduced,const fg_vk_tensor *gate,const fg_vk_tensor *up,
    const fg_vk_tensor *down,const fg_vk_tensor *activation,
    const fg_vk_tensor *tiles,const fg_vk_tensor *selected,const fg_vk_tensor *gates,
    uint32_t gate_stride,uint32_t up_stride,uint32_t down_stride,
    uint32_t gate_type,uint32_t up_type,uint32_t down_type,
    uint32_t tokens,fg_error *err);
fg_status fg_vk_small_n_q8_down(fg_vk_context *context,fg_vk_tensor *output,
    const fg_vk_tensor *weights,const fg_vk_tensor *selected,
    const fg_vk_tensor *input,const fg_vk_tensor *gates,uint32_t expert_stride,
    uint32_t tokens,fg_error *err);
fg_status fg_vk_small_n_shared(fg_vk_context *context,fg_vk_tensor *output,
    const fg_vk_tensor *experts,const fg_vk_tensor *shared,
    const fg_vk_tensor *scalar,uint32_t tokens,fg_error *err);

typedef struct fg_vk_profile_kernel {
    const char *scope;
    const char *name;
    uint64_t invocations;
    double gpu_ms;
} fg_vk_profile_kernel;

typedef struct fg_vk_profile {
    uint32_t kernel_count;
    uint64_t submissions;
    uint64_t dispatches;
    double gpu_ms;
    double kernel_ms;
    double wait_ms;
    double record_ms;
    double gap_ms;
    double gap_max_ms;
    uint64_t gap_count;
    const char *gap_max_kernel;
    double op_ms;
    double barrier_ms;
    double submit_ms;
    fg_vk_profile_kernel kernels[FG_VK_PROFILE_MAX_KERNELS];
} fg_vk_profile;

typedef struct fg_vk_counters {
    uint64_t submissions;
    uint64_t dispatches;
    uint64_t residency_canary_calls;
} fg_vk_counters;

typedef struct fg_vk_memory_stats {
    uint64_t requested_live_bytes;
    uint64_t allocated_live_bytes;
    uint64_t requested_peak_bytes;
    uint64_t allocated_peak_bytes;
    uint64_t allocation_count;
    uint64_t live_allocations;
} fg_vk_memory_stats;

fg_status fg_vk_open(fg_vk_context **out,fg_error *err);
void fg_vk_close(fg_vk_context *context);
const char *fg_vk_device_name(const fg_vk_context *context);
bool fg_vk_integer_dot_product_enabled(const fg_vk_context *context);
uint32_t fg_vk_active_compute_units(const fg_vk_context *context);
uint32_t fg_vk_subgroup_size(const fg_vk_context *context);
uint32_t fg_vk_hc_inject_pieces(const fg_vk_context *context);
bool fg_vk_hc_up_mix_supported(const fg_vk_context *context,const fg_vk_tensor *weights);
bool fg_vk_hc_down_inject_supported(const fg_vk_context *context,const fg_vk_tensor *weights);
bool fg_vk_gdn_gate_controls_supported(const fg_vk_context *context,const fg_vk_tensor *weights);
fg_status fg_vk_gdn_gate_controls(fg_vk_context *context,fg_vk_tensor *gate,
    fg_vk_tensor *alpha,fg_vk_tensor *beta,const fg_vk_tensor *weights,
    const fg_vk_tensor *alpha_weight,const fg_vk_tensor *beta_weight,
    const fg_vk_tensor *hidden,fg_error *err);
fg_status fg_vk_hc_down_inject(fg_vk_context *context,fg_vk_tensor *low,fg_vk_tensor *activated,
    fg_vk_tensor *partials,const fg_vk_tensor *weights,const fg_vk_tensor *input,
    const fg_vk_tensor *inject_weights,uint32_t pieces,fg_error *err);
fg_status fg_vk_hc_up_mix(fg_vk_context *context,fg_vk_tensor *mixed,fg_vk_tensor *injection,
    const fg_vk_tensor *weights,const fg_vk_tensor *input,const fg_vk_tensor *normalized,
    const fg_vk_tensor *partials,uint32_t input_width,uint32_t hidden,uint32_t pieces,fg_error *err);

fg_status fg_vk_profile_begin(fg_vk_context *context,fg_error *err);
fg_status fg_vk_profile_set_scope(fg_vk_context *context,const char *scope,fg_error *err);
fg_status fg_vk_profile_end(fg_vk_context *context,fg_vk_profile *profile,fg_error *err);
bool fg_vk_profile_active(const fg_vk_context *context);
void fg_vk_get_counters(const fg_vk_context *context,fg_vk_counters *counters);
void fg_vk_get_memory_stats(const fg_vk_context *context,fg_vk_memory_stats *stats);

#define FG_VK_LAYER_DISPATCHES 96u
typedef struct fg_vk_layer_dispatch {
    const char *name;
    uint32_t grid[3],push[32],push_words,bindings;
    uint64_t bytes[16];
    bool barrier;
} fg_vk_layer_dispatch;
typedef struct fg_vk_layer_sample {
    double gpu_us;
    uint32_t dispatch_count;
    fg_vk_layer_dispatch dispatches[FG_VK_LAYER_DISPATCHES];
} fg_vk_layer_sample;
/* Enable before recording static runs; query resets and two timestamps per
 * layer are replayed with the original command buffers. Read after draining. */
fg_status fg_vk_layer_clock_enable(fg_vk_context *context,fg_error *err);
fg_status fg_vk_layer_clock_mark(fg_vk_context *context,uint32_t layer,bool end,fg_error *err);
fg_status fg_vk_layer_clock_read(fg_vk_context *context,uint32_t layer,
                                  fg_vk_layer_sample *sample,fg_error *err);

/* FG_DECODE_FUSION bitmask: routing schedule, shared residual, shared SwiGLU. */
uint32_t fg_vk_decode_fusion_mask(void);
fg_status fg_vk_router_top10_tiles(fg_vk_context *context,fg_vk_tensor *selected,
    fg_vk_tensor *gates,fg_vk_tensor *tiles,const fg_vk_tensor *logits,fg_error *err);
fg_status fg_vk_moe_shared_gr_write(fg_vk_context *context,fg_vk_tensor *output,
    const fg_vk_tensor *hyper,const fg_vk_tensor *reduced,const fg_vk_tensor *shared,
    const fg_vk_tensor *scalar,const fg_vk_tensor *injection,fg_error *err);
bool fg_vk_shared_swiglu_supported(const fg_vk_tensor *gate,const fg_vk_tensor *up);
fg_status fg_vk_shared_swiglu(fg_vk_context *context,fg_vk_tensor *output,
    const fg_vk_tensor *gate,const fg_vk_tensor *up,const fg_vk_tensor *input,fg_error *err);

fg_status fg_vk_begin(fg_vk_context *context,fg_error *err);
fg_status fg_vk_end(fg_vk_context *context,fg_error *err);
fg_status fg_vk_flush(fg_vk_context *context,fg_error *err);
fg_status fg_vk_static_begin(fg_vk_context *context,uint32_t slot,fg_error *err);
fg_status fg_vk_static_claim(fg_vk_context *context,uint32_t slot,fg_error *err);
fg_status fg_vk_static_release(fg_vk_context *context,uint32_t slot,fg_error *err);
fg_status fg_vk_static_end(fg_vk_context *context,uint32_t slot,fg_error *err);
fg_status fg_vk_static_reset(fg_vk_context *context,uint32_t slot,fg_error *err);
fg_status fg_vk_static_submit(fg_vk_context *context,uint32_t slot,fg_error *err);
/* Stage stable graph inputs and execute the graph with one submission/fence. */
fg_status fg_vk_static_copy_run(fg_vk_context *context,uint32_t slot,
    fg_vk_tensor *const *dst,const fg_vk_tensor *const *src,uint32_t count,fg_error *err);
fg_status fg_vk_static_wait(fg_vk_context *context,uint32_t slot,fg_error *err);
fg_status fg_vk_static_drain(fg_vk_context *context,fg_error *err);
bool fg_vk_static_recorded(const fg_vk_context *context,uint32_t slot);
/* Opt-in submission scope: flush records ahead, end/readback still waits.
 * Mapped inputs must remain immutable until end; use ordered writes for
 * mutable per-dispatch inputs shared by several recorded command buffers.
 * Publish optionally starts the queued prefix while recording the suffix;
 * at most one prefix may be in flight, and end still drains all work. */
fg_status fg_vk_submit_group_begin(fg_vk_context *context,fg_error *err);
fg_status fg_vk_submit_group_publish(fg_vk_context *context,fg_error *err);
fg_status fg_vk_submit_group_end(fg_vk_context *context,fg_error *err);
void fg_vk_submit_group_abort(fg_vk_context *context);
bool fg_vk_submit_group_active(const fg_vk_context *context);
fg_status fg_vk_abort(fg_vk_context *context,fg_error *err);
bool fg_vk_batch_active(const fg_vk_context *context);
void fg_vk_next_dispatch_independent(fg_vk_context *context);
void fg_vk_host_write_visible(fg_vk_context *context);
void fg_vk_device_write_visible(fg_vk_context *context);

fg_status fg_vk_expert_graph_create(fg_vk_context *context,fg_vk_expert_graph **out,
                                     fg_vk_tensor *activation,fg_vk_tensor *tiles,
                                     fg_vk_tensor *gates,fg_vk_tensor *gate,fg_vk_tensor *up,
                                     fg_vk_tensor *mid,fg_vk_tensor *down,fg_vk_tensor *reduced,
                                     const fg_vk_tensor *gate_weights,const fg_vk_tensor *up_weights,
                                     const fg_vk_tensor *down_weights,uint32_t gate_type,
                                     uint32_t up_type,uint32_t down_type,uint32_t hidden_width,
                                     uint32_t mid_width,uint32_t gate_expert_stride,
                                     uint32_t up_expert_stride,uint32_t down_expert_stride,
                                     uint32_t weight_experts,uint32_t slots,fg_error *err);
void fg_vk_expert_graph_destroy(fg_vk_expert_graph *graph);
fg_status fg_vk_expert_graph_execute(fg_vk_expert_graph *graph,fg_error *err);
fg_status fg_vk_expert_graph_submit(fg_vk_expert_graph *graph,fg_error *err);
fg_status fg_vk_expert_graph_wait(fg_vk_context *context,fg_error *err);
bool fg_vk_decode_experts_fusable(const fg_vk_tensor *gate_weights,
                                  const fg_vk_tensor *up_weights,
                                  const fg_vk_tensor *down_weights,
                                  uint32_t down_type);
fg_status fg_vk_moe_decode_gate_up(fg_vk_context *context,fg_vk_tensor *mid,
                                   const fg_vk_tensor *gate_weights,const fg_vk_tensor *up_weights,
                                   const fg_vk_tensor *activation,const fg_vk_tensor *tiles,
                                   uint32_t output_width,uint32_t input_width,
                                   uint32_t gate_stride,uint32_t up_stride,
                                   uint32_t gate_type,uint32_t up_type,uint32_t slots,fg_error *err);
fg_status fg_vk_moe_decode_down_reduce(fg_vk_context *context,fg_vk_tensor *out,
                                       const fg_vk_tensor *down_weights,const fg_vk_tensor *tiles,
                                       const fg_vk_tensor *input,const fg_vk_tensor *gates,
                                       uint32_t output_width,uint32_t input_width,
                                       uint32_t expert_stride,uint32_t slots,
                                       uint32_t down_type,fg_error *err);
fg_status fg_vk_moe_decode_shared_add(fg_vk_context *context,fg_vk_tensor *out,
                                      const fg_vk_tensor *reduced,const fg_vk_tensor *shared,
                                      const fg_vk_tensor *scalar,uint32_t width,fg_error *err);

fg_status fg_vk_tensor_create(fg_vk_context *context,uint64_t bytes,fg_vk_tensor **out,fg_error *err);
fg_status fg_vk_tensor_create_cached(fg_vk_context *context,uint64_t bytes,fg_vk_tensor **out,fg_error *err);
fg_status fg_vk_tensor_view(fg_vk_tensor *base,uint64_t offset,uint64_t bytes,fg_vk_tensor **out,fg_error *err);
/* Rebinds view metadata within its allocation; recorded descriptor offsets remain snapshots. */
fg_status fg_vk_tensor_view_rebind(fg_vk_tensor *view,fg_vk_tensor *base,uint64_t offset,
                                   uint64_t bytes,fg_error *err);
void fg_vk_tensor_destroy(fg_vk_tensor *tensor);
uint64_t fg_vk_tensor_bytes(const fg_vk_tensor *tensor);
uint64_t fg_vk_tensor_allocation_bytes(const fg_vk_tensor *tensor);
fg_status fg_vk_tensor_residency_canary(fg_vk_tensor *tensor,uint64_t *touched_bytes,
                                        fg_error *err);
void *fg_vk_tensor_map(fg_vk_tensor *tensor);
const void *fg_vk_tensor_const_map(const fg_vk_tensor *tensor);
void fg_vk_tensor_set_format(fg_vk_tensor *tensor,fg_vk_tensor_format format);
fg_vk_tensor_format fg_vk_tensor_get_format(const fg_vk_tensor *tensor);
fg_status fg_vk_tensor_write(fg_vk_tensor *tensor,uint64_t offset,const void *data,uint64_t bytes,fg_error *err);
fg_status fg_vk_tensor_write_ordered(fg_vk_tensor *tensor,uint64_t offset,
    const void *data,uint64_t bytes,fg_error *err);
fg_status fg_vk_tensor_read(const fg_vk_tensor *tensor,uint64_t offset,void *data,uint64_t bytes,fg_error *err);
/* Device-side tensor copy: `count` equal-sized (dst[i],src[i]) pairs copied with
 * vkCmdCopyBuffer on the context queue.  Drains pending submissions first and
 * waits for the copy, so it is a synchronous checkpoint primitive. */
fg_status fg_vk_copy_tensors(fg_vk_context *context,fg_vk_tensor *const *dst,
                             const fg_vk_tensor *const *src,uint32_t count,fg_error *err);
fg_status fg_vk_quantize_q8_k(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *input,
                              uint32_t input_width,uint32_t tokens,fg_error *err);
fg_status fg_vk_quantize_q8_0(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *input,
                              uint32_t input_width,uint32_t tokens,fg_error *err);
fg_status fg_vk_quantize_q4_0(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *input,
                              uint32_t input_width,uint32_t tokens,fg_error *err);
fg_status fg_vk_dequantize_iq4_nl(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *input,
                                  uint32_t rows,uint32_t width,fg_error *err);
fg_status fg_vk_swiglu(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *gate,
                       const fg_vk_tensor *up,uint32_t values,fg_error *err);

fg_status fg_vk_dense_q8_0_f32(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *weights,
                               const fg_vk_tensor *input,uint32_t input_width,uint32_t output_width,
                               uint32_t tokens,float scale,fg_error *err);
fg_status fg_vk_dense_q8_0_subgroup(fg_vk_context *context,fg_vk_tensor *output,
                                    const fg_vk_tensor *weights,const fg_vk_tensor *input,
                                    uint32_t input_width,uint32_t output_width,
                                    uint32_t tokens,float scale,fg_error *err);
fg_status fg_vk_dense_q8_0_cooked(fg_vk_context *context,fg_vk_tensor *output,
                                  const fg_vk_tensor *weights,const fg_vk_tensor *input,
                                  uint32_t input_width,uint32_t output_width,
                                  uint32_t tokens,float scale,fg_error *err);
fg_status fg_vk_dense_q8_0_cooked_prefill(fg_vk_context *context,
                                          fg_vk_tensor *output,
                                          const fg_vk_tensor *weights,
                                          const fg_vk_tensor *input,
                                          uint32_t input_width,
                                          uint32_t output_width,
                                          uint32_t tokens,float scale,
                                          fg_error *err);
fg_status fg_vk_dense_q8_0_cooked_split(fg_vk_context *context,fg_vk_tensor *output,
                                        fg_vk_tensor *partials,const fg_vk_tensor *weights,
                                        const fg_vk_tensor *input,uint32_t input_width,
                                        uint32_t output_width,uint32_t tokens,uint32_t splits,
                                        float scale,fg_error *err);
fg_status fg_vk_dense_q8_0_cooked_split_silu(fg_vk_context *context,fg_vk_tensor *low,
                                             fg_vk_tensor *active,fg_vk_tensor *partials,
                                             const fg_vk_tensor *weights,
                                             const fg_vk_tensor *input,uint32_t input_width,
                                             uint32_t output_width,uint32_t tokens,
                                             uint32_t splits,float scale,float input_scale,
                                             fg_error *err);
fg_status fg_vk_embedding_q8_0(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *weights,
                               uint32_t token,uint32_t width,uint32_t rows,uint32_t copies,fg_error *err);
fg_status fg_vk_embedding_q8_0_batch(fg_vk_context *context,fg_vk_tensor *output,
                                     const fg_vk_tensor *weights,const fg_vk_tensor *token_ids,
                                     uint32_t token_count,uint32_t width,uint32_t rows,
                                     uint32_t copies,fg_error *err);
fg_status fg_vk_dense_f32(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *weights,
                          const fg_vk_tensor *input,uint32_t input_width,uint32_t output_width,
                          uint32_t tokens,fg_error *err);
fg_status fg_vk_dense_bf16_f32(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *weights,
                               const fg_vk_tensor *input,uint32_t input_width,uint32_t output_width,
                               uint32_t tokens,fg_error *err);
fg_status fg_vk_silu_scaled(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *input,
                            uint32_t values,float input_scale,fg_error *err);
fg_status fg_vk_group_rms_norm(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *input,
                               const fg_vk_tensor *weight,uint32_t width,uint32_t groups,uint32_t tokens,
                               float epsilon,fg_error *err);
fg_status fg_vk_gr_mix(fg_vk_context *context,fg_vk_tensor *mixed,fg_vk_tensor *injection,
                       const fg_vk_tensor *normalized,const fg_vk_tensor *up_logits,
                       const fg_vk_tensor *injection_logits,uint32_t hidden,uint32_t groups,
                       uint32_t tokens,fg_error *err);
fg_status fg_vk_hc_inject_partial(fg_vk_context *context,fg_vk_tensor *partials,
                                  const fg_vk_tensor *normalized,const fg_vk_tensor *weights,
                                  uint32_t hidden,uint32_t groups,uint32_t tokens,
                                  uint32_t pieces,fg_error *err);
fg_status fg_vk_gr_mix_partial(fg_vk_context *context,fg_vk_tensor *mixed,fg_vk_tensor *injection,
                               const fg_vk_tensor *normalized,const fg_vk_tensor *up_logits,
                               const fg_vk_tensor *partials,uint32_t hidden,uint32_t groups,
                               uint32_t tokens,uint32_t pieces,fg_error *err);
fg_status fg_vk_hc_finalize(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *normalized,
                            const fg_vk_tensor *up,uint32_t hidden,uint32_t groups,uint32_t tokens,
                            fg_error *err);
fg_status fg_vk_gr_write(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *hyper_input,
                         const fg_vk_tensor *block_output,const fg_vk_tensor *injection,uint32_t hidden,
                         uint32_t groups,uint32_t tokens,fg_error *err);
fg_status fg_vk_ple_gate(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *key,
                         const fg_vk_tensor *query,const fg_vk_tensor *value,fg_error *err);
fg_status fg_vk_ple_gate_prefill(fg_vk_context *context,fg_vk_tensor *output,
                                 const fg_vk_tensor *key,const fg_vk_tensor *query,
                                 const fg_vk_tensor *value,uint32_t tokens,fg_error *err);
fg_status fg_vk_ple_conv_decode(fg_vk_context *context,fg_vk_tensor *output,fg_vk_tensor *state,
                                const fg_vk_tensor *gated,const fg_vk_tensor *normalized,
                                const fg_vk_tensor *weight,fg_error *err);
fg_status fg_vk_ple_conv_prefill(fg_vk_context *context,fg_vk_tensor *output,fg_vk_tensor *state,
                                 const fg_vk_tensor *gated,const fg_vk_tensor *normalized,
                                 const fg_vk_tensor *weight,uint32_t tokens,fg_error *err);
fg_status fg_vk_ple_conv_decode_add(fg_vk_context *context,fg_vk_tensor *output,fg_vk_tensor *state,
                                    const fg_vk_tensor *gated,const fg_vk_tensor *normalized,
                                    const fg_vk_tensor *weight,const fg_vk_tensor *hyper,
                                    fg_error *err);
fg_status fg_vk_add_f32(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *left,
                        const fg_vk_tensor *right,uint32_t values,fg_error *err);
fg_status fg_vk_apply_penalties(fg_vk_context *context,fg_vk_tensor *logits,
                                const fg_vk_tensor *counts,uint32_t values,
                                float presence_penalty,float frequency_penalty,
                                float repetition_penalty,fg_error *err);
fg_status fg_vk_gdn_conv_decode(fg_vk_context *context,fg_vk_tensor *output,fg_vk_tensor *state,
                                const fg_vk_tensor *projection,const fg_vk_tensor *weight,
                                uint32_t channels,fg_error *err);
fg_status fg_vk_gdn_conv_prefill(fg_vk_context *context,fg_vk_tensor *output,fg_vk_tensor *state,
                                 const fg_vk_tensor *projection,const fg_vk_tensor *weight,
                                 uint32_t channels,uint32_t tokens,fg_error *err);
fg_status fg_vk_gdn_project_decode(fg_vk_context *context,fg_vk_tensor *qkv,
                                   fg_vk_tensor *z,fg_vk_tensor *alpha,fg_vk_tensor *beta,
                                   const fg_vk_tensor *qkv_weight,const fg_vk_tensor *z_weight,
                                   const fg_vk_tensor *alpha_weight,const fg_vk_tensor *beta_weight,
                                   const fg_vk_tensor *hidden,fg_error *err);
fg_status fg_vk_gdn_recurrent_decode(fg_vk_context *context,fg_vk_tensor *output,fg_vk_tensor *state,
                                     const fg_vk_tensor *qkv,const fg_vk_tensor *z,const fg_vk_tensor *alpha,
                                     const fg_vk_tensor *beta,const fg_vk_tensor *a_log,const fg_vk_tensor *dt_bias,
                                     const fg_vk_tensor *norm_weight,uint32_t value_heads,uint32_t key_heads,
                                     uint32_t head_dim,float epsilon,fg_error *err);
fg_status fg_vk_gdn_recurrent_algebraic(fg_vk_context *context,fg_vk_tensor *output,fg_vk_tensor *state,
                                        const fg_vk_tensor *qkv,const fg_vk_tensor *z,
                                        const fg_vk_tensor *alpha,const fg_vk_tensor *beta,
                                        const fg_vk_tensor *a_log,const fg_vk_tensor *dt_bias,
                                        const fg_vk_tensor *norm_weight,uint32_t value_heads,
                                        uint32_t key_heads,uint32_t head_dim,float epsilon,fg_error *err);
fg_status fg_vk_gdn_recurrent_prefill(fg_vk_context *context,fg_vk_tensor *output,
                                      fg_vk_tensor *state,const fg_vk_tensor *qkv,
                                      const fg_vk_tensor *z,const fg_vk_tensor *alpha,
                                      const fg_vk_tensor *beta,const fg_vk_tensor *a_log,
                                      const fg_vk_tensor *dt_bias,const fg_vk_tensor *norm_weight,
                                      uint32_t value_heads,uint32_t key_heads,uint32_t head_dim,
                                      uint32_t tokens,float epsilon,fg_error *err);
fg_status fg_vk_gdn_recurrent_prefill_chunked(fg_vk_context *context,
                                               fg_vk_tensor *output,
                                               fg_vk_tensor *state,
                                               fg_vk_tensor *qkv,
                                               const fg_vk_tensor *z,
                                               const fg_vk_tensor *alpha,
                                               const fg_vk_tensor *beta,
                                               const fg_vk_tensor *a_decay,
                                               const fg_vk_tensor *dt_bias,
                                               const fg_vk_tensor *norm_weight,
                                               uint32_t tokens,float epsilon,
                                               fg_error *err);
fg_status fg_vk_qsa_index_score_batch(fg_vk_context *context,
    fg_vk_tensor *scores,fg_vk_tensor *ids,const fg_vk_tensor *queries,
    const fg_vk_tensor *keys,const fg_vk_tensor *norm,const fg_vk_tensor *positions,
    uint32_t segment_tokens,uint32_t block_base,uint32_t score_stride,
    uint32_t first_visible,uint32_t query_count,fg_error *err);
fg_status fg_vk_qsa_index_score(fg_vk_context *context,fg_vk_tensor *scores,
                                fg_vk_tensor *block_ids,
                                const fg_vk_tensor *query,const fg_vk_tensor *index_keys_q8,
                                const fg_vk_tensor *key_norm,const fg_vk_tensor *positions,
                                uint32_t tokens,fg_error *err);
fg_status fg_vk_qsa_index_score_segment(fg_vk_context *context,fg_vk_tensor *scores,
                                        fg_vk_tensor *block_ids,
                                        const fg_vk_tensor *query,
                                        const fg_vk_tensor *index_keys_q8,
                                        const fg_vk_tensor *key_norm,
                                        const fg_vk_tensor *positions,uint32_t tokens,
                                        uint32_t block_base,fg_error *err);
fg_status fg_vk_qsa_prepare(fg_vk_context *context,fg_vk_tensor *query,fg_vk_tensor *gate,
                            fg_vk_tensor *key,const fg_vk_tensor *raw_query_gate,
                            const fg_vk_tensor *raw_key,const fg_vk_tensor *query_norm,
                            const fg_vk_tensor *key_norm,const fg_vk_tensor *position,
                            fg_error *err);
fg_status fg_vk_mtp_attention(fg_vk_context *context,fg_vk_tensor *output,
    fg_vk_tensor *keys,fg_vk_tensor *values,const fg_vk_tensor *query,
    const fg_vk_tensor *gate,const fg_vk_tensor *key,const fg_vk_tensor *value,
    uint32_t cell,fg_error *err);
fg_status fg_vk_mtp_attention_indirect(fg_vk_context *context,fg_vk_tensor *output,
    fg_vk_tensor *keys,fg_vk_tensor *values,const fg_vk_tensor *query,
    const fg_vk_tensor *gate,const fg_vk_tensor *key,const fg_vk_tensor *value,
    const fg_vk_tensor *position,uint32_t capacity,fg_error *err);
fg_status fg_vk_qsa_prepare_prefill(fg_vk_context *context,fg_vk_tensor *query,
                                    fg_vk_tensor *gate,fg_vk_tensor *key,
                                    const fg_vk_tensor *raw_query_gate,
                                    const fg_vk_tensor *raw_key,const fg_vk_tensor *query_norm,
                                    const fg_vk_tensor *key_norm,const fg_vk_tensor *positions,
                                    uint32_t tokens,fg_error *err);
fg_status fg_vk_qsa_index_prepare(fg_vk_context *context,fg_vk_tensor *query,const fg_vk_tensor *raw_query,
                                  const fg_vk_tensor *query_norm,const fg_vk_tensor *position,
                                  fg_error *err);
fg_status fg_vk_qsa_index_prepare_prefill(fg_vk_context *context,fg_vk_tensor *query,
                                          const fg_vk_tensor *raw_query,
                                          const fg_vk_tensor *query_norm,
                                          const fg_vk_tensor *positions,uint32_t tokens,
                                          fg_error *err);
fg_status fg_vk_qsa_record_commit(fg_vk_context *context,fg_vk_tensor *records,
                                  fg_vk_tensor *index_history,const fg_vk_tensor *key_q8,
                                  const fg_vk_tensor *value_q8,const fg_vk_tensor *index_key_q8,
                                  const fg_vk_tensor *position,uint32_t layer_slot,
                                  uint32_t token,uint32_t capacity,fg_error *err);
fg_status fg_vk_qsa_record_commit_segmented(
    fg_vk_context *context,fg_vk_tensor *records,fg_vk_tensor *index_segment,
    const fg_vk_tensor *key_q8,const fg_vk_tensor *value_q8,
    const fg_vk_tensor *index_key_q8,const fg_vk_tensor *position,
    uint32_t layer_slot,uint32_t token,uint32_t index_token,
    uint32_t index_capacity,uint32_t hot_slot,uint32_t hot_capacity,
    fg_error *err);
fg_status fg_vk_qsa_record_commit_tiered(fg_vk_context *context,fg_vk_tensor *records,
                                         fg_vk_tensor *index_history,
                                         const fg_vk_tensor *key_q8,
                                         const fg_vk_tensor *value_q8,
                                         const fg_vk_tensor *index_key_q8,
                                         const fg_vk_tensor *position,uint32_t layer_slot,
                                         uint32_t token,uint32_t index_capacity,
                                         uint32_t hot_slot,uint32_t hot_capacity,
                                         fg_error *err);
fg_status fg_vk_qsa_record_gather(fg_vk_context *context,fg_vk_tensor *output,
                                  const fg_vk_tensor *records,const fg_vk_tensor *block_ids,
                                  uint32_t layer_slot,uint32_t capacity,uint32_t block_count,
                                  uint32_t tail_start,uint32_t tail_count,fg_error *err);
fg_status fg_vk_qsa_select_resolve(fg_vk_context *context,fg_vk_tensor *resolved,
                                   fg_vk_tensor *flags,const fg_vk_tensor *selected_ids,
                                   const fg_vk_tensor *slot_table,uint32_t count,
                                   uint32_t block_limit,uint32_t layer_base,
                                   fg_error *err);
fg_status fg_vk_qsa_attention(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *records,
                              const fg_vk_tensor *query,const fg_vk_tensor *gate,
                              uint32_t selected_count,fg_error *err);
fg_status fg_vk_qsa_attention_split(fg_vk_context *context,fg_vk_tensor *partials,
                                    const fg_vk_tensor *records,const fg_vk_tensor *query,
                                    uint32_t selected_count,uint32_t splits,fg_error *err);
fg_status fg_vk_qsa_decode_attention_split(fg_vk_context *context,fg_vk_tensor *partials,
                                           const fg_vk_tensor *records,const fg_vk_tensor *query,
                                           uint32_t selected_count,uint32_t splits,fg_error *err);
fg_status fg_vk_qsa_attention_merge(fg_vk_context *context,fg_vk_tensor *output,
                                    const fg_vk_tensor *partials,const fg_vk_tensor *gate,
                                    uint32_t splits,fg_error *err);
fg_status fg_vk_qsa_attention_split_batch(fg_vk_context *context,fg_vk_tensor *partials,
                                          const fg_vk_tensor *records,const fg_vk_tensor *query,
                                          const fg_vk_tensor *counts,uint32_t query_count,
                                          uint32_t record_stride,uint32_t query_stride,
                                          uint32_t splits,fg_error *err);
fg_status fg_vk_qsa_attention_merge_batch(fg_vk_context *context,fg_vk_tensor *output,
                                          const fg_vk_tensor *partials,
                                          const fg_vk_tensor *gate,uint32_t query_count,
                                          uint32_t query_stride,uint32_t splits,fg_error *err);
fg_status fg_vk_qsa_attention_union(fg_vk_context *context,fg_vk_tensor *partials,
    const fg_vk_tensor *records,const fg_vk_tensor *query,const fg_vk_tensor *descriptors,
    uint32_t query_count,uint32_t union_blocks,uint32_t capacity,uint32_t splits,fg_error *err);
fg_status fg_vk_qsa_record_gather_batch(fg_vk_context *context,fg_vk_tensor *output,
                                        const fg_vk_tensor *records,
                                        const fg_vk_tensor *slots,uint32_t query_count,
                                        uint32_t slot_stride,uint32_t record_stride,
                                        uint32_t capacity,fg_error *err);
/* Reduce per-query candidate rows (count entries, input_stride apart) to the
   top 512 ids in result_ids using fg_qsa_resident_topk_merge.  The two score
   buffers are scratch sides; the final merge writes ids into result_ids with
   a 512-id stride. */
fg_status fg_vk_qsa_select_merge(fg_vk_context *context,fg_vk_tensor *scores_0,
                                 fg_vk_tensor *ids_0,fg_vk_tensor *scores_1,
                                 fg_vk_tensor *ids_1,fg_vk_tensor *result_ids,
                                 uint32_t count,uint32_t input_stride,uint32_t query_count,
                                 fg_error *err);
fg_status fg_vk_qsa_resident_record_commit(
    fg_vk_context *context,fg_vk_tensor *record_segment_0,
    fg_vk_tensor *record_segment_1,fg_vk_tensor *index_segment_0,
    fg_vk_tensor *index_segment_1,const fg_vk_tensor *keys_q8,
    const fg_vk_tensor *values_q8,const fg_vk_tensor *index_keys_q8,
    const fg_vk_tensor *positions,uint32_t first_token,uint32_t token_count,
    uint32_t capacity,uint32_t segment_capacity,fg_error *err);
fg_status fg_vk_qsa_resident_select(
    fg_vk_context *context,fg_vk_tensor *scores_0,fg_vk_tensor *ids_0,
    fg_vk_tensor *scores_1,fg_vk_tensor *ids_1,const fg_vk_tensor *query,
    const fg_vk_tensor *index_segment_0,const fg_vk_tensor *index_segment_1,
    const fg_vk_tensor *key_norm,const fg_vk_tensor *positions,
    uint32_t first_token,uint32_t query_tokens,uint32_t capacity,
    uint32_t segment_capacity,uint32_t *final_side,fg_error *err);
fg_status fg_vk_qsa_resident_attention(
    fg_vk_context *context,fg_vk_tensor *output,
    const fg_vk_tensor *record_segment_0,const fg_vk_tensor *record_segment_1,
    const fg_vk_tensor *selected_blocks,const fg_vk_tensor *query,
    const fg_vk_tensor *gate,uint32_t first_token,uint32_t query_tokens,
    uint32_t capacity,uint32_t segment_capacity,uint32_t selected_stride,
    fg_error *err);
fg_status fg_vk_topk_reduce(fg_vk_context *context,fg_vk_tensor *output_scores,fg_vk_tensor *output_ids,
                            const fg_vk_tensor *input_scores,const fg_vk_tensor *input_ids,
                            uint32_t count,uint32_t *output_count,fg_error *err);
/* Select up to 64 finalists per 1024-value tile.  Call repeatedly over the
   compacted result until one tile remains.  Candidate order is unspecified. */
fg_status fg_vk_topk_select(fg_vk_context *context,fg_vk_tensor *output_scores,fg_vk_tensor *output_ids,
                            const fg_vk_tensor *input_scores,const fg_vk_tensor *input_ids,
                            uint32_t count,uint32_t k,uint32_t *output_count,fg_error *err);
fg_status fg_vk_router_top10(fg_vk_context *context,fg_vk_tensor *selected,
                             fg_vk_tensor *gates,const fg_vk_tensor *logits,
                             uint32_t experts,uint32_t tokens,fg_error *err);
fg_status fg_vk_expert_major_pack(fg_vk_context *context,fg_vk_tensor *tiles,
                                  const fg_vk_tensor *selected,uint32_t experts,
                                  uint32_t tokens,fg_error *err);
fg_status fg_vk_decode_tile_schedule(fg_vk_context *context,
                                     fg_vk_tensor *tiles,
                                     const fg_vk_tensor *selected,
                                     fg_error *err);
fg_status fg_vk_argmax_reduce(fg_vk_context *context,fg_vk_tensor *output_scores,
                                                            fg_vk_tensor *output_ids,const fg_vk_tensor *input_scores,
                                                            const fg_vk_tensor *input_ids,uint32_t count,
                                                            uint32_t *output_count,fg_error *err);
fg_status fg_vk_moe_q5_1_down(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *weights,
                              const fg_vk_tensor *tiles,const fg_vk_tensor *input,uint32_t output_width,
                              uint32_t input_width,uint32_t expert_stride,uint32_t used_experts,
                              bool packed_weights,uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_q5_1_down_cooked(fg_vk_context *context,fg_vk_tensor *output,
                                     const fg_vk_tensor *weights,const fg_vk_tensor *tiles,
                                     const fg_vk_tensor *input,uint32_t output_width,
                                     uint32_t input_width,uint32_t expert_stride,
                                     bool packed_weights,uint32_t tile_count,fg_error *err);
            fg_status fg_vk_moe_q5_1_down_cooked_pairs(fg_vk_context *context,fg_vk_tensor *output,
                                         const fg_vk_tensor *weights,const fg_vk_tensor *tiles,
                                         const fg_vk_tensor *input,uint32_t output_width,
                                         uint32_t input_width,uint32_t expert_stride,
                                         uint32_t routed_pairs,bool packed_weights,
                                         uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_q8_0_down(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *weights,
                              const fg_vk_tensor *tiles,const fg_vk_tensor *input,uint32_t output_width,
                              uint32_t input_width,uint32_t expert_stride,uint32_t used_experts,
                              bool packed_weights,uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_q8_0_down_cooked_pairs(fg_vk_context *context,fg_vk_tensor *output,
                                           const fg_vk_tensor *weights,const fg_vk_tensor *tiles,
                                           const fg_vk_tensor *input,uint32_t output_width,
                                           uint32_t input_width,uint32_t expert_stride,
                                           uint32_t routed_pairs,bool packed_weights,
                                           uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_q8_0_down_cooked(fg_vk_context *context,fg_vk_tensor *output,
                                     const fg_vk_tensor *weights,const fg_vk_tensor *tiles,
                                     const fg_vk_tensor *input,uint32_t output_width,
                                     uint32_t input_width,uint32_t expert_stride,
                                     bool packed_weights,uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_reduce(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *down,
                           const fg_vk_tensor *gates,const fg_vk_tensor *tiles,uint32_t output_width,
                           uint32_t selected_count,uint32_t slot_count,fg_error *err);
fg_status fg_vk_moe_kquant(fg_vk_context *context,fg_vk_tensor *output,const fg_vk_tensor *weights,
                           const fg_vk_tensor *activation_q8k,const fg_vk_tensor *tiles,uint32_t ggml_type,
                           uint32_t output_width,uint32_t input_width,uint32_t expert_stride,uint32_t used_experts,
                           uint32_t routed_pairs,bool packed_weights,uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_kquant_cooked(fg_vk_context *context,fg_vk_tensor *output,
                                  const fg_vk_tensor *weights,const fg_vk_tensor *activation_q8k,
                                  const fg_vk_tensor *tiles,uint32_t ggml_type,
                                  uint32_t output_width,uint32_t input_width,
                                    uint32_t expert_stride,bool packed_weights,
                                  uint32_t tile_count,fg_error *err);
            fg_status fg_vk_moe_kquant_cooked_pairs(fg_vk_context *context,fg_vk_tensor *output,
                                        const fg_vk_tensor *weights,
                                        const fg_vk_tensor *activation_q8k,
                                        const fg_vk_tensor *tiles,uint32_t ggml_type,
                                        uint32_t output_width,uint32_t input_width,
                                        uint32_t expert_stride,uint32_t used_experts,
                                        uint32_t routed_pairs,bool packed_weights,
                                        uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_kquant_cooked_grouped(fg_vk_context *context,
                                         fg_vk_tensor *output,
                                         const fg_vk_tensor *weights,
                                         const fg_vk_tensor *activation_q8k,
                                         const fg_vk_tensor *tiles,
                                         uint32_t ggml_type,
                                         uint32_t output_width,
                                         uint32_t input_width,
                                         uint32_t expert_stride,
                                         uint32_t weight_experts,
                                         uint32_t tokens,uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_q5_1_down_cooked_grouped(fg_vk_context *context,
                                            fg_vk_tensor *output,
                                            const fg_vk_tensor *weights,
                                            const fg_vk_tensor *tiles,
                                            const fg_vk_tensor *input,
                                            uint32_t output_width,
                                            uint32_t input_width,
                                            uint32_t expert_stride,
                                            uint32_t weight_experts,
                                            uint32_t tokens,uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_q8_0_down_grouped(fg_vk_context *context,
                                      fg_vk_tensor *output,
                                      const fg_vk_tensor *weights,
                                      const fg_vk_tensor *tiles,
                                      const fg_vk_tensor *input,
                                      uint32_t output_width,
                                      uint32_t input_width,
                                      uint32_t expert_stride,
                                      uint32_t weight_experts,
                                      uint32_t tokens,uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_q8_0_down_cooked_grouped(fg_vk_context *context,
                                             fg_vk_tensor *output,
                                             const fg_vk_tensor *weights,
                                             const fg_vk_tensor *tiles,
                                             const fg_vk_tensor *input,
                                             uint32_t output_width,
                                             uint32_t input_width,
                                             uint32_t expert_stride,
                                             uint32_t weight_experts,
                                             uint32_t tokens,uint32_t tile_count,fg_error *err);
fg_status fg_vk_moe_prefill_shard_reduce(fg_vk_context *context,fg_vk_tensor *output,
    const fg_vk_tensor *experts,const fg_vk_tensor *gates,uint32_t tokens,fg_error *err);
fg_status fg_vk_moe_prefill_reduce(fg_vk_context *context,fg_vk_tensor *output,
                                   const fg_vk_tensor *expert_output,
                                   const fg_vk_tensor *gates,
                                   const fg_vk_tensor *shared_output,
                                   const fg_vk_tensor *shared_logit,
                                   uint32_t width,uint32_t tokens,
                                   fg_error *err);

/* GPU timestamp-profiled kernel benchmark. Reports per-shape:
    A. raw GPU kernel GB/s (no inter-dispatch barriers)
    B. kernel with current barrier policy
    C. complete standalone dispatch (full Vulkan overhead) */
fg_status fg_vk_bench_dense_q8(fg_vk_context *context,fg_error *err);
fg_status fg_vk_bench_decompose(fg_vk_context *context,fg_error *err);
fg_status fg_vk_bench_stream_abc(fg_vk_context *context,fg_error *err);
fg_status fg_vk_bench_cooked_layout(fg_vk_context *context,fg_error *err);

#endif
