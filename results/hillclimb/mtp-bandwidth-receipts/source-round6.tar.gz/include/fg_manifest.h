#ifndef FLASH_GORDON_MANIFEST_H
#define FLASH_GORDON_MANIFEST_H

#include "fg.h"

#define FG_MANIFEST_MAGIC UINT64_C(0x314d47464e574f51) /* QOWNFGM1 */
#define FG_MANIFEST_LEGACY_FORMAT_VERSION 4u
#define FG_MANIFEST_SESSION_FORMAT_VERSION 5u
#define FG_MANIFEST_FORMAT_VERSION 6u
#define FG_MANIFEST_CONTRACT_VERSION 1u
#define FG_MANIFEST_DEFAULT_CONTEXT_TOKENS 8192u
#define FG_MAX_TENSORS 4096u
#define FG_TENSOR_NAME_MAX 96u
#define FG_MAX_ENDPOINT 64u
#define FG_TOKEN_EMBEDDING_ARTIFACT "token-embedding.q8_0"
#define FG_NGRAM_SHARD_COUNT (FG_RANK_COUNT - 1u)
#define FG_NGRAM_SHARD_ARTIFACT_FORMAT "ngram-rank-%02u.iq4nl"

typedef enum fg_tensor_kind {
    FG_TENSOR_COMMON = 1,
    FG_TENSOR_ROUTED_EXPERT = 2,
    FG_TENSOR_NGRAM = 3,
    FG_TENSOR_VISION = 4,
    FG_TENSOR_MTP = 5,
    FG_TENSOR_TOKENIZER = 6,
    FG_TENSOR_HOST_CACHE = 7
} fg_tensor_kind;

typedef enum fg_tensor_layout {
    FG_TENSOR_LAYOUT_GGML = 0,
    FG_TENSOR_LAYOUT_Q8_0_COOKED = 1,
    FG_TENSOR_LAYOUT_K_QUANT_EXPERT_COOKED = 2,
    FG_TENSOR_LAYOUT_Q5_1_EXPERT_COOKED = 3,
    FG_TENSOR_LAYOUT_HOST_Q8_0 = 4,
    FG_TENSOR_LAYOUT_Q8_0_EXPERT_COOKED = 5,
    FG_TENSOR_LAYOUT_DENSE_SOA = 6,
    FG_TENSOR_LAYOUT_DENSE_COMPACT = 7
} fg_tensor_layout;

enum {
    FG_MANIFEST_HAS_TEXT = 1u << 0,
    FG_MANIFEST_HAS_NGRAM = 1u << 1,
    FG_MANIFEST_HAS_VISION = 1u << 2,
    FG_MANIFEST_HAS_MTP = 1u << 3,
    FG_MANIFEST_HAS_TOKENIZER = 1u << 4,
    FG_MANIFEST_COMPONENTS_TEXT_REQUIRED = FG_MANIFEST_HAS_TEXT | FG_MANIFEST_HAS_NGRAM |
        FG_MANIFEST_HAS_TOKENIZER,
    FG_MANIFEST_COMPONENTS_MULTIMODAL = FG_MANIFEST_HAS_VISION | FG_MANIFEST_HAS_MTP
};

typedef enum fg_manifest_component {
    FG_COMPONENT_TEXT = 0,
    FG_COMPONENT_NGRAM = 1,
    FG_COMPONENT_TOKENIZER = 2,
    FG_COMPONENT_VISION = 3,
    FG_COMPONENT_MTP = 4,
    FG_COMPONENT_COUNT = 5
} fg_manifest_component;

typedef enum fg_execution_mode {
    FG_EXECUTION_EXPERT_PARALLEL = 0 /* Value 1 is retired and rejected. */
} fg_execution_mode;

typedef struct fg_tensor_record {
    char name[FG_TENSOR_NAME_MAX];
    uint64_t offset;
    uint64_t bytes;
    uint32_t ggml_type;
    uint32_t dims;
    uint64_t shape[4];
    uint16_t rank;
    uint16_t layer;
    uint16_t expert;
    uint8_t kind;
    uint8_t layout;
    uint8_t reserved[4];
    uint8_t sha256[32];
} fg_tensor_record;

typedef struct fg_rank_record {
    char endpoint[FG_MAX_ENDPOINT];
    uint64_t persistent_bytes;
    uint64_t transient_bytes;
    uint64_t kv_bytes;
    uint64_t state_file_bytes;
    uint64_t scratch_bytes;
    uint64_t driver_reserve_bytes;
    uint32_t tensor_begin;
    uint32_t tensor_count;
} fg_rank_record;

typedef struct fg_manifest_contract {
    uint32_t version;
    uint32_t minimum_protocol_version;
    uint32_t position_mode;
    uint32_t flags;
    uint32_t gpu_index_tokens;
    uint32_t qsa_hot_record_tokens;
    uint64_t host_page_cache_bytes;
    uint8_t rope_policy_sha256[32];
    uint8_t quantization_sha256[32];
    uint8_t state_format_sha256[32];
    uint8_t component_sha256[FG_COMPONENT_COUNT][32];
    uint8_t rank_state_format_sha256[FG_RANK_COUNT][32];
    uint32_t logical_context_tokens;
    uint8_t reserved[60];
} fg_manifest_contract;

typedef struct fg_ngram_shard_record {
    uint32_t logical_rank;
    uint32_t reserved;
    uint64_t row_begin;
    uint64_t row_count;
    uint64_t bytes;
    uint8_t sha256[32];
} fg_ngram_shard_record;

typedef struct fg_manifest {
    uint64_t magic;
    uint32_t format_version;
    uint32_t protocol_version;
    uint32_t header_bytes;
    uint32_t rank_count;
    uint32_t layer_count;
    uint32_t expert_count;
    uint32_t hidden_size;
    uint32_t top_k;
    uint32_t required_cu;
    uint32_t native_context;
    uint32_t max_context;
    uint32_t prefill_microbatch;
    uint32_t prefill_window;
    uint32_t tensor_count;
    uint32_t flags;
    uint64_t persistent_cap_bytes;
    uint64_t residency_cap_bytes;
    uint8_t source_sha256[32];
    uint8_t quant_profile_sha256[32];
    uint8_t manifest_sha256[32];
    fg_rank_record ranks[FG_RANK_COUNT];
    uint8_t layer_owner[FG_LAYER_COUNT];
    uint8_t layer_groups[FG_LAYER_COUNT][FG_GROUP_SIZE];
    uint16_t expert_rank[FG_LAYER_COUNT][FG_EXPERT_COUNT];
    fg_tensor_record tensors[FG_MAX_TENSORS];
    fg_manifest_contract session;
    uint32_t execution_mode;
    uint32_t stage_count;
    uint8_t stage_ranks[FG_RANK_COUNT];
    uint32_t layer_offsets[FG_RESERVED_LAYER_OFFSETS];
    uint32_t slot_count;
    uint8_t topology_sha256[32];
    uint8_t topology_reserved[32];
    uint32_t ngram_shard_count;
    uint32_t deployment_reserved;
    fg_ngram_shard_record ngram_shards[FG_NGRAM_SHARD_COUNT];
    uint64_t host_resident_bytes[FG_RANK_COUNT];
} fg_manifest;

#define FG_MANIFEST_V4_BYTES ((size_t)offsetof(fg_manifest, session))
#define FG_MANIFEST_V5_BYTES ((size_t)offsetof(fg_manifest, execution_mode))
#define FG_MANIFEST_SIZE ((size_t)sizeof(fg_manifest))

void fg_manifest_init(fg_manifest *manifest);
fg_status fg_manifest_validate(const fg_manifest *manifest, fg_error *err);
fg_status fg_manifest_validate_deployment(const fg_manifest *manifest, fg_error *err);
fg_status fg_manifest_read(const char *path, fg_manifest *manifest, fg_error *err);
fg_status fg_manifest_write(const char *path, fg_manifest *manifest, fg_error *err);
fg_status fg_manifest_upgrade(const char *input_path, const char *output_path, fg_error *err);
fg_status fg_manifest_upgrade_with_profile(const char *input_path, const char *output_path,
                                           uint32_t runtime_profile, fg_error *err);
fg_status fg_manifest_add_tensor(fg_manifest *manifest, const fg_tensor_record *record, fg_error *err);
fg_status fg_manifest_validate_compatibility(const fg_manifest *manifest,
                                             uint32_t required_protocol_version,
                                             fg_position_mode position_mode,
                                             fg_error *err);
void fg_manifest_print(const fg_manifest *manifest);

#endif
