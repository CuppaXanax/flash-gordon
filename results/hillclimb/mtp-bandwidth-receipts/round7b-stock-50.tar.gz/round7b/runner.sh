#!/bin/bash
set -euo pipefail
cd /home/xander/hc-mtpk
mkdir -p round7b
cp "$0" round7b/runner.sh
export TMPDIR=$PWD/.build XDG_CACHE_HOME=$PWD/cache
active=()
for service in bc250-embed bc250-rerank; do
    if systemctl is-active --quiet "$service"; then active+=("$service"); fi
done
finish(){
    local rc=$?
    cd /home/xander/hc-mtpk
    for service in "${active[@]}"; do systemctl start "$service" || rc=1; done
    for service in "${active[@]}"; do
        port=8091
        if [ "$service" = bc250-rerank ]; then port=8092; fi
        curl --retry 60 --retry-connrefused --retry-delay 2 --max-time 3 \
            -fsS "http://192.168.42.50:$port/health" > "round7b/health-$port.json" || rc=1
    done
    cmp evidence/governor-original.toml /etc/cyan-skillfish-governor-smu/config.toml || rc=1
    if [ "$rc" != 0 ]; then
        for f in round7b/*.txt round7b/*.stderr; do echo "=== $f"; tail -10 "$f"; done
    fi
    tar -czf round7b.tar.gz round7b evidence
    exit "$rc"
}
trap finish EXIT
for service in "${active[@]}"; do systemctl stop "$service"; done
tar -xf candidate.tar -C src
cd src
export TMPDIR=$PWD/.build FG_SHADER_DIR=$PWD/vulkan FG_EXPERT_Q8_WIDE=1
make -s -j8 tools/bench-decode-fusion tests/test_fg_vk > ../round7b/build.txt 2>&1
sha256sum tools/bench-decode-fusion tests/test_fg_vk > ../round7b/binary-sha256.txt
FG_SMALL_KERNELS=2097482 DS4_REMOTE_TEST_FILTER=small_dense_vector_layout \
    ./tests/test_fg_vk > ../round7b/vector-residency.txt 2>&1
FG_SMALL_KERNELS=2097482 ./tools/bench-decode-fusion --q4 --no-clocks --dense-only \
    --dense-type 12 --dense-shape 1024 1025 --allow-reassociation \
    > ../round7b/vector-tail.jsonl 2> ../round7b/vector-tail.stderr
FG_SMALL_KERNELS=2097482 ./tools/bench-decode-fusion --q4 --small-n --no-clocks \
    --batch 2 --warmup 1 --iterations 1 --windows 1 --small-test \
    --session-test --rollback-test --allow-reassociation \
    > ../round7b/oracles.jsonl 2> ../round7b/oracles.stderr
