import collections
import json
from pathlib import Path
import re
import statistics
import sys

directory = Path(sys.argv[1])
result = {"scope": "diagnostic, not promotion; single-session mask330",
          "tokens_per_pass_definition": "emitted tokens per speculative verification round",
          "repair_pass_definition": "one additional target replay when consumed < drafted+1",
          "phases": {}, "comparisons": {}}
pattern = re.compile(r"MTP_ROUND slot=(\d+) first=(\d+) k=(\d+) accepted=(\d+) "
                     r"emitted=(\d+) consumed=(\d+) ms=([0-9.]+)")
phase_rows, phase_requests = {}, {}
for phase in ["A0", "D3", "A1", "F1", "A2", "F2", "A3", "F3", "A4"]:
    path = directory / f"{phase}-perf.json"
    if not path.exists():
        continue
    rows = json.loads(path.read_text(encoding="utf-8-sig"))["rows"]
    phase_rows[phase] = rows
    requests, pending = {}, []
    trace = directory / f"{phase}-rank-0.log"
    if trace.exists():
        for line in trace.read_text(encoding="utf-8").splitlines():
            match = pattern.search(line)
            if match:
                slot, first, k, accepted, emitted, consumed, ms = match.groups()
                assert slot == "0"
                pending.append(dict(k=int(k), accepted=int(accepted),
                                    emitted=int(emitted), consumed=int(consumed),
                                    milliseconds=float(ms)))
            token_hash = re.search(r"API_TOKEN_HASH id=(\S+) count=(\d+)", line)
            if token_hash:
                requests[token_hash[1]] = pending
                pending = []
    phase_requests[phase] = requests
    categories = {}
    for category in ["chat", "code"]:
        cases = [row for row in rows if row.get("category") == category]
        rounds = [item for row in cases for item in requests.get(row["id"], [])]
        emitted = sum(item["emitted"] for item in rounds)
        replays = sum(item["consumed"] < item["k"]+1 for item in rounds)
        total_k = sum(item["k"] for item in rounds)
        categories[category] = dict(
            requests=len(cases),
            decode_tps_median=statistics.median(row["decode_tps"] for row in cases),
            decode_tps_weighted=sum(row["tokens"] for row in cases)/
                                sum(row["decode_seconds"] for row in cases),
            wall_tps_median=statistics.median(row["wall_tps"] for row in cases),
            completion_tokens=sum(row["tokens"] for row in cases),
            rounds=len(rounds), emitted=emitted, repair_passes=replays,
            actual_k_counts=dict(collections.Counter(item["k"] for item in rounds)),
            tokens_per_pass=emitted/len(rounds) if rounds else None,
            tokens_per_verify_or_repair_pass=emitted/(len(rounds)+replays) if rounds else None,
            accepted_fraction=sum(item["accepted"] for item in rounds)/total_k if total_k else None,
            round_trace_requests_matched=sum(row["id"] in requests for row in cases),
            round_only_emitted_tps=emitted*1000/
                sum(item["milliseconds"] for item in rounds) if rounds else None)
    report = directory / f"{phase}-greedy-report.json"
    result["phases"][phase] = dict(categories=categories,
        greedy=json.loads(report.read_text()) if report.exists() else None)
for arm, left, right in [("D3", "A0", "A1"), ("F1", "A1", "A2"),
                          ("F2", "A2", "A3"), ("F3", "A3", "A4")]:
    if not all(phase in result["phases"] for phase in (arm, left, right)):
        continue
    result["comparisons"][arm] = {}
    for category in ["chat", "code"]:
        before, current, after = [result["phases"][phase]["categories"][category]
                                  for phase in (left, arm, right)]
        before_rows = {(row["case"], row["repeat"]): row for row in phase_rows[left]}
        after_rows = {(row["case"], row["repeat"]): row for row in phase_rows[right]}
        matched = [row for row in phase_rows[arm] if row["category"] == category and
                   (row["case"], row["repeat"]) in before_rows and
                   (row["case"], row["repeat"]) in after_rows]
        off = [statistics.mean([before_rows[row["case"], row["repeat"]]["decode_tps"],
                                after_rows[row["case"], row["repeat"]]["decode_tps"]])
               for row in matched]
        baseline = statistics.median(off)
        mtp = statistics.median(row["decode_tps"] for row in matched)
        rounds = [item for row in matched for item in phase_requests[arm][row["id"]]]
        emitted = sum(item["emitted"] for item in rounds)
        repair = sum(item["consumed"] < item["k"]+1 for item in rounds)
        result["comparisons"][arm][category] = dict(
            baseline_phases=[left, right], off_decode_tps=baseline,
            mtp_decode_tps=mtp, matched_requests=len(matched),
            unmatched_candidate_requests=current["requests"]-len(matched),
            rounds=len(rounds), emitted=emitted, repair_passes=repair,
            accepted_fraction=sum(item["accepted"] for item in rounds)/
                sum(item["k"] for item in rounds),
            tokens_per_pass=emitted/len(rounds),
            tokens_per_verify_or_repair_pass=emitted/(len(rounds)+repair),
            ratio=mtp/baseline,
            paired_ratio_median=statistics.median(row["decode_tps"]/value
                for row,value in zip(matched,off)))
Path(sys.argv[2]).write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result["comparisons"], indent=2))
