set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'mtp-s1-20261016-152247-diag'; bash '/home/xander/hc-mtp/lease.sh' start-serving A1 0 330 1 0
