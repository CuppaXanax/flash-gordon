set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'mtp-s1-20261016-152247'; bash '/home/xander/hc-mtp/lease.sh' verify
