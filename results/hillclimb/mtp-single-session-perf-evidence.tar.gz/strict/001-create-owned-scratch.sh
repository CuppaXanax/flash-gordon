set -euo pipefail
test ! -e '/home/xander/hc-mtp'; mkdir -p '/home/xander/hc-mtp'; printf '%s\n' 'mtp-s1-20261016-152247' > '/home/xander/hc-mtp/lease.id'
