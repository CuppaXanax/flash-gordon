set -eu
root=/home/xander/hc-mtp/rehearsal
cd "$root/source"
mkdir -p vulkan
cp ../vulkan/*.spv vulkan/
export TMPDIR="$root/cache" XDG_CACHE_HOME="$root/cache" FG_SHADER_DIR="$PWD/vulkan"
make -j12 -o shaders tests/test_fg_vk > ../oracle-build.log 2>&1
cp shaders/fg_small_hc_up_mix.glsl ../hc-stock.glsl
cp ../../hc-scale-hoisted.glsl shaders/fg_small_hc_up_mix.glsl
make -j2 vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_q8.spv > ../scale-build.log 2>&1
cp vulkan/fg_small_hc_up_mix_iq4.spv ../scale-iq4.spv
cp vulkan/fg_small_hc_up_mix_q8.spv ../scale-q8.spv
FG_BENCH_HC_INJECT=1 DS4_REMOTE_TEST_FILTER=small_hc_up_mix ./tests/test_fg_vk > ../scale-oracle.jsonl 2> ../scale-oracle.log
export FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
run(){
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ./tools/bench-decode-fusion "$@"' bash "$@"
}
for round in 1 2 3; do
    for tag in A0 B A1; do
        if test "$tag" = B; then
            cp ../scale-iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
            cp ../scale-q8.spv vulkan/fg_small_hc_up_mix_q8.spv
        else
            cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
            cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
        fi
        for n in 1 4; do
            run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" --iterations "$((216/n))" --windows 1 --allow-reassociation --no-clocks > "../scale-$round-$tag-$n.jsonl" 2> "../scale-$round-$tag-$n.log"
        done
    done
done
cp ../scale-iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
cp ../scale-q8.spv vulkan/fg_small_hc_up_mix_q8.spv
RADV_DEBUG=shaders,shaderstats MESA_SHADER_CACHE_DISABLE=true ./tools/bench-decode-fusion --q4 --mixed-experts --small-n --batch 4 --warmup 2 --iterations 1 --windows 1 --allow-reassociation --no-clocks > ../scale-isa.jsonl 2> ../scale-isa.log
cp ../hc-stock.glsl shaders/fg_small_hc_up_mix.glsl
cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
cd ..
tar -czf scale-evidence.tar.gz --exclude=scale-evidence.tar.gz scale-* oracle-build.log hc-stock.glsl counter-tools.log
echo SCALE_HOIST_AB_COMPLETE_NO_COUNTER_TOOLS_INSTALLED
