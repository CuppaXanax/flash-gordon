from collections import Counter
from datetime import datetime,timezone
import hashlib,io,json,re,statistics,subprocess,tarfile
from pathlib import Path

root=Path.cwd();base=root/".build/mtp-union-lease"
out=root/"results/hillclimb";run=base/"runs/union-20261017-0145"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def records(p):return [json.loads(l) for l in p.read_text().splitlines() if l.startswith("{")]
def utc(t):return datetime.fromtimestamp(t,timezone.utc).isoformat()
ratios=[]
for i in (1,2,3):
    row={"bracket":i}
    for n in (1,4):
        data={t:records(base/f"scale/scale-{i}-{t}-{n}.jsonl") for t in ("A0","B","A1")}
        times={t:statistics.median(r["wall_us"] for r in data[t] if r["kind"]=="sample") for t in data}
        row[str(n)]={"median_us":times,"B_over_bracket":times["B"]/statistics.mean([times["A0"],times["A1"]]),
                     "parity":{t:next(r for r in data[t] if r["kind"]=="parity") for t in data}}
    ratios.append(row)
opcode={}
for n in (2,4):
    source=(base/f"pressure/isa-{n}.log").read_text()
    opcode[str(n)]={}
    for name in ("fg_small_hc_up_mix_iq4.spv",f"fg_small_reuse8_q4_n{n}.spv"):
        b=next(b for b in re.split(r"(?=^VK_PIPELINE file=)",source,flags=re.M) if b.startswith("VK_PIPELINE file="+name+" "))
        lines=[l for l in b.splitlines() if re.search(r";\s*[0-9a-f]{8}",l)]
        if "hc_" in name:
            bars=[i for i,l in enumerate(lines) if "s_barrier" in l];lines=lines[bars[0]+1:bars[1]]
        c=Counter(l.strip().split()[0] for l in lines)
        opcode[str(n)][name]={k:v for k,v in c.items() if "cvt_f32" in k or "bfe_" in k or "mul_f32" in k}
route_count=0
for archive in run.glob("evidence-*.tar.gz"):
    with tarfile.open(archive) as t:
        route_count+=sum(len(t.extractfile(m).read().splitlines()) for m in t if "capture/verify-routes-" in m.name and m.isfile())
assert route_count==0
cleanup=json.loads((run/"038-remove-owned-scratch.json").read_text(encoding="utf-8-sig"))
assert len(cleanup)==8 and all(r["ExitCode"]==0 for r in cleanup)
assert all("2026-10-17T01:50:21Z" in r["Stdout"] for r in cleanup)
with tarfile.open(base/"rehearsal-evidence.tar.gz") as t:
    rehearsal=json.load(t.extractfile("rehearsal.json"))
data={
    "base_commit":"69ca796144ca33fa126735cddcc521016d94aa0b",
    "default_off":True,"promotion":False,
    "rehearsal":{
        "target":"192.168.42.51","CLI_all_candidate_options_pass":True,
        "runtime_numeric_double":rehearsal,
        "capture_client_four_HTTP_protocol_double_cases_pass":True,
        "trained_same_command_end_to_end_rehearsal":False,
        "limitation":"Component rehearsals were NOT a full trained API/worker/prefill capture rehearsal and were insufficient as fleet readiness.",
        "persistent_test":"make test-mtp-capture-ring; all48 layers, complete per-window multiplicities, N4, top10 validity",
    },
    "lease":{
        "grant_utc":"2026-10-17T01:37:00.395Z","maximum_minutes":15,
        "private_work_deadline_utc":"2026-10-17T01:49:00Z",
        "production_released_utc":"2026-10-17T01:50:21Z",
        "outcome":json.loads((run/"outcome.json").read_text(encoding="utf-8-sig")),
        "cleanup_receipts":cleanup,
        "actual_verify_route_records":route_count,
        "measured_union_ratio":None,"measured_union_weighted_floor":None,
        "completed_HTTP_cases":0,"first_requested_case":"chat-0",
        "last_logged_prefill":"chunk0, owner0 layers6..11 completed; no verifier routes",
        "root_cause":"unresolved; client exceeded remaining work budget during cold first request, not a proven kernel/transport diagnosis",
        "stage_receipt_local_write_utc":[{"file":p.name,"utc":utc(p.stat().st_mtime)} for p in sorted(run.glob("[0-9]*.json"))],
        "future_lease_readiness":"blocked until genuine trained cold-prefill/capture end-to-end rehearsal, not additional parser mocks",
    },
    "dequant_audit":{
        "dense":"reuse_weight performs bit extraction, scale decode and qlo/qhi FMA before all token-column accumulations",
        "HC":"quants/LUT lookup and d decode are outside token loop; d multiplies each token dot in one FMA",
        "static_conversion_counts":opcode,
        "counter_tools_found":[],
        "VALU_or_memory_busy_counters_measured":False,
        "alternative":"timestamp A/B with HC qlo/qhi scaled once before token loop",
        "compiler_stock":{"VALU":1034,"VMEM":46,"VGPRs":84},
        "compiler_hoisted":{"VALU":1098,"VMEM":46,"VGPRs":84},
        "brackets":ratios,
        "median_N4_B_over_A":statistics.median(r["4"]["B_over_bracket"] for r in ratios),
        "median_N1_B_over_A":statistics.median(r["1"]["B_over_bracket"] for r in ratios),
        "selected":False,
        "limitation":"Static opcodes are NOT achieved busy counters; no proof of ALU-bound service",
        "oracle_cases_passed":12,"target_precision":"unchanged >=Q4",
    },
    "offline_release":json.loads((base/"rehearsal-release.json").read_text(encoding="utf-8-sig")),
    "offline_released_utc":"2026-10-17T01:50:29Z",
    "validation":{"Linux_ring_capture_regression":"pass","Linux_capture_tests":8,
                  "C17_Werror_build":"pass","flag_registry":"pass"},
}
patch=subprocess.check_output(["git","diff","--binary","--","Makefile","tests/test_mtp_ring.c","tests/test_mtp_capture_ring.py"])
(base/"capture-rehearsal-source.diff").write_bytes(patch)
files=[base/p for p in ("rehearsal-evidence.tar.gz","client-rehearsal-evidence.tar.gz",
                       "rehearsal-final-evidence.tar.gz","scale-evidence.tar.gz",
                       "rehearsal-release.json","capture-rehearsal-source.diff",
                       "prepare-rehearsal.py","rehearsal.sh","client-rehearsal.py",
                       "client-rehearsal.sh","capture.ps1","capture-guard.sh","capture-client.py",
                       "scale-ab.sh","hc-scale-hoisted.glsl","rehearsal-final.sh",
                       "release-rehearsal.sh","publish-rehearsal.py")]
files += [p for p in run.rglob("*") if p.is_file() and p.suffix in (".sh",".ps1",".json",".gz",".stdout",".stderr")]
archive=out/"mtp-capture-rehearsal-evidence.tar.gz"
with tarfile.open(archive,"w:gz") as t:
    for p in sorted(set(files)):
        assert p.stat().st_size<16*1024*1024,p
        t.add(p,arcname=str(p.relative_to(base)).replace("\\","/"))
    t.add(root/"tests/test_mtp_capture_ring.py",arcname="source/tests/test_mtp_capture_ring.py")
data["evidence"]={"path":archive.name,"sha256":sha(archive),"bytes":archive.stat().st_size}
(out/"mtp-capture-rehearsal.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps({"ratio":data["dequant_audit"]["median_N4_B_over_A"],"evidence":data["evidence"]}))
