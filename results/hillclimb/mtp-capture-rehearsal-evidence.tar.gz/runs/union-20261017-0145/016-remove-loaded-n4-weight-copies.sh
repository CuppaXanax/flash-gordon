set -euo pipefail
rm '/home/xander/hc-mtp/native-q8.gguf' '/home/xander/hc-mtp/local-head.q8'; df -B1 '/home/xander/hc-mtp'
