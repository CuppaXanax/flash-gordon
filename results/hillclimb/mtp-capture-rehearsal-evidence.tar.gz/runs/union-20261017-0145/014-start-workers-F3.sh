set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'union-20261017-0145'; bash '/home/xander/hc-mtp/lease.sh' start-serving F3 3 330 1 3 1 440
