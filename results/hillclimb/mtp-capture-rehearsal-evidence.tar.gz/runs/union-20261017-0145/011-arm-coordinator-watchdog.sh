set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'union-20261017-0145'; bash '/home/xander/hc-mtp/lease.sh' arm 1792201860
