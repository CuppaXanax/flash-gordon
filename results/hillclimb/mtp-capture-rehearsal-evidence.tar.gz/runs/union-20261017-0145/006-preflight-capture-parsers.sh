set -euo pipefail
set -eu
root='/home/xander/hc-mtp'
mkdir -p "$root/capture-cli-preflight"
for role in api rank; do
    if "$root/release/flash-gordon" "$role" --mtp-capture-dir "$root/capture-cli-preflight" > "$root/capture-cli-$role.log" 2>&1; then
        echo "capture parser unexpectedly accepted missing manifest" >&2
        exit 1
    fi
    grep -q "$role requires --manifest" "$root/capture-cli-$role.log"
    if grep -q unknown "$root/capture-cli-$role.log"; then exit 1; fi
done
echo CAPTURE_PARSERS_READY_BEFORE_STOPPING_PRODUCTION
