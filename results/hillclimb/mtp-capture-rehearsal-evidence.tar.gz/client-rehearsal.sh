set -eu
cd /home/xander/hc-mtp
tar -xf client-rehearsal.tar
python3 client-rehearsal.py
cd rehearsal
tar -czf client-rehearsal-evidence.tar.gz client-rehearsal*.json
