#requires -Version 7.0
[CmdletBinding()]
param(
    [ValidateSet('Plan','Run','Restore')][string]$Action='Plan',
    [switch]$LeaseConfirmed,
    [ValidatePattern('^[A-Za-z0-9_-]{4,80}$')][string]$LeaseId='',
    [long]$LeaseStartedUnixSeconds=0,
    [ValidateRange(1,12)][int]$WorkMinutes=9,
    [ValidateSet('DualSession','SingleSessionPerf')][string]$Profile='DualSession',
    [switch]$DiagnosticGreedy,
    [switch]$N4Diagnostic,
    [string]$CorrectnessArtifacts='',
    [string]$LocalHead='',
    [string]$TransportSource='',
    [string]$Artifacts='',
    [string]$NativeOverlay='',
    [string]$ProductionRunner='D:\looking-glass-labs\fg-wt\ab-harness\tools\ab-fleet.ps1',
    [ValidatePattern('^http://(192\.168\.42\.42|127\.0\.0\.1)(:\d+)?$')]
    [string]$ApiBaseUrl='http://192.168.42.42:8080'
)
$ErrorActionPreference='Stop'
$repo=Split-Path 'D:\looking-glass-labs\fg-wt\mtp\tools' -Parent
if(-not $Artifacts){$Artifacts=Join-Path $repo '.build\mtp-serving-lease'}
if(-not $NativeOverlay){$NativeOverlay=Join-Path $repo '.build\mtp-lease\native-q8.gguf'}
$phases=@(@('A0',0,0),@('B0',0,330),
    @('K1',1,0),@('S1',1,330),@('A1',0,0),
    @('K2',2,0),@('S2',2,330),@('A2',0,0),
    @('K3',3,0),@('S3',3,330),@('A3',0,0))
$candidateSessions=2
$candidateQsaCacheMiB=if($LocalHead){440}else{640}
if($LocalHead -and $Profile -ne 'SingleSessionPerf'){
    throw 'The local-head performance lease requires the single-session profile; dual-session residency is unqualified.'
}
if($Profile -eq 'SingleSessionPerf'){
    $candidateSessions=1
    $phases=@(@('A0',0,330,0),@('D3',3,330,0),@('A1',0,330,0),
        @('F1',3,330,1),@('A2',0,330,0),@('F2',3,330,2),
        @('A3',0,330,0),@('F3',3,330,3),@('A4',0,330,0))
}
if($N4Diagnostic){
    if(-not $DiagnosticGreedy -or $Profile -ne 'SingleSessionPerf'){
        throw 'N4Diagnostic requires DiagnosticGreedy and SingleSessionPerf.'
    }
    $phases=@(@('A0',0,330,0),@('F3',3,330,3),@('A1',0,330,0))
}
$phases=,@('F3',3,330,3);$candidateSessions=1;$candidateQsaCacheMiB=440
if($Action -eq 'Plan'){
    [ordered]@{
        productionAccess=$false; ring='192.168.42.42-.49'; phases=$phases
        ready=$false; blocker='A trained cold-prefill/capture end-to-end rehearsal is required; component doubles are insufficient.'
        profile=$Profile;candidateSessions=$candidateSessions
        smallKernelMasks=$(if($candidateSessions -eq 1){@(330)}else{@(0,330)})
        greedy='off arms retain exact identity; MTP requires receipt-complete pass-local argmax, same-prefix top2 margins <0.10 and original-Q8 KL<=0.005/top1>=0.985'
        diagnosticOnly=[bool]$DiagnosticGreedy
        n4Diagnostic=[bool]$N4Diagnostic
        localDraftHead=[bool]$LocalHead
        candidateQsaPageCacheMiB=$candidateQsaCacheMiB
        perf='capture only: real chat/code speculative router IDs; no TPS qualification'
        coexist=$(if($candidateSessions -eq 1){'none; sequential single-session chat/code; SSE/stop/cancel on D3/F3'}else{'three two-session chat/code overlaps per phase; SSE/stop/cancel on K3/S3'})
        workDeadlineMinutes=$WorkMinutes; watchdogWorkerMinute=13; watchdogCoordinatorMinute=14
        wallBudgetMinutes=15
        restore='31508ee / 20261016-abq-stack-adaptive + sealed mix-04, sessions2 wide1; exact pinned launcher/env'
        exclusions='no clocks/governors/serving-ref changes; model quality is not waived by low-margin drift; no promotion or long-context claim'
    } | ConvertTo-Json -Depth 8
    return
}
if($Action -eq 'Run'){
    throw 'Capture runs blocked: resolve and rehearse the trained cold-prefill/capture path offline before requesting another lease.'
}
if(-not $LeaseConfirmed -or -not $LeaseId){
    throw 'Explicit exclusive ring lease confirmation and a fresh LeaseId are required.'
}
$release=Join-Path $Artifacts 'repaired-release.tar.gz'

if(-not $DiagnosticGreedy){throw 'Capture-only diagnostic acknowledgement required.'}
if((Get-FileHash $NativeOverlay -Algorithm SHA256).Hash.ToLowerInvariant() -ne
 '536bab54b0a1bdea23b65871c4cdc38deee5803771501a0c770a0510bcd3283b'){throw 'Native overlay mismatch'}
$localHeadSha256=(Get-FileHash $LocalHead -Algorithm SHA256).Hash.ToLowerInvariant()
if($localHeadSha256 -ne '2801d79db74bcae38b47fd5051f03136d8ca7715abeba7d92b49ba46c696bc33'){throw 'Full draft head mismatch'}
$all=@(42..49 | ForEach-Object {"192.168.42.$_"})
$workers=@(43..49 | ForEach-Object {"192.168.42.$_"})
$root='/home/xander/hc-mtp'
$run=Join-Path $Artifacts "runs\$LeaseId"
if($Action -eq 'Run' -and (Test-Path $run)){throw 'Lease evidence is immutable; use a fresh LeaseId.'}
$null=New-Item -ItemType Directory -Force $run
$started=if($LeaseStartedUnixSeconds){[DateTimeOffset]::FromUnixTimeSeconds($LeaseStartedUnixSeconds)}else{[DateTimeOffset]::UtcNow}
$script:workEnd=$started.AddMinutes($WorkMinutes)
$script:restoreMode=$Action -eq 'Restore'
$script:sequence=0
function Remote {
    param([string]$Name,[string]$Text,[string[]]$Targets,
          [string]$Upload='',[string]$Destination='',[string]$Download='',
          [string]$Local='',[int]$Timeout=180)
    $remaining=if($script:restoreMode){300}else{[int]($script:workEnd-[DateTimeOffset]::UtcNow).TotalSeconds}
    if($remaining -le 0){throw 'Serving qualification deadline reached; restore now.'}
    $script:sequence++
    $tag='{0:D3}-{1}' -f $script:sequence,$Name
    $file=Join-Path $run "$tag.sh"
    [IO.File]::WriteAllText($file,"set -euo pipefail`n"+($Text -replace "`r",'')+"`n")
    $arguments=@{ScriptPath=$file;Targets=$Targets;PassThru=$true;CommandTimeout=[Math]::Max(60,[Math]::Min($Timeout,$remaining))}
    if($Upload){$arguments.UploadPath=$Upload;$arguments.UploadDestination=$Destination}
    if($Download){$arguments.DownloadSource=$Download;$arguments.DownloadPath=$Local}
    $results=@(& $ProductionRunner @arguments)
    $results | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $run "$tag.json")
    if($results.Count -ne $Targets.Count -or @($results | Where-Object ExitCode -ne 0).Count){
        throw "Fleet step $tag failed."
    }
    return $results
}
function Guard {
    param([string]$Name,[string]$Command,[string[]]$Targets)
    Remote $Name "test `"`$(cat '$root/lease.id')`" = '$LeaseId'; bash '$root/lease.sh' $Command" $Targets
}
function ApiCheck {
    $health=Invoke-RestMethod "$ApiBaseUrl/health" -TimeoutSec 3
    $models=Invoke-RestMethod "$ApiBaseUrl/v1/models" -TimeoutSec 5
    if($health.status -ne 'ok' -or $models.data[0].id -ne 'Qwen3.8-Flash-Next-Uncensored'){
        throw 'API health/model mismatch.'
    }
    return @{health=$health;models=$models}
}
function ApiGreedy {
    $body=@{model='Qwen3.8-Flash-Next-Uncensored';temperature=0;max_tokens=16
        user='lease-health';messages=@(@{role='user';content='/no_think Output exactly OK.'})} |
        ConvertTo-Json -Depth 6
    $result=Invoke-RestMethod "$ApiBaseUrl/v1/chat/completions" -Method Post `
        -ContentType application/json -Body $body -TimeoutSec 60
    if([string]::IsNullOrWhiteSpace($result.choices[0].message.content)){throw 'Empty greedy health response.'}
    return $result
}
function WaitApi {
    $end=[DateTimeOffset]::UtcNow.AddSeconds(150)
    if(-not $script:restoreMode -and $end -gt $script:workEnd){$end=$script:workEnd}
    do {
        try {return ApiCheck}catch{Start-Sleep -Seconds 2}
    } while([DateTimeOffset]::UtcNow -lt $end)
    throw 'API failed readiness deadline.'
}
function Client {
    param([string[]]$Arguments)
    if([DateTimeOffset]::UtcNow -ge $script:workEnd){throw 'Client work deadline reached.'}
    $seconds=[Math]::Min(300,[int]($script:workEnd-[DateTimeOffset]::UtcNow).TotalSeconds)
    $out=Join-Path $run "client-$([guid]::NewGuid().ToString('N')).stdout"
    $err=Join-Path $run "$([IO.Path]::GetFileNameWithoutExtension($out)).stderr"
    $start=[Diagnostics.ProcessStartInfo]::new('python')
    $start.UseShellExecute=$false
    $start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
    $start.ArgumentList.Add((Join-Path $Artifacts 'capture-client.py'))
    foreach($argument in $Arguments){$start.ArgumentList.Add($argument)}
    if($DiagnosticGreedy -and $Arguments[0] -eq 'run'){$start.ArgumentList.Add('--diagnostic')}
    $process=[Diagnostics.Process]::Start($start)
    $stdout=$process.StandardOutput.ReadToEndAsync();$stderr=$process.StandardError.ReadToEndAsync()
    if(-not $process.WaitForExit([Math]::Max(1,$seconds)*1000)){
        $process.Kill($true);$process.WaitForExit()
        [IO.File]::WriteAllText($out,$stdout.GetAwaiter().GetResult())
        [IO.File]::WriteAllText($err,$stderr.GetAwaiter().GetResult())
        throw 'HTTP client timed out; restore production.'
    }
    [IO.File]::WriteAllText($out,$stdout.GetAwaiter().GetResult())
    [IO.File]::WriteAllText($err,$stderr.GetAwaiter().GetResult())
    if($process.ExitCode){throw "HTTP client failed; see $err"}
}
function RestoreProduction {
    $script:restoreMode=$true
    $restoreErrors=@()
    try {$null=Guard 'stop-candidates' 'stop-candidate' $all}catch{$restoreErrors+=$_.Exception.Message}
    try {$null=Guard 'restore-workers' 'restore' $workers}catch{$restoreErrors+=$_.Exception.Message}
    try {$null=Guard 'restore-coordinator' 'restore' @('192.168.42.42')}catch{$restoreErrors+=$_.Exception.Message}
    $api=WaitApi
    $greedy=ApiGreedy
    $null=Guard 'verify-pinned-production' 'verify' $all
    @{api=$api;greedy=$greedy} | ConvertTo-Json -Depth 30 |
        Set-Content -Encoding utf8 (Join-Path $run 'restored-api.json')
    $null=Guard 'cancel-watchdogs' 'cancel' $all
    if($restoreErrors.Count){Write-Warning ($restoreErrors -join '; ')}
    return $greedy
}
if($Action -eq 'Restore'){
    $null=RestoreProduction
    Write-Output 'Current stack-1/mix-04 sessions2 wide1 production restored and verified.'
    return
}
$created=$false;$armed=$false;$mutated=$false;$complete=$false;$failure=$null;$before=$null
$productionVerified=$false;$scratchRemoved=$false;$finalizationErrors=@()
try {
    $created=$true
    $null=Remote 'create-owned-scratch' "test ! -e '$root'; mkdir -p '$root'; printf '%s\n' '$LeaseId' > '$root/lease.id'" $all
    $guardFile=Join-Path $run 'lease.sh'
    [IO.File]::WriteAllText($guardFile,([IO.File]::ReadAllText((Join-Path $Artifacts 'capture-guard.sh')) -replace "`r",''))
    $null=Remote 'upload-guard' ':' $all -Upload $guardFile -Destination "$root/lease.sh"
    $checks=@(Guard 'preflight-production' 'preflight' $all)
    foreach($check in $checks){
        $epochs=@($check.Stdout -split "`r?`n" | Where-Object {$_ -match '^[0-9]{10}$'})
        if($epochs.Count -ne 1 -or [Math]::Abs([long]$epochs[0]-[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) -gt 30){
            throw 'Owner/watchdog clock skew exceeds thirty seconds.'
        }
    }
    $before=ApiGreedy
    $before | ConvertTo-Json -Depth 30 | Set-Content -Encoding utf8 (Join-Path $run 'before-api.json')
    $null=Remote 'stage-release' ':' $all -Upload $release -Destination "$root/release.tar.gz"
    $null=Guard 'stage-serving' 'stage-serving' $all
    $smoke = @'
set -eu
root='__ROOT__'
mkdir -p "$root/capture-cli-preflight"
for role in api rank; do
    if "$root/release/flash-gordon" "$role" --mtp-capture-dir "$root/capture-cli-preflight" > "$root/capture-cli-$role.log" 2>&1; then
        echo "capture parser unexpectedly accepted missing manifest" >&2
        exit 1
    fi
    grep -q "$role requires --manifest" "$root/capture-cli-$role.log"
    if grep -q unknown "$root/capture-cli-$role.log"; then exit 1; fi
done
echo CAPTURE_PARSERS_READY_BEFORE_STOPPING_PRODUCTION
'@
    $null=Remote 'preflight-capture-parsers' ($smoke.Replace('__ROOT__',$root)) $all
    $null=Remote 'stage-native-final-owner' "echo '536bab54b0a1bdea23b65871c4cdc38deee5803771501a0c770a0510bcd3283b  $root/native-q8.gguf' | sha256sum -c -" `
        @('192.168.42.49') -Upload $NativeOverlay -Destination "$root/native-q8.gguf" -Timeout 240
    $embedding=Join-Path $run 'embedding.fgme'
    $null=Remote 'fetch-exact-embedding' ':' @('192.168.42.42') -Download "$root/embedding.fgme" -Local $embedding
    $null=Remote 'stage-exact-embedding-final-owner' ':' @('192.168.42.49') -Upload $embedding -Destination "$root/embedding.fgme"
    if($LocalHead -and -not $N4Diagnostic){
        $null=Remote 'stage-local-head-final-owner' "echo '$localHeadSha256  $root/local-head.q8' | sha256sum -c -" `
            @('192.168.42.49') -Upload $LocalHead -Destination "$root/local-head.q8" -Timeout 240
    }
    $armed=$true
    $null=Guard 'arm-worker-watchdogs' "arm $($started.AddMinutes(13).ToUnixTimeSeconds())" $workers
    $null=Guard 'arm-coordinator-watchdog' "arm $($started.AddMinutes(14).ToUnixTimeSeconds())" @('192.168.42.42')
    if($TransportSource){
        if(-not $DiagnosticGreedy){throw 'Transport probing requires a diagnostic lease.'}
        $pair=@('192.168.42.48','192.168.42.49')
        $null=Remote 'stage-transport-source' ':' $pair -Upload $TransportSource -Destination "$root/transport-source.tar.gz"
        $text=@'
mkdir -p /home/xander/hc-mtp/transport
tar -xzf /home/xander/hc-mtp/transport-source.tar.gz -C /home/xander/hc-mtp/transport
cd /home/xander/hc-mtp/transport
gcc -std=c17 -O3 -Wall -Wextra -Werror -D_POSIX_C_SOURCE=200809L -Iinclude -ffunction-sections -fdata-sections -Wl,--gc-sections tools/bench_mtp_transport.c src/protocol.c src/util.c -lm -o bench
if [[ " $(hostname -I) " == *" 192.168.42.48 "* ]]; then
    timeout 90s ./bench server 192.168.42.48 26840
else
    timeout 90s ./bench client 192.168.42.48 26840 | tee /home/xander/hc-mtp/transport.jsonl
fi
'@
        $null=Remote 'measure-n1-n4-transport' $text $pair -Timeout 120
    }
    foreach($phase in $phases){
        $name=[string]$phase[0];$cap=[int]$phase[1];$small=[int]$phase[2]
        $fixed=if($phase.Count -gt 3){[int]$phase[3]}else{0}
        if(-not $mutated){$mutated=$true;$null=Guard 'stop-production' 'stop-prod' $all}
        else {$null=Guard "stop-before-$name" 'stop-candidate' $all}
        if($N4Diagnostic -and $LocalHead -and $cap){
            $null=Remote 'stage-n4-local-head' "echo '$localHeadSha256  $root/local-head.q8' | sha256sum -c -" `
                @('192.168.42.49') -Upload $LocalHead -Destination "$root/local-head.q8" -Timeout 240
        }
        $localHeadEnabled=[int][bool]$LocalHead
        $null=Guard "start-workers-$name" "start-serving $name $cap $small $candidateSessions $fixed $localHeadEnabled $candidateQsaCacheMiB" $workers
        $null=Guard "start-coordinator-$name" "start-serving $name $cap $small $candidateSessions $fixed $localHeadEnabled $candidateQsaCacheMiB" @('192.168.42.42')
        $null=WaitApi
        if($N4Diagnostic -and $LocalHead -and $cap){
            $null=Remote 'remove-loaded-n4-weight-copies' "rm '$root/native-q8.gguf' '$root/local-head.q8'; df -B1 '$root'" @('192.168.42.49')
        }

        foreach($case in @('chat-0','chat-1','code-0','code-1')){
            Client @('--base',$ApiBaseUrl,'--case',$case,'--output',(Join-Path $run "$case.json"))
            $null=Remote "bind-$case" "python3 -c `"import glob,json;print(json.dumps(sorted(glob.glob('$root/capture/verify-routes-*.jsonl'))))`"" @('192.168.42.42')
        }
    }
    $complete=$true
} catch {$failure=$_}
finally {
    if($mutated -or $armed){
        try {
            $restored=RestoreProduction
            $productionVerified=$true
            if($before.choices[0].message.content -ne $restored.choices[0].message.content){
                throw 'Restored production greedy sanity differs from pre-lease.'
            }
        } catch {
            $finalizationErrors+=$_.Exception.Message
            if(-not $failure){$failure=$_}
        }
        if($productionVerified){
            foreach($ip in $all){
                try {
                    $null=Guard "evidence-$ip" 'evidence' @($ip)
                    $null=Remote "download-evidence-$ip" ':' @($ip) -Download "$root/final-evidence.tar.gz" `
                        -Local (Join-Path $run "evidence-$ip.tar.gz")
                } catch {
                    $finalizationErrors+=$_.Exception.Message
                    if(-not $failure){$failure=$_}
                }
            }
            try {
                $null=Guard 'remove-owned-scratch' 'cleanup' $all
                $scratchRemoved=$true
            } catch {
                $finalizationErrors+=$_.Exception.Message
                if(-not $failure){$failure=$_}
            }
        }
    } elseif($created){
        try {
            $null=Remote 'cleanup-unstarted' "if test -f '$root/lease.id' && test `"`$(cat '$root/lease.id')`" = '$LeaseId'; then test ! -e '$root/candidate.pid'; test ! -e '$root/watchdog.pid'; cd /home/xander; rm -rf '$root'; fi" $all
            $scratchRemoved=$true
        } catch {
            $finalizationErrors+=$_.Exception.Message
            if(-not $failure){$failure=$_}
        }
    }
    @{lease=$LeaseId;complete=$complete;failure=[string]$failure;
        diagnosticOnly=$DiagnosticGreedy.IsPresent;
        productionVerified=$productionVerified;scratchRemoved=$scratchRemoved;
        finalizationErrors=$finalizationErrors;
        elapsedSeconds=([DateTimeOffset]::UtcNow-$started).TotalSeconds} |
        ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $run 'outcome.json')
}
if($failure){throw $failure}
if(-not $complete){throw 'Serving qualification incomplete; no performance or exactness claim.'}
Write-Output "MTP serving sweep complete (diagnosticOnly=$DiagnosticGreedy); pinned production restored. Evidence: $run"
