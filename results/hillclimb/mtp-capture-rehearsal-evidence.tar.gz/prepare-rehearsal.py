import io,subprocess,tarfile
from pathlib import Path
r=Path.cwd();b=r/".build/mtp-union-lease"
raw=subprocess.check_output(["git","archive","HEAD"])
with tarfile.open(fileobj=io.BytesIO(raw)) as source,tarfile.open(b/"rehearsal-source.tar.gz","w:gz") as out:
    for m in source:
        if m.isfile():
            data=(r/m.name).read_bytes() if m.name in ("Makefile","tests/test_mtp_ring.c") else source.extractfile(m).read()
            m.size=len(data);out.addfile(m,io.BytesIO(data))
with tarfile.open(b/"repaired-release.tar.gz") as source,tarfile.open(b/"rehearsal-assets.tar.gz","w:gz") as out:
    for m in source:
        if m.isfile():out.addfile(m,source.extractfile(m))
    with tarfile.open(r/".build/mtp-op-floor/candidate-release.tar.gz") as old:
        m=old.getmember("tests/test_fg_vk");out.addfile(m,old.extractfile(m))
shader=(r/"shaders/fg_small_hc_up_mix.glsl").read_text()
shader=shader.replace("[[unroll]]for(uint t=0u;t<TOKENS;t++)\n                acc[t][r]=fma(d,dot(q0,a[t])+dot(q1,b[t]),acc[t][r]);",
    "q0*=d;q1*=d;\n            [[unroll]]for(uint t=0u;t<TOKENS;t++)\n                acc[t][r]+=dot(q0,a[t])+dot(q1,b[t]);")
assert "q0*=d;q1*=d;" in shader
(b/"hc-scale-hoisted.glsl").write_text(shader)
