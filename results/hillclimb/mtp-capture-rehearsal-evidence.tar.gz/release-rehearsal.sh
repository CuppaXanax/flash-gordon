set -eu
root=/home/xander/hc-mtp
cd "$root/rehearsal"
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > governor-now.sha256
cmp governor.sha256 governor-now.sha256
cd /home/xander
sudo -n python3 - "$0" <<'PY'
import json,os,pathlib,sys
root=pathlib.Path("/home/xander/hc-mtp")
allowed={"rehearsal","rehearsal-source.tar.gz","rehearsal-assets.tar.gz",
         "client-rehearsal.tar","client-rehearsal.py","capture-client.py",
         "hc-scale-hoisted.glsl","rehearsal-update.tar",pathlib.Path(sys.argv[1]).name}
entries={p.name for p in root.iterdir()}
assert entries==allowed,entries
owned=[]
for p in pathlib.Path("/proc").iterdir():
    if not p.name.isdigit() or int(p.name) in (os.getpid(),os.getppid()):continue
    try:exe,cwd=os.readlink(p/"exe"),os.readlink(p/"cwd")
    except (FileNotFoundError,PermissionError,ProcessLookupError):continue
    if exe.startswith(str(root)+"/") or cwd.startswith(str(root)+"/rehearsal"):
        owned.append((p.name,exe,cwd))
assert not owned,owned
print(json.dumps({"owned_processes":0,"governors_unchanged":True,"entries":sorted(entries)}))
PY
sudo -n rm -rf -- "$root"
test ! -e "$root"
sleep 2
test ! -e "$root"
printf 'RELEASED_51 owned_root_absent_twice %s\n' "$(date -u +%FT%TZ)"
