import http.server,json,subprocess,sys,threading
from pathlib import Path
base=Path("/home/xander/hc-mtp/rehearsal")
source=base/"source"
client=source/".build/mtp-union-lease/capture-client.py"
client.parent.mkdir(parents=True,exist_ok=True)
client.write_bytes((base.parent/"capture-client.py").read_bytes())
seen=[]
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        assert self.path=="/v1/chat/completions" and body["max_tokens"]==80
        assert body["temperature"]==0 and not body["stream"]
        seen.append(body["user"])
        result={"id":"fixture-"+body["user"],"choices":[{"message":{"role":"assistant","content":"fixture only"},"finish_reason":"length"}],"usage":{"completion_tokens":80}}
        raw=json.dumps(result).encode()
        self.send_response(200);self.send_header("Content-Length",str(len(raw)))
        self.send_header("X-Flash-Gordon-Decode-Seconds","1")
        self.end_headers();self.wfile.write(raw)
server=http.server.HTTPServer(("127.0.0.1",0),Handler)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
    for case in ("chat-0","chat-1","code-0","code-1"):
        output=base/f"client-rehearsal-{case}.json"
        subprocess.run([sys.executable,str(client),"--base",f"http://127.0.0.1:{server.server_port}","--case",case,"--output",str(output)],check=True)
        row=json.loads(output.read_text());assert row["tokens"]==80 and row["timing_valid"] is False
    assert len(seen)==4
finally:server.shutdown();server.server_close();thread.join()
(base/"client-rehearsal.json").write_text(json.dumps({"scope":"exact capture client, protocol-double HTTP server; NOT model outputs","cases":4,"requests":seen}))
print("EXACT_CAPTURE_CLIENT_FOUR_CASES_PASS_PROTOCOL_DOUBLE")
