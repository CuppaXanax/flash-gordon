set -eu
root=/home/xander/hc-mtp
mkdir -p "$root/rehearsal/source" "$root/rehearsal/cache" "$root/rehearsal/capture"
cd "$root/rehearsal"
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > governor.sha256
tar -xzf ../rehearsal-source.tar.gz -C source
tar -xzf ../rehearsal-assets.tar.gz
export TMPDIR="$PWD/cache" XDG_CACHE_HOME="$PWD/cache"
cd source
make -j12 flash-gordon tests/test_mtp_ring tools/bench-decode-fusion > ../build.log 2>&1
./tests/test_mtp_ring 127.0.0.1 127.0.0.1 29760 3 2 7 1 ../capture > ../ring.log 2>&1
python3 -m unittest discover -s tests -p test_mtp_capture.py > ../capture-tests.log 2>&1
cd ..
python3 - <<'PY'
import json,pathlib
files=list(pathlib.Path('capture').glob('verify-routes-*.jsonl'))
rows=[json.loads(l) for p in files for l in p.read_text().splitlines()]
assert rows
assert {r['layer'] for r in rows}==set(range(48))
assert any(r['n']==4 for r in rows), rows[0]
print(json.dumps({'scope':'numerical-double ring, NOT trained weights','records':len(rows),'layers':48}))
pathlib.Path('rehearsal.json').write_text(json.dumps({'scope':'numerical-double ring','records':len(rows),'layers':48}))
PY
for role in api rank; do
    set -- "$role" --mtp-capture-dir "$root/rehearsal/capture"
    if test "$role" = api; then
        set -- "$@" --model-name Qwen3.8-Flash-Next-Uncensored --host 0.0.0.0 --port 8080 --context-tokens 262144 --gpu-index-tokens 262144 --qsa-hot-tokens 0 --qsa-page-cache-mib 440 --sessions 1 --experimental-mtp --mtp-overlay "$root/native-q8.gguf" --mtp-embedding "$root/embedding.fgme" --mtp-window 8192 --mtp-max-draft 3 --mtp-fixed-draft 3 --mtp-local-head "$root/local-head.q8"
    else set -- "$@" --rank 7; fi
    if ./flash-gordon "$@" > "cli-$role.log" 2>&1; then exit 1; fi
    grep -q "$role requires --manifest" "cli-$role.log"
done
for tool in rocprof rocprofv2 rocprofv3 rgp; do command -v "$tool" || true; done > counter-tools.log
tar -czf rehearsal-evidence.tar.gz build.log ring.log capture-tests.log rehearsal.json cli-*.log counter-tools.log capture governor.sha256
echo NUMERICAL_RING_CAPTURE_AND_EXACT_API_OPTIONS_PASS
