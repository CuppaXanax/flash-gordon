set -eu
cd /home/xander/hc-mtp/rehearsal/source
tar -xf ../../rehearsal-update.tar
export TMPDIR="$PWD/../cache" XDG_CACHE_HOME="$PWD/../cache"
make -j12 tests/test_mtp_ring test-mtp-capture-ring > ../ring-regression.log 2>&1
python3 -m unittest discover -s tests -p test_mtp_capture.py > ../capture-final.log 2>&1
bash tools/check-flags.sh > ../flags-final.log
sha256sum tests/test_mtp_ring.c tests/test_mtp_capture_ring.py Makefile > ../ring-inputs.sha256
cd ..
tar -czf rehearsal-final-evidence.tar.gz ring-regression.log capture-final.log flags-final.log ring-inputs.sha256
echo PERSISTENT_ALL_OWNER_CAPTURE_REGRESSION_PASS
