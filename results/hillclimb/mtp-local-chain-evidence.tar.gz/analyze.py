import collections
import hashlib
import io
import json
import math
from pathlib import Path
import re
import statistics as st
import sys
import tarfile

root = Path.cwd()
data = root / ".build" / "mtp-local"
sys.path.insert(0, str(root / "tools"))
from mtp_diagnose import validate_stage_ledgers


def sha(b):
    return hashlib.sha256(b).hexdigest()


def summary(values):
    values = sorted(values)
    return dict(samples=len(values), mean=st.mean(values), median=st.median(values),
                p95=values[math.ceil(len(values)*.95)-1], maximum=max(values))


with tarfile.open(data / "evidence.tar.gz") as evidence:
    def read(name):
        return evidence.extractfile(name).read()

    chain = [json.loads(x) for x in read("chain-final.jsonl").splitlines()]
    receipt, chain = chain[-1], chain[:-1]
    states = [json.loads(x) for x in read("state-perf.jsonl").splitlines()]
    states = [r for r in states if r["kind"] == "state_commit_test"]
    assert len(states) == 24 and receipt["cases"] == 40
    assert sum(3 for r in chain) == receipt["draft_tokens_reference_equal"]
    assert all(r["reference_equal"] for r in chain)
    for row in states:
        assert all(row[k] for k in ("hc_untouched", "stale_rejected", "rollback_exact",
                    "journal_full_state_exact", "static_replay_retained", "tolerance_ok"))
    stage_count = choice_count = chain_rounds = 0
    for member in evidence.getmembers():
        if member.name.startswith("tcp/") and member.name.endswith(".log"):
            text = read(member.name).decode()
            assert "MTP synthetic 8-rank runtime" in text
            stage_count += validate_stage_ledgers(text)
            choices = re.findall(r"MTP_CHOICE .*?emitted=(\d+) target_argmax=(\d+)", text)
            assert choices and all(a == b for a, b in choices)
            choice_count += len(choices)
            chain_rounds += text.count("MTP_LOCAL_CHAIN ")
    source = read("delta.tar.gz")
    source_inputs = {}
    with tarfile.open(fileobj=io.BytesIO(source)) as bundle:
        for member in bundle.getmembers():
            path = root / member.name
            if member.isfile() and (Path(member.name).suffix in (".c", ".h", ".inc", ".py", ".comp", ".sh", ".ps1")
                                    or member.name == "Makefile"):
                actual = path.read_bytes().replace(b"\r\n", b"\n")
                assert actual == bundle.extractfile(member).read(), member.name
                source_inputs[member.name] = sha(actual)

transport_path = data / "transport.json"
if not transport_path.exists():
    transport_path = Path(r"D:\looking-glass-labs\fg-wt\bf16-hops\.build\fp16-hop-pair.json")
transport_bytes = transport_path.read_bytes()
assert sha(transport_bytes) == "58555eaed22367401c9f30d3ce149c6de04ba4ad11bb7db415a7f56e16fac106"
transport = [json.loads(line) for result in json.loads(transport_bytes)
             for line in result.get("Stdout", "").splitlines() if line.startswith("{")]
primary_series = transport[:30]
assert len(primary_series) == 30
assert {r["codec"] for r in primary_series if r["compressed"]} == {"fp16"}
f32 = [r for r in primary_series if r["codec"] == "f32"]
rounds = sorted({r["round"] for r in f32})
assert len(rounds) == 5 and all(r["codec_validated"] for r in f32)
ordinary = st.mean(st.mean(r["rtt_mean_us"]/2000 for r in f32
                  if r["round"] == i and not r["ngram"]) for i in rounds)
initial = st.mean(st.mean(r["rtt_mean_us"]/2000 for r in f32
                 if r["round"] == i and r["ngram"]) for i in rounds)
wire = [7*st.mean(r["rtt_mean_us"]/2000 for r in f32 if r["round"] == i and not r["ngram"])
        + st.mean(r["rtt_mean_us"]/2000 for r in f32 if r["round"] == i and r["ngram"])
        for i in rounds]
wire1 = st.mean(wire)
wire_ci = 2.7764451051977987*st.stdev(wire)/math.sqrt(len(wire))
p50_wire = [7*st.mean(r["hop_rtt_over_2_p50_us"]/1000 for r in f32
                     if r["round"] == i and not r["ngram"])
            + st.mean(r["hop_rtt_over_2_p50_us"]/1000 for r in f32
                      if r["round"] == i and r["ngram"]) for i in rounds]
diagnosis = json.loads((root/"results/hillclimb/mtp-diagnosis.json").read_text())
historic = json.loads((root/"results/hillclimb/mtp-single-session-perf.json").read_text())
target = diagnosis["offline_model"]["summed_median_owner_compute_ms_by_n"]
off_tps = historic["comparisons"]["F3"]["code"]["off_decode_tps"]
calibration = 1000/off_tps-target["1"]-wire1

groups = {}
for category in ("chat", "code"):
    warm = [r for r in chain if r["category"] == category and r["round"] >= 2]
    prefixes = [r for r in chain if r["category"] == category and r["mode"] == 0]
    cases = collections.defaultdict(dict)
    for row in prefixes:
        assert row["position"] not in cases[row["case"]]
        cases[row["case"]][row["position"]] = row
    keeps, emitted = collections.Counter(), 0
    for case in cases.values():
        assert set(case) == set(range(256))
        position = 0
        while position < 256:
            keep = min(1+case[position]["accepted"], 256-position)
            keeps[keep] += 1
            emitted += keep
            position += keep
    repair = {k: st.mean(r["native_repair_ms"] for r in warm if r["mode"] == 1 and r["keep"] == k)
              for k in range(1, 5)}
    groups[category] = dict(draft_k3_ms=summary([r["draft_ms"] for r in warm]),
        full_vocab_three_calls_ms=summary([r["reference_vocab_ms"] for r in warm]),
        native_repair_ms_by_keep=repair, frozen_positions=len(prefixes),
        all_prefix_mean_accepted=st.mean(r["accepted"] for r in prefixes),
        fixed_k3_simulated_rounds=sum(keeps.values()), fixed_k3_simulated_emissions=emitted,
        fixed_k3_simulated_tokens_per_verify=emitted/sum(keeps.values()),
        fixed_k3_simulated_keep_counts=dict(keeps),
        simulated_native_repair_mean_ms=sum(keeps[k]*repair[k] for k in keeps)/sum(keeps.values()))

n4 = [r for r in states if r["n"] == 4]
snapshot = summary([r["snapshot_us"]/1000 for r in n4])
retain = summary([r["retain_us"]/1000 for r in n4])
code = groups["code"]
components = dict(target_n4_owner_proxy_ms=target["4"], n4_wire_proportional_model_ms=4*wire1,
    cross_cohort_n1_calibration_allowance_ms=calibration,
    native_k3_mean_ms=code["draft_k3_ms"]["mean"],
    extra_three_vocab_calls_full_head_proxy_ms=code["full_vocab_three_calls_ms"]["mean"],
    extra_three_head_rpc_budget_ms=6*ordinary,
    local_chain_rpc_budget_ms=2*ordinary,
    parallel_owner_snapshot_p95_proxy_ms=snapshot["p95"],
    parallel_owner_retain_p95_proxy_ms=retain["p95"],
    snapshot_and_retain_control_budget_ms=4*ordinary,
    extra_n4_host_lookup_budget_ms=1.5,
    native_repair_simulated_mean_ms=code["simulated_native_repair_mean_ms"])
modeled = sum(components.values())
memory_extra = 675430400+248320*4+4*31040*4
prior_rank7 = 13982045224
journal_one = 1646080
cap = 14495514624
memory_700 = prior_rank7+memory_extra+journal_one
memory_440 = memory_700-(700-440)*(1 << 20)
result = dict(scope="Offline code-round model, not a serving measurement or qualification",
    measured_chain=receipt, groups=groups, state_fixture_snapshot_ms=snapshot,
    state_fixture_retain_ms=retain,
    target_service_proxy=target, target_n4_n1_ratio=target["4"]/target["1"],
    transport=dict(source_sha256=sha(transport_bytes), ordinary_rtt_half_mean_ms=ordinary,
        initial_rtt_half_mean_ms=initial, eight_hop_n1_model_ms=wire1,
        eight_hop_n1_model_ci95_ms=wire_ci, n4_proportional_model_ms=4*wire1,
        published_mean_of_round_run_p50_eight_hop_ms=st.mean(p50_wire),
        n4_application_frame_measurement=False),
    model=dict(components_ms=components, code_round_ms=modeled,
        head_rpc_and_host_budgets_measured=False, draft_transformer_overlap_credit_ms=0,
        historical_off_tps=off_tps,
        simulated_captured_prefix_code_tps=1000*code["fixed_k3_simulated_tokens_per_verify"]/modeled,
        historical_ring_yield_code_tps=1000*historic["comparisons"]["F3"]["code"]["tokens_per_pass"]/modeled,
        target_service_plus10_percent_ms=modeled+.1*target["4"],
        under_approx100_ms=modeled<100),
    memory_projection=dict(actual_new_full_head_requested_bytes=memory_extra,
        prior_actual_rank7_single_warm_bytes=prior_rank7, new_journal_single_bytes=journal_one,
        projected_rank7_single_at700_mib=memory_700,
        projected_rank7_single_at440_mib=memory_440,
        cap_bytes=cap, projected_440_headroom_bytes=cap-memory_440,
        full_target_admission_measured=False),
    validation=dict(tcp_cases=16, stage_ledgers=stage_count,
        choice_argmax_checks=choice_count, local_chain_rounds=chain_rounds,
        state_fixtures=24, final_source_inputs=len(source_inputs)),
    assumptions=[
        "N4 owner proxy sums mixed failure-prefix/chat owner medians on .51, not matched code or ring.",
        "N4 transport extrapolates primary global-codec series F32 baselines (first30 records), equally weighting five bracketed rounds; not a 160KB measurement.",
        "N1 calibration allowance transfers historical off TPS across unmatched timing cohorts; it is not a measured historical component.",
        "Extra target projections use measured whole-head three-call proxy, not measured four-shard fleet service.",
        "RPC budgets use ordinary full-frame RTT/2 equivalents; tiny RPCs were not measured.",
        "State fixtures have real six-layer shapes but synthetic weights; owners prepare/retain independently in parallel.",
        "Retain requests fan out before coordinator-local retain; local checkpoint is hidden by drafting, native-owner checkpoint follows the chain.",
        "No transformer-compute overlap or speculative precision-hop saving is credited.",
        "Acceptance simulates fixed-k3 frontiers from all256 N1-teacher prefixes per retained case; not actual N4/ring acceptance.",
        "Paired440MiB page-cache candidate arms are projected to fit; eager admission remains mandatory.",
        "N4 original-Q8 same-geometry quality and complete serving divergence capture are pending.",
    ], evidence=dict(archive_sha256=sha((data/"evidence.tar.gz").read_bytes()),
        source_sha256=sha(source), native_hot_source_sha256={
            name: source_inputs[name] for name in ("src/mtp_native.c", "src/mtp_head.c", "src/vk.c",
                                                   "tools/bench_mtp_chain.c")},
        source_inputs=source_inputs),
    production_access=False, promoted=False)
(data/"transport.json").write_bytes(transport_bytes)
(data/"analysis.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({k: result[k] for k in ("model", "memory_projection", "validation")}, indent=2))
