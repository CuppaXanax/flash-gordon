set -eu
sudo -n python3 - <<'PY'
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

root = Path("/home/xander/hc-mtp")
assert root.resolve() == root and root.is_dir()
config = Path("/etc/cyan-skillfish-governor-smu/config.toml")
expected = "a5e83975e4fbea57d6110cbf4aa81fd58367d044c2bc602815ff0ca21ede6757"
assert hashlib.sha256(config.read_bytes()).hexdigest() == expected
subprocess.run(["systemctl", "is-active", "--quiet",
                "cyan-skillfish-governor-smu.service"], check=True)

def owned():
    found = []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            executable = os.readlink(proc / "exe").removesuffix(" (deleted)")
        except OSError:
            continue
        if executable.startswith(str(root) + "/"):
            found.append(int(proc.name))
    return found

stopped = owned()
for pid in stopped:
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
if stopped:
    time.sleep(1)
for pid in owned():
    os.kill(pid, signal.SIGKILL)
time.sleep(.2)
assert not owned()
listeners = subprocess.check_output(["ss", "-H", "-ltnp"], text=True)
for line in listeners.splitlines():
    match = re.search(r":(\d+)$", line.split()[3])
    assert not match or not 17400 <= int(match[1]) < 17716, line

ancestors = {os.getpid()}
pid = os.getppid()
while pid and pid not in ancestors:
    ancestors.add(pid)
    status = Path(f"/proc/{pid}/status").read_text()
    pid = int(re.search(r"^PPid:\s+(\d+)", status, re.M)[1])
open_owned_files = []
for proc in Path("/proc").iterdir():
    if not proc.name.isdecimal() or int(proc.name) in ancestors:
        continue
    try:
        descriptors = list((proc / "fd").iterdir())
    except OSError:
        continue
    for descriptor in descriptors:
        try:
            target = os.readlink(descriptor)
        except OSError:
            continue
        if target.startswith(str(root) + "/"):
            open_owned_files.append({"pid": int(proc.name), "file": target})
assert not open_owned_files, open_owned_files
shutil.rmtree(root)
absence = []
for _ in range(2):
    time.sleep(.5)
    absence.append(not os.path.lexists(root))
assert all(absence) and not owned()
assert hashlib.sha256(config.read_bytes()).hexdigest() == expected
subprocess.run(["systemctl", "is-active", "--quiet",
                "cyan-skillfish-governor-smu.service"], check=True)
print(json.dumps(dict(host="192.168.42.51", owned_root=str(root),
    cleaned_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    root_absent_checks=absence, owned_executables_remaining=0,
    other_open_owned_files=0, stopped_owned_pids=stopped,
    fixture_listeners_remaining=0, governor_config_sha256=expected,
    governor_service="active", production_access=False)))
PY
