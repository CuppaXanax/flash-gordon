set -eu
cd /home/xander/hc-mtp/relocation
mkdir -p src
tar -xzf source.tar.gz -C src
cd src
find src include tests tools -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' \) -exec touch {} +
make -j12 flash-gordon tests/test_session tests/test_api test-mtp tests/test_mtp_ring > ../build.log 2>&1
./tests/test_session > ../session.log 2>&1
./tests/test_api > ../api.log 2>&1
make test-mtp-ring > ../ring.log 2>&1
sh tools/check-flags.sh > ../flags.log 2>&1
sha256sum flash-gordon > ../binary.sha256
echo 'BUILD SESSION API MTP RING FLAGS PASS'
