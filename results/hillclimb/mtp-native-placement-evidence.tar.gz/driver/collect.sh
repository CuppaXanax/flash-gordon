set -eu
cd /home/xander/hc-mtp/relocation
sha256sum -c governor-before.sha256 > governor-check.txt
systemctl is-active cyan-skillfish-governor-smu.service > governor-service.txt
mkdir -p evidence
cp source.tar.gz build.log session.log api.log ring.log flags.log gpu-build.log native6.json native6.log gpu-binaries.sha256 governor-before.sha256 governor-check.txt governor-service.txt evidence/
cd src
sha256sum flash-gordon tools/mtp-residency > ../evidence/binaries.sha256
(cd vulkan; sha256sum *.spv) > ../evidence/shaders.sha256
python3 - <<'PY' > ../evidence/sources.json
import pathlib,json,hashlib
names=[p for d in ('include','src','tests','tools') for p in pathlib.Path(d).rglob('*')
       if p.is_file() and p.suffix in ('.h','.c','.inc','.py','.ps1','.sh')]
print(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in sorted(names)},sort_keys=True,indent=2))
PY
cd ..
test "$(grep -c 'MTP synthetic 8-rank runtime:' ring.log)" = 8
test "$(grep -c 'MTP large-frame two-session target credit: PASS' ring.log)" = 8
python3 - <<'PY'
import json,pathlib
d=json.loads(pathlib.Path('native6.json').read_text())
assert d['native_owner']==6 and d['exact_default_equivalence_steps']==8
assert d['weights']==2772584448 and d['private_second']==38705712
print(json.dumps(d))
PY
tar -czf evidence.tar.gz evidence
sha256sum evidence.tar.gz source.tar.gz
