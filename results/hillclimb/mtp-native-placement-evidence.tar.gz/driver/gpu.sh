set -eu
cd /home/xander/hc-mtp/relocation
sha256sum /etc/cyan-skillfish-governor-smu/config.toml > governor-before.sha256
test "$(systemctl is-active cyan-skillfish-governor-smu.service)" = active
echo '536bab54b0a1bdea23b65871c4cdc38deee5803771501a0c770a0510bcd3283b  native-q8.gguf' | sha256sum -c -
cd src
tar -xzf ../source.tar.gz
find src include tools -type f \( -name '*.c' -o -name '*.h' -o -name '*.inc' \) -exec touch {} +
make -j12 tools/mtp-residency flash-gordon > ../gpu-build.log 2>&1
export FG_EXPERT_Q8_WIDE=1 FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3
export FG_ROOF_EXPERT=33024 FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1
export FG_NGRAM_LOCAL_CACHE=1 FG_DECODE_SUBMIT_GROUP=2 FG_SMALL_KERNELS=330
./tools/mtp-residency --native-only manifest.fgm ../native-q8.gguf --native-rank 6 > ../native6.json 2> ../native6.log
sha256sum flash-gordon tools/mtp-residency > ../gpu-binaries.sha256
cd ..
sha256sum -c governor-before.sha256
echo 'REAL NATIVE6 TWO CONTEXTS AND EIGHT EXACT DEFAULT-OWNER STEPS PASS'
