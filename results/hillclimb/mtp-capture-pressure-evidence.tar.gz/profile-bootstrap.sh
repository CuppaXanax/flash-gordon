set -eu
test ! -e /home/xander/hc-mtp/pressure
mkdir -p /home/xander/hc-mtp
echo OFFLINE_PRESSURE_51_RESERVED
