import hashlib
import json
import statistics
import sys
import tarfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]/"tools"))
from analyze_mtp_union import summarize
from mtp_format_audit import load_manifest

root = Path(__file__).resolve().parent
run = root/"runs/union-20261017-0102"
rows = []
for archive in sorted(run.glob("evidence-*.tar.gz")):
    with tarfile.open(archive) as tar:
        for member in tar:
            if member.name.startswith("capture/verify-routes-") and member.name.endswith(".jsonl"):
                rows.extend(json.loads(line) for line in tar.extractfile(member).read().decode().splitlines())
            if member.name == "pack/manifest.fgm":
                (root/"manifest.fgm").write_bytes(tar.extractfile(member).read())
sessions, previous = {}, set()
for case in ("chat-0", "chat-1", "code-0", "code-1"):
    binding = next(run.glob("*-bind-"+case+".json"))
    result = json.loads(binding.read_text(encoding="utf-8-sig"))
    if isinstance(result, list):
        assert len(result) == 1
        result = result[0]
    assert result["ExitCode"] == 0
    files = json.loads(result["Stdout"])
    current = {Path(path).name.split("-")[2] for path in files}
    added = current-previous
    assert len(added) == 1, (case, added)
    session = added.pop()
    response = json.loads((run/(case+".json")).read_text())
    sessions[session] = dict(case=case, category=response["category"],
                             http_id=response["id"], binding=binding.name,
                             tokens=response["tokens"])
    previous = current
manifest = load_manifest(root/"manifest.fgm")
provenance = dict(origin="native-target-MTP-verification",
                  manifest_sha256=manifest["sha256"],
                  source_commit="9eea42f10b02044798d10327927094a9c80ff8d3",
                  small_kernel_mask=330, fixed_draft=3, draft_head="full authenticated Q8",
                  sessions=sessions, lease="union-20261017-0102",
                  quality_scope="unqualified capture-only; Forced80 failure acknowledged",
                  release_sha256=hashlib.sha256((root/"release.tar.gz").read_bytes()).hexdigest())
(root/"provenance.json").write_text(json.dumps(provenance, indent=2)+"\n")
result = summarize(rows, manifest, provenance)
result["provenance"] = provenance
result["conditional_floor"] = {}
for category in ("all", "chat", "code"):
    group = result["groups"][category]
    gu, down = group["gu_byte_ratio"], group["down_byte_ratio"]
    ideal = 437.84*gu+296.16*down+1.1*(854.20+434.44)+671.24
    current = ideal+1055.72-671.24
    result["conditional_floor"][category] = dict(
        gu_byte_ratio=gu, down_byte_ratio=down,
        proxy_ideal_n4_over_n1=ideal/2693.88,
        proxy_current_other_n4_over_n1=current/2693.88,
        proxy_ideal_us=ideal, proxy_current_other_us=current,
        caveat="Measured logical union bytes, synthetic N1 op prices, assumed1.1 dense/HC; not DRAM counters or a measured physical/service floor.")
    cardinalities = [r["unique_experts"] for r in result["observations"]
                     if category == "all" or r["category"] == category]
    result["conditional_floor"][category]["unique_experts_median"] = statistics.median(cardinalities)
(root/"union-analysis.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(dict(windows=result["windows"], groups=result["conditional_floor"]), indent=2))
