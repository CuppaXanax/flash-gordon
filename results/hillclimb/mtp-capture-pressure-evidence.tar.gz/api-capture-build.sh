set -eu
cd /home/xander/hc-mtp/pressure
mkdir api-source
tar -xzf ../api-source.tar.gz -C api-source
cd api-source
export TMPDIR="$PWD/../cache" XDG_CACHE_HOME="$PWD/../cache"
make -j12 flash-gordon > ../api-build.log 2>&1
mkdir -p .build/cli-capture
set +e
./flash-gordon api --mtp-capture-dir .build/cli-capture > ../api-cli.log 2>&1
rc=$?
set -e
test "$rc" -ne 0
grep -q 'api requires --manifest' ../api-cli.log
sha256sum flash-gordon src/main.c > ../api-build.sha256
cp flash-gordon ../api-flash-gordon
cd ..
tar -czf api-build-evidence.tar.gz api-build.log api-cli.log api-build.sha256
echo API_CAPTURE_CLI_ACCEPTED_OFFLINE
