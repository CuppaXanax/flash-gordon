set -eu
cd /home/xander/hc-mtp/pressure/api-source
export TMPDIR="$PWD/../cache" XDG_CACHE_HOME="$PWD/../cache"
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
run(){
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ../tools/bench-decode-fusion "$@"' bash "$@"
}
for round in 1 2 3 4 5 6; do
    for variant in A0 B A1; do
        if test "$variant" = B; then
            cp ../epilogue-iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
            cp ../epilogue-q8.spv vulkan/fg_small_hc_up_mix_q8.spv
        else
            cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
            cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
        fi
        for n in 1 4; do
            run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" \
                --iterations "$((216/n))" --windows 1 --allow-reassociation --no-clocks \
                > "../epilogue-confirm-$round-$variant-$n.jsonl" 2> "../epilogue-confirm-$round-$variant-$n.log"
        done
    done
done
for variant in A B; do
    if test "$variant" = B; then
        cp ../epilogue-iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
        cp ../epilogue-q8.spv vulkan/fg_small_hc_up_mix_q8.spv
    else
        cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
        cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
    fi
    FG_BENCH_HC_INJECT=1 DS4_REMOTE_TEST_FILTER=small_hc_up_mix ../tests/test_fg_vk \
        > "../epilogue-micro-$variant.jsonl" 2> "../epilogue-micro-$variant.log"
done
cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
cd ..
tar -czf epilogue-confirm-evidence.tar.gz epilogue-confirm-* epilogue-micro-*
echo SIX_OFFLINE_EPILOGUE_BRACKETS_COMPLETE
