set -eu
cd /home/xander/hc-mtp
python3 - <<'PY'
import os,pathlib,time,json
p=pathlib.Path("epilogue.sh")
p.write_bytes(p.read_bytes().replace(b"\r\n",b"\n"))
removed=[]
for name in ("epilogue-build.log","epilogue-oracle.jsonl","epilogue-oracle.log\r",
             "epilogue-isa.jsonl","epilogue-isa.log\r"):
    p=pathlib.Path("/home/xander")/name
    if not p.exists():continue
    s=p.stat()
    assert s.st_uid==os.getuid() and s.st_size<4096 and time.time()-s.st_mtime<3600,(p,s)
    data=p.read_bytes()
    assert not data or b"../tests/test_fg_vk" in data or b"No such file" in data,(p,data)
    p.unlink();removed.append(name)
pathlib.Path("pressure/newline-cleanup.json").write_text(json.dumps({"owned_accidental_redirections_removed":removed})+"\n")
PY
bash epilogue.sh
cd pressure
tar -czf pressure-close-evidence.tar.gz pressure-final-evidence.tar.gz epilogue-evidence.tar.gz newline-cleanup.json
echo GUIDED_EXPERIMENTS_SEALED
