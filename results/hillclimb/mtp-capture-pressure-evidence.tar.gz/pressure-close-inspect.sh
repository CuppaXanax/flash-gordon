set -eu
cd /home/xander/hc-mtp/pressure
sha256sum final-flash-gordon
find /home/xander/hc-mtp -mindepth 1 -maxdepth 1 -printf '%f\n'
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > governor-now.sha256
cmp governor.sha256 governor-now.sha256
cd api-source
python3 -m unittest discover -s tests -p test_mtp_lease_identity.py
bash -n tools/mtp-lease-guard.sh
echo CLI_CANDIDATE_RETAINED_AND_RESTORATION_GUARD_VALIDATED
