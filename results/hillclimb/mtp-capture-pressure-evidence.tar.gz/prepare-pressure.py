import io
import tarfile
from pathlib import Path

root = Path.cwd()
out = root/".build/mtp-union-lease"
shader = (root/"shaders/fg_small_hc_up_mix.glsl").read_text()
replacements = {
    "#extension GL_KHR_shader_subgroup_arithmetic : require":
        "#extension GL_KHR_shader_subgroup_arithmetic : require\n#extension GL_KHR_shader_subgroup_shuffle : require",
    "uint lane=gl_SubgroupInvocationID&3u,cohort=gl_SubgroupInvocationID/4u;":
        "uint half_tile=gl_SubgroupInvocationID/32u;\n    uint lane=gl_SubgroupInvocationID&3u,cohort=(gl_SubgroupInvocationID&31u)/4u;",
    "first=gl_WorkGroupID.x*8u+hc*pc.hidden":
        "first=gl_WorkGroupID.x*8u+hc*pc.hidden+half_tile*4u",
    "float acc[TOKENS][8];": "float acc[TOKENS][4];",
    "r<8u": "r<4u",
    "g+=16u": "g+=8u",
    "float v=subgroupAdd(acc[t][r]);":
        "float v=acc[t][r];\n        for(uint shift=1u;shift<32u;shift*=2u)v+=subgroupShuffleXor(v,shift);",
    "if(subgroupElect())values[(t*4u+hc)*8u+r]=v;":
        "if((gl_SubgroupInvocationID&31u)==0u)values[(t*4u+hc)*8u+half_tile*4u+r]=v;",
}
for old, new in replacements.items():
    assert old in shader, old
    shader = shader.replace(old, new)
(out/"hc-halfwave.glsl").write_text(shader)
with tarfile.open(out/"pressure-update.tar", "w") as t:
    for path in ("Makefile", "tests/test_mtp_capture.py"):
        t.add(root/path, arcname=path)
    data = shader.encode()
    member = tarfile.TarInfo("hc-halfwave.glsl")
    member.size = len(data)
    t.addfile(member, io.BytesIO(data))
