set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'union-20261017-0102'; bash '/home/xander/hc-mtp/lease.sh' restore
