set -euo pipefail
echo '536bab54b0a1bdea23b65871c4cdc38deee5803771501a0c770a0510bcd3283b  /home/xander/hc-mtp/native-q8.gguf' | sha256sum -c -
