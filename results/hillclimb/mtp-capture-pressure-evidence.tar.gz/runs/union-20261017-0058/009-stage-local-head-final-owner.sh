set -euo pipefail
echo '2801d79db74bcae38b47fd5051f03136d8ca7715abeba7d92b49ba46c696bc33  /home/xander/hc-mtp/local-head.q8' | sha256sum -c -
