set -euo pipefail
test ! -e '/home/xander/hc-mtp'; mkdir -p '/home/xander/hc-mtp'; printf '%s\n' 'union-20261017-0058' > '/home/xander/hc-mtp/lease.id'
