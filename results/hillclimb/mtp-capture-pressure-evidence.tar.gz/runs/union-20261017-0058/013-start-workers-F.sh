set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'union-20261017-0058'; bash '/home/xander/hc-mtp/lease.sh' start-serving F 51 0 1 0 1 440
