set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'union-20261017-0058'; bash '/home/xander/hc-mtp/lease.sh' arm 1792199183
