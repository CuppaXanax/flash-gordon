set -eu
root=/home/xander/hc-mtp/pressure
test ! -d "$root"
mkdir -p "$root/cache" "$root/.build"
cd "$root"
find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > governor.sha256
tar -xzf ../profile-release.tar.gz
export TMPDIR="$PWD/cache" XDG_CACHE_HOME="$PWD/cache" FG_SHADER_DIR="$PWD/vulkan"
export FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
for n in 1 2 4; do
    RADV_DEBUG=shaders,shaderstats MESA_SHADER_CACHE_DISABLE=true \
        ./tools/bench-decode-fusion --q4 --mixed-experts --small-n --batch "$n" \
        --warmup 2 --iterations 1 --windows 1 --allow-reassociation --no-clocks \
        > "isa-$n.jsonl" 2> "isa-$n.log"
done
sha256sum tools/bench-decode-fusion tests/test_fg_vk > binaries.sha256
tar -czf evidence.tar.gz isa-* binaries.sha256 governor.sha256
echo COMPILED_N1_N2_N4_PRESSURE_CAPTURED_NO_NEW_VARIANTS
