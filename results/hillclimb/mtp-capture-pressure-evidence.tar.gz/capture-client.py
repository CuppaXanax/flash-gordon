import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]/"tools"))
from mtp_serving_qualify import CASES, request

p = argparse.ArgumentParser()
p.add_argument("--base", required=True)
p.add_argument("--case", required=True)
p.add_argument("--output", required=True)
a = p.parse_args()
name, category, prompt = next(c for c in CASES if c[0] == a.case)
start = time.time()
row = dict(case=name, category=category, start_unix=start,
           **request(a.base, prompt, "union-capture-"+name, 80))
row["end_unix"] = time.time()
row["timing_valid"] = False
row["scope"] = "capture only; traced run, not TPS evidence"
Path(a.output).write_text(json.dumps(row, indent=2)+"\n")
print(name, row["id"], row["tokens"])
