set -eu
cd /home/xander/hc-mtp/pressure/api-source
tar -xf ../../finish-update.tar
touch src/main.c
export TMPDIR="$PWD/../cache" XDG_CACHE_HOME="$PWD/../cache"
make -j12 flash-gordon test-mtp-capture test-mtp > ../final-build-tests.log 2>&1
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
for variant in A B; do
    if test "$variant" = B; then
        cp ../halfwave-iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
        cp ../halfwave-q8.spv vulkan/fg_small_hc_up_mix_q8.spv
    else
        cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
        cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
    fi
    FG_BENCH_HC_INJECT=2000 DS4_REMOTE_TEST_FILTER=small_hc_up_mix ../tests/test_fg_vk \
        > "../hc-micro-$variant.jsonl" 2> "../hc-micro-$variant.log"
done
cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
run(){
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ../tools/bench-decode-fusion "$@"' bash "$@"
}
export FG_SMALL_KERNELS=393418
RADV_DEBUG=shaders,shaderstats MESA_SHADER_CACHE_DISABLE=true \
    ../tools/bench-decode-fusion --q4 --mixed-experts --small-n --batch 4 \
    --warmup 2 --iterations 1 --windows 1 --allow-reassociation --no-clocks \
    > ../rows4-isa.jsonl 2> ../rows4-isa.log
run --q4 --mixed-experts --small-n --batch 4 --small-test --allow-reassociation \
    --routing-trace ../rows4-routes.jsonl --warmup 8 --iterations 8 --windows 1 \
    --no-clocks > ../rows4-block.jsonl 2> ../rows4-block.log
for round in 1 2 3; do
    for tag in A0 B A1; do
        if test "$tag" = B; then export FG_SMALL_KERNELS=393418
        else export FG_SMALL_KERNELS=393546; fi
        for n in 1 4; do
            run --q4 --mixed-experts --small-n --batch "$n" --warmup "$((264/n))" \
                --iterations "$((216/n))" --windows 1 --allow-reassociation --no-clocks \
                > "../rows-replay-$round-$tag-$n.jsonl" 2> "../rows-replay-$round-$tag-$n.log"
        done
    done
done
for mask in 393546 393418; do
    export FG_SMALL_KERNELS="$mask"
    run --q4 --small-n --dense-only --dense-type 12 --allow-reassociation --no-clocks \
        > "../dense-rows-$mask.jsonl" 2> "../dense-rows-$mask.log"
done
bash tools/check-flags.sh > ../final-flags.log
sha256sum flash-gordon src/main.c Makefile tests/test_mtp_capture.py > ../final-inputs.sha256
cp flash-gordon ../final-flash-gordon
cd ..
tar -czf pressure-final-evidence.tar.gz final-build-tests.log final-flags.log final-inputs.sha256 hc-micro-* rows4-* rows-replay-* dense-rows-*
echo FINAL_CLI_CPU_GATES_AND_ROW_TILE_EXPERIMENTS_PASS
