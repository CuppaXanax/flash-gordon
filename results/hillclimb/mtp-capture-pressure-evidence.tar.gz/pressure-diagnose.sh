set -eu
cd /home/xander/hc-mtp/pressure
for file in final-build-tests.log hc-micro-A.log hc-micro-B.log rows4-block.log dense-rows-393546.log dense-rows-393418.log final-flags.log; do
    if test -f "$file"; then echo "FILE $file"; tail -8 "$file"; fi
done
find . -maxdepth 1 -type f -name 'rows-replay*' -printf '%f\n'
tar -czf pressure-final-partial.tar.gz final-build-tests.log hc-micro-* rows4-* rows-replay-* dense-rows-* 2>/dev/null || true
