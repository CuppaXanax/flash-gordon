from pathlib import Path

root = Path.cwd()
dest = root/".build/mtp-union-lease"
source = (root/"tools/Invoke-MTPServingQualification.ps1").read_text()
start = source.index("if($Action -eq 'Run'){\n    if(-not $DiagnosticGreedy")
end = source.index("$all=@(", start)
source = source[:start] + """
if(-not $DiagnosticGreedy){throw 'Capture-only diagnostic acknowledgement required.'}
if((Get-FileHash $NativeOverlay -Algorithm SHA256).Hash.ToLowerInvariant() -ne
 '536bab54b0a1bdea23b65871c4cdc38deee5803771501a0c770a0510bcd3283b'){throw 'Native overlay mismatch'}
$localHeadSha256=(Get-FileHash $LocalHead -Algorithm SHA256).Hash.ToLowerInvariant()
if($localHeadSha256 -ne '2801d79db74bcae38b47fd5051f03136d8ca7715abeba7d92b49ba46c696bc33'){throw 'Full draft head mismatch'}
""" + source[end:]
source = source.replace("if($Action -eq 'Plan'){",
    "$phases=,@('F3',3,330,3);$candidateSessions=1;$candidateQsaCacheMiB=440\nif($Action -eq 'Plan'){")
source = source.replace("$started.AddMinutes(38)", "$started.AddMinutes(13)")
source = source.replace("$started.AddMinutes(39)", "$started.AddMinutes(14)")
source = source.replace("(Join-Path $PSScriptRoot 'mtp-lease-guard.sh')",
                        "(Join-Path $Artifacts 'capture-guard.sh')")
source = source.replace("(Join-Path $PSScriptRoot 'mtp_serving_qualify.py')",
                        "(Join-Path $Artifacts 'capture-client.py')")
start = source.index("        $greedyFile=Join-Path")
end = source.index("    $complete=$true", start)
source = source[:start] + r"""
        foreach($case in @('chat-0','chat-1','code-0','code-1')){
            Client @('--base',$ApiBaseUrl,'--case',$case,'--output',(Join-Path $run "$case.json"))
            $null=Remote "bind-$case" "python3 -c `"import glob,json;print(json.dumps(sorted(glob.glob('$root/capture/verify-routes-*.jsonl'))))`"" @('192.168.42.42')
        }
    }
""" + source[end:]
source = source.replace("$PSScriptRoot", "'"+str(root/"tools")+"'")
(dest/"capture.ps1").write_text(source)
guard = (root/"tools/mtp-lease-guard.sh").read_text()
guard = guard.replace("    bash \"$operator/launch-current.sh\" status\n    date +%s",
    "    bash \"$operator/launch-current.sh\" status\n"
    "    find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > \"$root/governor.sha256\"\n"
    "    date +%s")
guard = guard.replace("    (\n        cd \"$root/release\"",
                      "    command+=(--mtp-capture-dir \"$root/capture\")\n    (\n        cd \"$root/release\"")
guard = guard.replace("    cd /home/xander\n    rm -rf \"$root\"",
    """    find /sys/devices/system/cpu/cpufreq -name scaling_governor -exec sha256sum {} + > "$root/governor-now.sha256"
    cmp "$root/governor.sha256" "$root/governor-now.sha256"
    cd /home/xander
    python3 - <<'PY'
import os,pathlib
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit() or int(p.name) in (os.getpid(),os.getppid()):continue
    try:exe=os.readlink(p/'exe');cwd=os.readlink(p/'cwd')
    except (PermissionError,FileNotFoundError,ProcessLookupError):continue
    assert not exe.startswith('/home/xander/hc-mtp/'),(p,exe)
    assert not cwd.startswith('/home/xander/hc-mtp/'),(p,cwd)
print('owned processes absent; governor inventory unchanged')
PY
    rm -rf "$root\"""")
guard = guard.replace('    echo "hc-mtp removed"',
    '    sleep 2\n    [[ ! -e "$root" ]]\n    echo "hc-mtp absent twice RELEASED $(date -u +%FT%TZ)"')
(dest/"capture-guard.sh").write_text(guard)
print("Capture-only harness prepared; unqualified diagnostic, no promotion.")
