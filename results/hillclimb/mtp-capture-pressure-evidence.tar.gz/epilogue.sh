set -eu
cd /home/xander/hc-mtp/pressure/api-source
export TMPDIR="$PWD/../cache" XDG_CACHE_HOME="$PWD/../cache"
cp ../../hc-parallel-epilogue.glsl shaders/fg_small_hc_up_mix.glsl
make -j2 vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_q8.spv > ../epilogue-build.log 2>&1
cp vulkan/fg_small_hc_up_mix_iq4.spv ../epilogue-iq4.spv
cp vulkan/fg_small_hc_up_mix_q8.spv ../epilogue-q8.spv
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
DS4_REMOTE_TEST_FILTER=small_hc_up_mix ../tests/test_fg_vk > ../epilogue-oracle.jsonl 2> ../epilogue-oracle.log
RADV_DEBUG=shaders,shaderstats MESA_SHADER_CACHE_DISABLE=true \
    ../tools/bench-decode-fusion --q4 --mixed-experts --small-n --batch 4 \
    --warmup 2 --iterations 1 --windows 1 --allow-reassociation --no-clocks \
    > ../epilogue-isa.jsonl 2> ../epilogue-isa.log
run(){
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ../tools/bench-decode-fusion "$@"' bash "$@"
}
run --q4 --mixed-experts --small-n --batch 4 --small-test --allow-reassociation \
    --routing-trace ../epilogue-routes.jsonl --warmup 8 --iterations 8 --windows 1 \
    --no-clocks > ../epilogue-block.jsonl 2> ../epilogue-block.log
for round in 1 2 3; do
    for variant in A0 B A1; do
        if test "$variant" = B; then
            cp ../epilogue-iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
            cp ../epilogue-q8.spv vulkan/fg_small_hc_up_mix_q8.spv
        else
            cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
            cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
        fi
        run --q4 --mixed-experts --small-n --batch 4 --warmup 66 --iterations 54 \
            --windows 1 --allow-reassociation --no-clocks \
            > "../epilogue-replay-$round-$variant.jsonl" 2> "../epilogue-replay-$round-$variant.log"
    done
done
cp ../hc-original.glsl shaders/fg_small_hc_up_mix.glsl
cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
cd ..
tar -czf epilogue-evidence.tar.gz epilogue-*
echo PARALLEL_EPILOGUE_EXPERIMENT_COMPLETE
