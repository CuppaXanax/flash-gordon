set -eu
cd /home/xander/hc-mtp/pressure
export TMPDIR="$PWD/cache" XDG_CACHE_HOME="$PWD/cache"
cd api-source
tar -xf ../../pressure-update.tar
make -j12 test-mtp-capture > ../capture-regressions.log 2>&1
mkdir -p vulkan .build
cp ../vulkan/*.spv vulkan/
cp shaders/fg_small_hc_up_mix.glsl ../hc-original.glsl
cp hc-halfwave.glsl shaders/fg_small_hc_up_mix.glsl
make -j2 vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_q8.spv > ../halfwave-build.log 2>&1
cp vulkan/fg_small_hc_up_mix_iq4.spv ../halfwave-iq4.spv
cp vulkan/fg_small_hc_up_mix_q8.spv ../halfwave-q8.spv
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
DS4_REMOTE_TEST_FILTER=small_hc_up_mix ../tests/test_fg_vk > ../halfwave-oracle.jsonl 2> ../halfwave-oracle.log
RADV_DEBUG=shaders,shaderstats MESA_SHADER_CACHE_DISABLE=true \
    ../tools/bench-decode-fusion --q4 --mixed-experts --small-n --batch 4 \
    --warmup 2 --iterations 1 --windows 1 --allow-reassociation --no-clocks \
    > ../halfwave-isa.jsonl 2> ../halfwave-isa.log
run(){
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ../tools/bench-decode-fusion "$@"' bash "$@"
}
run --q4 --mixed-experts --small-n --batch 4 --small-test --allow-reassociation \
    --routing-trace ../halfwave-routes.jsonl --warmup 8 --iterations 8 --windows 1 \
    --no-clocks > ../halfwave-block.jsonl 2> ../halfwave-block.log
for round in 1 2 3; do
    for variant in A0 B A1; do
        if test "$variant" = B; then
            cp ../halfwave-iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
            cp ../halfwave-q8.spv vulkan/fg_small_hc_up_mix_q8.spv
        else
            cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
            cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
        fi
        run --q4 --mixed-experts --small-n --batch 4 --warmup 66 --iterations 54 \
            --windows 1 --allow-reassociation --no-clocks \
            > "../half-replay-$round-$variant.jsonl" 2> "../half-replay-$round-$variant.log"
    done
done
cp ../hc-original.glsl shaders/fg_small_hc_up_mix.glsl
cp ../vulkan/fg_small_hc_up_mix_iq4.spv vulkan/fg_small_hc_up_mix_iq4.spv
cp ../vulkan/fg_small_hc_up_mix_q8.spv vulkan/fg_small_hc_up_mix_q8.spv
cd ..
tar -czf pressure-iteration-evidence.tar.gz capture-regressions.log halfwave-* half-replay-* api-build.* api-cli.log hc-original.glsl api-source/hc-halfwave.glsl
echo CAPTURE_CLI_REGRESSION_AND_PROFILE_GUIDED_HALF_WAVE_EXPERIMENT_COMPLETE
