set -eu
cd /home/xander/hc-mtp
tar -xf pressure-next.tar
cd pressure/api-source
export TMPDIR="$PWD/../cache" XDG_CACHE_HOME="$PWD/../cache"
export FG_SHADER_DIR="$PWD/vulkan" FG_EXPERT_Q8_WIDE=1 FG_SMALL_KERNELS=393546
export FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3 FG_ROOF_EXPERT=33024
export FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1 FG_DECODE_SUBMIT_GROUP=2
for mask in 393546 393418; do
    export FG_SMALL_KERNELS="$mask"
    sudo -n --preserve-env=TMPDIR,XDG_CACHE_HOME,FG_SHADER_DIR,FG_EXPERT_Q8_WIDE,FG_SMALL_KERNELS,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_DECODE_SUBMIT_GROUP bash -c \
        'ulimit -l unlimited; exec ../tools/bench-decode-fusion --q4 --small-n --dense-only --dense-type 12 --allow-reassociation --no-clocks' \
        > "../dense-rows-$mask.jsonl" 2> "../dense-rows-$mask.log"
done
bash tools/check-flags.sh > ../final-flags.log
sha256sum flash-gordon src/main.c Makefile tests/test_mtp_capture.py > ../final-inputs.sha256
cp flash-gordon ../final-flash-gordon
cd ..
tar -czf pressure-final-evidence.tar.gz final-build-tests.log final-flags.log final-inputs.sha256 hc-micro-* rows4-* rows-replay-* dense-rows-*
cd /home/xander/hc-mtp
bash epilogue.sh
cd pressure
tar -czf pressure-close-evidence.tar.gz pressure-final-evidence.tar.gz epilogue-evidence.tar.gz
echo DENSE_ROW_AND_EPILOGUE_MEASUREMENTS_COMPLETE
