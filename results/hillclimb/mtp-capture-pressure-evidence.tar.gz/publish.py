import hashlib
import io
import json
from pathlib import Path
import re
import statistics
import subprocess
import tarfile

ROOT = Path.cwd()
BASE = ROOT / ".build/mtp-union-lease"
OUT = ROOT / "results/hillclimb"
OUT.mkdir(parents=True, exist_ok=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines()
            if line.startswith("{")]


def replay(folder, pattern, rounds, ns):
    result = []
    for i in range(1, rounds + 1):
        row = {"bracket": i}
        for n in ns:
            paths = {tag: folder / pattern.format(i=i, tag=tag, n=n)
                     for tag in ("A0", "B", "A1")}
            data = {tag: records(path) for tag, path in paths.items()}
            samples = {tag: [r["wall_us"] for r in rs if r["kind"] == "sample"]
                       for tag, rs in data.items()}
            medians = {tag: statistics.median(s) for tag, s in samples.items()}
            means = {tag: statistics.mean(s) for tag, s in samples.items()}
            parity = {tag: next(r for r in rs if r["kind"] == "parity")
                      for tag, rs in data.items()}
            row[str(n)] = {
                "process_median_us": medians,
                "process_mean_us": means,
                "B_over_bracket_medians": medians["B"] / statistics.mean(
                    [medians["A0"], medians["A1"]]),
                "B_over_bracket_means": means["B"] / statistics.mean(
                    [means["A0"], means["A1"]]),
                "parity": parity,
                "same_terminal_hashes": parity["A0"] == parity["B"] == parity["A1"],
            }
        result.append(row)
    return result


def pipeline(path, name):
    return next(b for b in re.split(r"(?=^VK_PIPELINE file=)", path.read_text(), flags=re.M)
                if b.startswith("VK_PIPELINE file=" + name + " "))


def resource(block):
    s = re.search(r"^\*\*\* SHADER STATS \*\*\*\n(.*?)^\*{5,}",
                  block, re.M | re.S).group(1)
    return {key: int(re.search(r"^" + re.escape(key) + r": (.*)$", s, re.M).group(1))
            for key in ("VGPRs", "Spilled VGPRs", "Spilled SGPRs", "Scratch size",
                        "Subgroups per SIMD", "Instructions", "VALU", "VMEM")}


def loads(block, hc):
    machine = [l for l in block.splitlines() if re.search(r";\s*[0-9a-fA-F]{8}", l)]
    if hc:
        barriers = [i for i, line in enumerate(machine) if "s_barrier" in line]
        machine = machine[barriers[0] + 1:barriers[1]]
    return {kind: sum("buffer_load" in line and descriptor in line for line in machine)
            for kind, descriptor in (("weight_load_sites", "s[8:11]"),
                                     ("activation_load_sites", "s[12:15]"))}


isa = {}
for n in (1, 2, 4):
    path = BASE / f"pressure/isa-{n}.log"
    names = {
        "hc": "fg_roof_hc_up_mix_iq4.spv" if n == 1 else "fg_small_hc_up_mix_iq4.spv",
        "dense": "fg_roof_dense_l2.spv" if n == 1 else f"fg_small_reuse8_q4_n{n}.spv",
    }
    isa[str(n)] = {}
    for kind, name in names.items():
        block = pipeline(path, name)
        item = {"pipeline": name, "compiler": resource(block)}
        if kind == "hc" or n != 1:
            item.update(loads(block, kind == "hc"))
        isa[str(n)][kind] = item
assert [isa[str(n)]["hc"]["weight_load_sites"] for n in (1, 2, 4)] == [16, 16, 16]
assert [isa[str(n)]["dense"]["weight_load_sites"] for n in (2, 4)] == [18, 18]
assert [isa[str(n)]["hc"]["activation_load_sites"] for n in (1, 2, 4)] == [2, 4, 8]

final = BASE / "close/pressure-final-evidence"
half = replay(BASE / "iteration", "half-replay-{i}-{tag}.jsonl", 3, (4,))
rows = replay(final, "rows-replay-{i}-{tag}-{n}.jsonl", 3, (1, 4))
epi = replay(BASE / "close/epilogue-evidence",
             "epilogue-replay-{i}-{tag}.jsonl", 3, (4,))
confirm = replay(BASE / "confirm", "epilogue-confirm-{i}-{tag}-{n}.jsonl", 6, (1, 4))
assert all(r["4"]["same_terminal_hashes"] for r in rows + epi + confirm)

source = {}
for line in (final / "final-inputs.sha256").read_text().splitlines():
    expected, path = line.split(maxsplit=1)
    local = BASE / "final-flash-gordon" if path == "flash-gordon" else ROOT / path
    raw = local.read_bytes()
    matched = sha(raw) == expected or sha(raw.replace(b"\r\n", b"\n")) == expected
    assert matched, path
    source[path] = {"compiled_sha256": expected, "local_input_matches": matched}

with tarfile.open(BASE / "release.tar.gz") as t:
    members = {m.name: (m.mode, t.extractfile(m).read()) for m in t.getmembers() if m.isfile()}
members["flash-gordon"] = (0o755, (BASE / "final-flash-gordon").read_bytes())
members.pop("release.sha256", None)
manifest = "".join(f"{sha(data)}  {name}\n" for name, (_, data) in sorted(members.items()))
members["release.sha256"] = (0o644, manifest.encode())
with tarfile.open(BASE / "repaired-release.tar.gz", "w:gz") as t:
    for name, (mode, data) in members.items():
        info = tarfile.TarInfo(name)
        info.mode, info.size = mode, len(data)
        t.addfile(info, io.BytesIO(data))

patch = subprocess.check_output(
    ["git", "diff", "--binary", "--", "src/main.c", "Makefile", "tests/test_mtp_capture.py"])
(BASE / "capture-cli-source.diff").write_bytes(patch)

publication = {
    "base_commit": "9eea42f10b02044798d10327927094a9c80ff8d3",
    "default_off": True, "promotion": False,
    "capture": {
        "grant_utc": "2026-10-17T00:54:23Z", "lease_minutes": 15,
        "production_released_utc": "2026-10-17T01:06:07Z",
        "outcomes": [json.loads(p.read_text()) for p in sorted(BASE.glob("runs/*/outcome.json"))],
        "verified_rounds": 0, "measured_real_union_ratios": None,
        "measured_union_weighted_floor": None,
        "first_failure": "single nested PowerShell phase flattened; worker guard rejected",
        "second_failure": "flash-gordon: unknown api option: --mtp-capture-dir",
        "repair": "API parser accepts diagnostic capture directory; eight Linux capture tests pass",
        "restored_source": "31508eea70025a14fde14340c1b66cb4867536d9",
        "restored_binary_sha256": "02930a164e38c9c5ee50ae11bf0a746601cc587fdff4e31205da6861e850a6e0",
    },
    "offline": {
        "target": "192.168.42.51", "device": "AMD BC-250 (RADV GFX1013)",
        "released_utc": "2026-10-17T01:28:40Z",
        "release": json.loads((BASE / "pressure-release.json").read_text(encoding="utf-8-sig")),
        "isa": isa,
        "isa_limitations": [
            "Static load instruction sites, not DRAM bytes or execution counters",
            "Compiler Subgroups per SIMD is not measured achieved hardware occupancy",
            "RADV debug/cache disable used only for ISA, not wall timing",
        ],
        "half_wave_hc": {"selected": False, "reason": "slower and terminal hashes changed", "brackets": half},
        "dense_row4": {"selected": False, "reason": "4.95% whole-block regression",
                       "brackets": rows,
                       "isolated_shapes": {
                           str(m): [r for r in records(final / f"dense-rows-{m}.jsonl")
                                    if r["kind"] == "dense_cost"]
                           for m in (393546, 393418)}},
        "parallel_token_hc_epilogue": {
            "selected": False,
            "reason": "only 0.50% confirmatory median/0.22% mean signal; prioritize larger measured gaps",
            "initial_brackets": epi, "confirmatory_brackets": confirm,
        },
        "shipping_whole_block_N4_over_N1": 2.166612,
        "shipping_ratio_provenance": "prior 9eea42f synthetic replay, unchanged shaders",
    },
    "op_weighted_floor": {
        "real_union_input": None,
        "status": "conditional planning proxy, NOT a measured/physical floor",
        "N1_proxy_us": 2693.88,
        "N4_proxy_formula": "437.84*R_GU+296.16*R_down+1.1*(854.20+434.44)+671.24",
        "hypothetical_R_GU_and_R_down": 3,
        "hypothetical_ideal_other_ratio": (437.84*3+296.16*3+1.1*(854.20+434.44)+671.24)/2693.88,
        "hypothetical_current_other_ratio": (437.84*3+296.16*3+1.1*(854.20+434.44)+1055.72)/2693.88,
    },
    "validation": {
        "C17_Werror_build": "pass", "Linux_capture_tests": 8,
        "CPU_MTP_suite": "pass", "lease_identity_tests": 2,
        "flags_registry": "pass", "native_lease_guard_syntax": "pass",
        "component_HC_cases_per_variant": 12,
        "target_precision": "unchanged >=Q4", "draft_head": "unchanged full Q8",
        "new_serving_quality_TPS_or_acceptance_claim": False,
    },
    "candidate_inputs": source,
    "prepared_release_sha256": sha((BASE / "repaired-release.tar.gz").read_bytes()),
    "source_patch_sha256": sha(patch),
}

archive = OUT / "mtp-capture-pressure-evidence.tar.gz"
inputs = list(BASE.glob("*.sh")) + list(BASE.glob("*.ps1")) + list(BASE.glob("*.py"))
inputs += list(BASE.glob("*.glsl"))
inputs += [BASE / p for p in (
    "pressure-evidence.tar.gz", "pressure-iteration-evidence.tar.gz",
    "pressure-close-evidence.tar.gz", "epilogue-confirm-evidence.tar.gz",
    "pressure-close-inspect.json", "pressure-release.json", "capture-cli-source.diff",
    "final-flash-gordon",
)]
for p in BASE.glob("runs/**/*"):
    if p.is_file() and p.suffix in (".json", ".sh", ".ps1", ".py", ".gz"):
        assert p.stat().st_size < 16 * 1024 * 1024, p
        inputs.append(p)
with tarfile.open(archive, "w:gz") as t:
    for p in sorted(set(inputs)):
        t.add(p, arcname=str(p.relative_to(BASE)).replace("\\", "/"))
publication["evidence"] = {"path": archive.name, "sha256": sha(archive.read_bytes()),
                           "bytes": archive.stat().st_size}
(OUT / "mtp-capture-pressure.json").write_text(json.dumps(publication, indent=2) + "\n")
for label, rs in (("half", half), ("row4", rows), ("epilogue_initial", epi),
                  ("epilogue_confirm", confirm)):
    print(label, {n: statistics.median(r[n]["B_over_bracket_medians"] for r in rs)
                  for n in ("1", "4") if n in rs[0]})
print(publication["evidence"])
