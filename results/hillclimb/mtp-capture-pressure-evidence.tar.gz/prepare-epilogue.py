from pathlib import Path

source = Path("shaders/fg_small_hc_up_mix.glsl").read_text()
prefix = source[:source.index("    if(lid<8u){")]
Path(".build/mtp-union-lease/hc-parallel-epilogue.glsl").write_text(prefix+"""    if(lid<8u*TOKENS){
        uint t=lid/8u,index=gl_WorkGroupID.x*8u+(lid&7u);
        float v=0.0;
        [[unroll]]for(uint g=0u;g<4u;g++)
            v=fma(sigmoid(values[(t*4u+g)*8u+(lid&7u)]),normed[(t*4u+g)*pc.hidden+index],v);
        mixed[t*pc.hidden+index]=v*0.25;
    }
    if(gl_WorkGroupID.x==0u&&lid<4u*TOKENS){
        uint t=lid/4u,h=lid&3u;
        float v=0.0;
        for(uint p=0u;p<pc.pieces;p++)v+=partials[(t*pc.pieces+p)*4u+h];
        injection[t*4u+h]=2.0*sigmoid(v*0.25);
    }
}
""")
