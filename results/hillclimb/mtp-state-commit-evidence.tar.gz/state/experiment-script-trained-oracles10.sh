set -eu
cd /home/xander/hc-mtp/diagnose/state
export FG_EXPERT_Q8_WIDE=1 FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3
export FG_ROOF_EXPERT=33024 FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1
export FG_NGRAM_LOCAL_CACHE=1 FG_DECODE_SUBMIT_GROUP=2 FG_SMALL_KERNELS=330
for index in 1 0; do
    first=$((index * 6))
    last=$((first + 5))
    if test "$index" = 0; then
        ready=0
        for attempt in $(seq 1 120); do
            if test "$(stat -c %s ../full-pack/rank-01.fgw 2>/dev/null || true)" = 10536951808; then ready=1; break; fi
            sleep 5
        done
        test "$ready" = 1
        printf '%s  %s\n' 8d7851dd40572c253c201a7f056bde903d19c5ef79d2d2c0618d733386bfb49d ../full-pack/rank-01.fgw | sha256sum -c -
        input=../offline-input
    else
        input=../offline-stage0
    fi
    sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_NGRAM_LOCAL_CACHE,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c "ulimit -l unlimited; exec ./tools/mtp-offline oracle manifest.fgm ../full-pack ../plan.bin $first $last $input ../oracle-stage$index ../offline-input.ng" > "../oracle-stage$index.jsonl" 2> "../oracle-stage$index.log"
    cmp "../offline-stage$index.off" "../oracle-stage$index.off"
    cmp "../offline-stage$index.on" "../oracle-stage$index.on"
    tail -n 3 "../oracle-stage$index.jsonl"
done
cd ..
sha256sum oracle-stage?.off oracle-stage?.on > oracle-frames.sha256
tar -czf trained-oracles.tar.gz oracle-stage?.jsonl oracle-stage?.log oracle-frames.sha256 offline-original.c state/tools/mtp_offline.c offline-original-binaries.sha256 oracle-build.log
sha256sum trained-oracles.tar.gz
