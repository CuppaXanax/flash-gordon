set -eu
cd /home/xander/hc-mtp/diagnose/state
cp tools/mtp_offline.c ../offline-original.c
cp tools/mtp-offline ../mtp-offline-original
cp ../final-binaries.sha256 ../offline-original-binaries.sha256
cp ../mtp_offline.oracle.c tools/mtp_offline.c
touch tools/mtp_offline.c
make -j2 tools/mtp-offline > ../oracle-build.log 2>&1
export FG_EXPERT_Q8_WIDE=1 FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3
export FG_ROOF_EXPERT=33024 FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1
export FG_NGRAM_LOCAL_CACHE=1 FG_DECODE_SUBMIT_GROUP=2 FG_SMALL_KERNELS=330
for index in 2 3 4 5 6 7; do
    first=$((index * 6))
    last=$((first + 5))
    input=../offline-stage$((index - 1))
    sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_NGRAM_LOCAL_CACHE,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c "ulimit -l unlimited; exec ./tools/mtp-offline oracle manifest.fgm ../full-pack ../plan.bin $first $last $input ../oracle-stage$index ../offline-input.ng" > "../oracle-stage$index.jsonl" 2> "../oracle-stage$index.log"
    cmp "../offline-stage$index.off" "../oracle-stage$index.off"
    cmp "../offline-stage$index.on" "../oracle-stage$index.on"
    tail -n 3 "../oracle-stage$index.jsonl"
done
