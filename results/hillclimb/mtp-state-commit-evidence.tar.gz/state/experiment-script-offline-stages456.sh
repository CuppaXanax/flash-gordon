set -eu
cd /home/xander/hc-mtp/diagnose/state
df -B1 . > ../offline-disk-stage4.txt
export FG_EXPERT_Q8_WIDE=1 FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3
export FG_ROOF_EXPERT=33024 FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1
export FG_NGRAM_LOCAL_CACHE=1 FG_DECODE_SUBMIT_GROUP=2 FG_SMALL_KERNELS=330
for index in 4 5 6; do
    first=$((index * 6))
    last=$((first + 5))
    input=../offline-stage$((index - 1))
    sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_NGRAM_LOCAL_CACHE,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c "ulimit -l unlimited; exec ./tools/mtp-offline stage manifest.fgm ../full-pack ../plan.bin $first $last $input ../offline-stage$index ../offline-input.ng" > "../offline-stage$index.jsonl" 2> "../offline-stage$index.log"
    tail -n 2 "../offline-stage$index.jsonl"
done
