set -eu
cd /home/xander/hc-mtp/diagnose/state
tar -xzf ../final-delta.tar.gz
touch src/runtime.c src/runtime_mtp_worker.inc tests/test_mtp_wire.c tools/mtp_tokens.c tools/bench_decode_fusion.c
make -j2 all tests/test_mtp tests/test_mtp_wire tests/test_mtp_native tests/test_mtp_ring tools/mtp-tokens tools/bench-decode-fusion > ../final-build.log 2>&1
{
    ./tests/test_mtp
    ./tests/test_mtp_wire
    ./tests/test_mtp_native
    bash tools/check-flags.sh
} > ../final-host.log 2>&1
for owner in 7 6; do
    for reject in 0 1 2 3; do
        FG_DECODE_MS=1 ./tests/test_mtp_ring 127.0.0.1 127.0.0.1 21960 "$reject" 2 "$owner" > "../final-ring-$owner-$reject.log" 2>&1
    done
done
sudo -n bash -c 'ulimit -l unlimited; exec ./tools/mtp-tokens ../token-pack/manifest.fgm ../token-pack' < ../token-input.bin > ../final-greedy-tokens.jsonl
cmp ../greedy-tokens.jsonl ../final-greedy-tokens.jsonl
if printf '\001' | sudo -n bash -c 'ulimit -l unlimited; exec ./tools/mtp-tokens ../token-pack/manifest.fgm ../token-pack' > ../final-partial-header.log 2>&1; then
    echo "partial tokenizer input unexpectedly accepted" >&2
    exit 1
fi
tail -n 3 ../final-host.log
