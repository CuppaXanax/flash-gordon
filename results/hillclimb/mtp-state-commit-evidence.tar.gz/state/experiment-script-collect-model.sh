set -eu
cd /home/xander/hc-mtp/diagnose
cat offline-result.jsonl
sha256sum state/flash-gordon state/tools/mtp-offline state/tools/bench-decode-fusion state/tools/mtp-tokens state/tests/test_mtp state/tests/test_mtp_ring state/tests/test_mtp_wire state/tests/test_mtp_native src/tools/mtp-native-replay > final-binaries.sha256
find state/vulkan -name '*.spv' -type f -print0 | sort -z | xargs -0 sha256sum > final-shaders.sha256
test "$(wc -l < final-shaders.sha256)" = 320
sha256sum -c governor.sha256
sha256sum offline-stage?.off offline-stage?.on offline-input.off offline-input.on offline-input.ng offline-result.logits offline-result.hc plan.bin full-pack/ngram-source.json > offline-frames.sha256
tar -czf offline-model-evidence.tar.gz offline-stage?.jsonl offline-stage?.log offline-result.jsonl offline-result.log offline-result.logits offline-result.hc offline-prepare.jsonl offline-prepare.log offline-frames.sha256 plan.bin full-pack/ngram-source.json final-binaries.sha256 final-shaders.sha256 final-host.log final-build.log final-ring-*.log final-state-gpu.jsonl final-state-gpu.log final-partial-header.log governor.sha256 offline-disk-recovered.txt offline-disk-stage4.txt native-replay.jsonl native-replay.log
sha256sum offline-model-evidence.tar.gz
