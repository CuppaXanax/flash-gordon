set -eu
cd /home/xander/hc-mtp/diagnose/state
export FG_EXPERT_Q8_WIDE=1 FG_ROOFLINE=2047 FG_ROOF_DENSE=19 FG_ROOF_QSA=3
export FG_ROOF_EXPERT=33024 FG_ROOF_HC=96 FG_ROOF_RECURRENT=3 FG_ROOF_GDN=1
export FG_NGRAM_LOCAL_CACHE=1 FG_DECODE_SUBMIT_GROUP=2 FG_SMALL_KERNELS=330
sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_NGRAM_LOCAL_CACHE,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c 'ulimit -l unlimited; exec ./tools/mtp-offline stage manifest.fgm ../full-pack ../plan.bin 42 47 ../offline-stage6 ../offline-stage7 ../offline-input.ng' > ../offline-stage7.jsonl 2> ../offline-stage7.log
sudo -n --preserve-env=FG_EXPERT_Q8_WIDE,FG_ROOFLINE,FG_ROOF_DENSE,FG_ROOF_QSA,FG_ROOF_EXPERT,FG_ROOF_HC,FG_ROOF_RECURRENT,FG_ROOF_GDN,FG_NGRAM_LOCAL_CACHE,FG_DECODE_SUBMIT_GROUP,FG_SMALL_KERNELS bash -c 'ulimit -l unlimited; exec ./tools/mtp-offline head manifest.fgm ../full-pack ../plan.bin ../offline-stage7 ../offline-result' > ../offline-result.jsonl 2> ../offline-result.log
cd ..
sha256sum state/flash-gordon state/tools/mtp-offline state/tools/bench-decode-fusion state/tools/mtp-tokens state/tests/test_mtp state/tests/test_mtp_ring state/tests/test_mtp_wire state/tests/test_mtp_native src/tools/mtp-native-replay > final-binaries.sha256
find state/vulkan -name '*.spv' -type f -print0 | sort -z | xargs -0 sha256sum > final-shaders.sha256
sha256sum -c governor.sha256
sha256sum offline-stage?.off offline-stage?.on offline-input.off offline-input.on offline-input.ng offline-result.logits offline-result.hc plan.bin full-pack/ngram-source.json > offline-frames.sha256
tar -czf offline-model-evidence.tar.gz offline-stage?.jsonl offline-stage?.log offline-result.jsonl offline-result.log offline-result.logits offline-result.hc offline-prepare.jsonl offline-prepare.log offline-frames.sha256 plan.bin full-pack/ngram-source.json final-binaries.sha256 final-shaders.sha256 final-host.log final-build.log final-ring-*.log final-state-gpu.jsonl final-state-gpu.log final-partial-header.log governor.sha256 offline-disk-recovered.txt offline-disk-stage4.txt native-replay.jsonl native-replay.log
sha256sum offline-model-evidence.tar.gz
cat offline-result.jsonl
