set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'mtp-retain-a038dec-20261016-2103'; bash '/home/xander/hc-mtp/lease.sh' stop-candidate
