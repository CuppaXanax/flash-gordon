set -euo pipefail
test ! -e '/home/xander/hc-mtp'; mkdir -p '/home/xander/hc-mtp'; printf '%s\n' 'mtp-retain-a038dec-20261016-2103' > '/home/xander/hc-mtp/lease.id'
