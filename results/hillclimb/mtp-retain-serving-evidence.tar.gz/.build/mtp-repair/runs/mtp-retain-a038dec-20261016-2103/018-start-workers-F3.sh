set -euo pipefail
test "$(cat '/home/xander/hc-mtp/lease.id')" = 'mtp-retain-a038dec-20261016-2103'; bash '/home/xander/hc-mtp/lease.sh' start-serving F3 3 330 1 3 1 440
