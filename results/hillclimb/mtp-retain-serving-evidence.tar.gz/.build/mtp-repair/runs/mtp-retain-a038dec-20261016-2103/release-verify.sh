#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
root=/home/xander/hc-mtp
operator=/home/xander/flash-gordon-live/20261015-abq-operator
prod=/home/xander/flash-gordon-live/20261016-abq-stack-adaptive/flash-gordon
pack=/home/xander/fg-ring-pack-abliterated-q4-ablate-mix-04
binary_sha=02930a164e38c9c5ee50ae11bf0a746601cc587fdff4e31205da6861e850a6e0
shader_sha=5b7551d49ae10081e29e87aae59d289b1eff7479931d0986425803258d0dc633
manifest_sha=0898fe90f71deb6e9498451bd5fb827a128079e9881f204787b94a933f8e5252
ip="$(hostname -I)"
rank=-1
for last in {42..49}; do
    if [[ " $ip " == *" 192.168.42.$last "* ]]; then rank=$((last-42)); fi
done
[[ "$rank" -ge 0 ]] || { echo "not a production ring owner" >&2; exit 1; }

identity() {
    local pid="$1" executable="$2" manifest="$3"
    [[ "$pid" =~ ^[1-9][0-9]*$ && -d "/proc/$pid" ]] || return 1
    [[ "$(readlink "/proc/$pid/exe")" == "$executable" ]] || return 1
    python3 - "$pid" "$manifest" <<'PY'
import pathlib,sys
args=pathlib.Path('/proc/'+sys.argv[1]+'/cmdline').read_bytes().split(b'\0')
expected=sys.argv[2].encode()
assert any(args[i]==b'--manifest' and args[i+1]==expected for i in range(len(args)-1))
PY
}
stop_candidate() {
    [[ -f "$root/candidate.pid" ]] || return 0
    local pid
    pid="$(cat "$root/candidate.pid")"
    [[ "$pid" =~ ^[1-9][0-9]*$ ]] || return 1
    if [[ ! -d "/proc/$pid" ]]; then rm "$root/candidate.pid"; return 0; fi
    identity "$pid" "$root/release/flash-gordon" "$root/pack/manifest.fgm" || {
        echo "refusing non-owned PID $pid" >&2; return 1;
    }
    kill -TERM "$pid"
    for _ in {1..100}; do
        if [[ ! -e "/proc/$pid/exe" ]]; then rm "$root/candidate.pid"; return 0; fi
        sleep 0.2
    done
    echo "owned candidate did not stop; no forced kill" >&2
    return 1
}
check_hashes() {
    printf '%s  %s\n' "$binary_sha" "$prod" "$manifest_sha" "$pack/manifest.fgm" | sha256sum -c -
    local tree
    tree="$(cd "$(dirname "$prod")"; find vulkan -type f -name '*.spv' -print0 |
        LC_ALL=C sort -z | xargs -0 -r sha256sum | sha256sum | cut -d ' ' -f 1)"
    [[ "$tree" == "$shader_sha" ]]
}
prod_identity() {
    local pid
    pid="$(cat "$operator/rank-$rank.pid")"
    identity "$pid" "$prod" "$pack/manifest.fgm"
    python3 - "$pid" "$rank" <<'PY'
import pathlib,sys
env=dict(x.split(b'=',1) for x in pathlib.Path('/proc/'+sys.argv[1]+'/environ').read_bytes().split(b'\0') if b'=' in x)
args=pathlib.Path('/proc/'+sys.argv[1]+'/cmdline').read_bytes().rstrip(b'\0').split(b'\0')
rank=int(sys.argv[2])
options={b'--manifest':b'/home/xander/fg-ring-pack-abliterated-q4-ablate-mix-04/manifest.fgm'}
if rank==0:
    options.update({b'--model-name':b'Qwen3.8-Flash-Next-Uncensored',b'--host':b'0.0.0.0',
        b'--port':b'8080',b'--context-tokens':b'262144',b'--gpu-index-tokens':b'262144',
        b'--qsa-hot-tokens':b'0',b'--qsa-page-cache-mib':b'700',b'--sessions':b'2'})
else:
    options[b'--rank']=str(rank).encode()
assert args[1]==(b'api' if rank==0 else b'rank')
assert len(args)==2+2*len(options) and dict(zip(args[2::2],args[3::2]))==options
expected={b'FG_SHADER_DIR':b'/home/xander/flash-gordon-live/20261016-abq-stack-adaptive/vulkan',
    b'FG_EXPERT_Q8_WIDE':b'1',b'FG_ROOFLINE':b'2047',b'FG_ROOF_DENSE':b'19',
    b'FG_ROOF_QSA':b'3',b'FG_ROOF_EXPERT':b'33024',b'FG_ROOF_HC':b'96',
    b'FG_ROOF_RECURRENT':b'3',b'FG_ROOF_GDN':b'1',b'FG_NGRAM_LOCAL_CACHE':b'1',
    b'FG_DECODE_SUBMIT_GROUP':b'2'}
if sys.argv[2]=='0': expected[b'FG_RING_TRACE']=b'1'
assert {k:v for k,v in env.items() if k.startswith(b'FG_')}==expected
assert not env.get(b'LD_PRELOAD')
PY
}
check_hashes
prod_identity
for pass in 1 2; do [[ ! -e "$root" ]]; echo "ROOT_ABSENT pass=$pass rank=$rank"; sleep 1; done
[[ -z "$(ss -H -ltn 'sport = :26840')" ]]
python3 - <<'PY'
import pathlib,os
bad=[]
for p in pathlib.Path('/proc').glob('[0-9]*/cmdline'):
 try:
  if p.stat().st_uid==os.getuid() and b'/home/xander/hc-mtp/' in p.read_bytes(): bad.append(str(p))
 except (FileNotFoundError,PermissionError,ProcessLookupError): pass
assert not bad,bad
print('OWNED_PROCESSES_ABSENT')
PY
printf 'RELEASE_VERIFIED rank=%s utc=' "$rank"; date -u +%FT%TZ