import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

out = Path(".build") / "mtp-repair"
run = out / "runs" / "mtp-retain-a038dec-20261016-2103"
results = Path("results") / "hillclimb"
sha = lambda p: hashlib.file_digest(Path(p).open("rb"), "sha256").hexdigest()
read = lambda p: json.loads(Path(p).read_text(encoding="utf-8-sig"))
candidate = "a038dec46287439a2b2f63d725fe13aab815b661"
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip() == candidate
checks = read(run / "release-verified.json")
assert len(checks) == 8 and all(x["ExitCode"] == 0 and
    "RELEASE_VERIFIED" in x["Stdout"] and "ROOT_ABSENT pass=2" in x["Stdout"]
    for x in checks)
report = read(out / "a038dec-live-analysis.json")
assert all(report["outcome"][k] for k in ("complete","productionVerified","scratchRemoved"))
assert not report["outcome"]["finalizationErrors"]
assert report["validation"]["stage_ledgers"] == 775
assert report["validation"]["pass_local_argmax_checks"] == 2167
grant = read(out / "lease-grant-a038dec.json")
cleanup = {}
for path in (out / "head.q8", run / "embedding.fgme"):
    cleanup[str(path)] = dict(bytes=path.stat().st_size, sha256=sha(path))
    if path.name == "head.q8":
        assert cleanup[str(path)]["sha256"] == "2801d79db74bcae38b47fd5051f03136d8ca7715abeba7d92b49ba46c696bc33"
    path.unlink()
(out / "serving-local-weight-cleanup.json").write_text(json.dumps(cleanup,indent=2)+"\n")
report.update(
    tested_candidate=candidate, prepared=read(out/"prepared.json"),
    lease_grant=grant, lease_released_verified="2026-10-16T21:15:32Z",
    release_verification_sha256=sha(run/"release-verified.json"),
    active_lease=False, future_lease_authority="User directly, not sol-abqual",
    head_and_repaired_round_analysis=read(out/"a038dec-head-analysis.json"),
    transport_provenance="Prior 2026-10-16T19:56 lease .48/.49 codec/CRC pair; not remeasured during a038dec lease",
    quality=dict(
        current_n1_q8_mix04_80_forced_frontier_kl=0.051191953,
        current_n1_q8_mix04_80_forced_frontier_top1=0.85,
        current_n1_80_gate_pass=False,
        n4_same_prefix_full_model_qualified=False,
        precision_source_commit="9531f7e4130c582cb52bef1f4e14c7f4cff6ad5a",
        precision_report_sha256=sha(Path(r"D:\looking-glass-labs\flash-gordon\results\hillclimb\FP16_HOPS.md")),
        precision_json_sha256=sha(Path(r"D:\looking-glass-labs\flash-gordon\results\hillclimb\fp16-hops.json")),
        prior_480_reconciliation_reported_by_sibling=dict(
            original_q8_mix04_kl=0.003128577865,top1=0.989583,
            original_q8_stack_kl=0.003084266956,stack_top1=0.9875,
            incremental_mix04_stack_kl=0.000246434840,
            incremental_mix04_stack_top1=0.997917,
            same_as_80_cohort=False,native_prefill_n1_reconciliation_pending=True),
        bitwise_greedy_identity_required=False,promotion=False),
    local_weight_cleanup=cleanup,
    streaming_stop_cancel_passed=True,
    diagnostic_identity=read(run/"F3-greedy-report.json"))
report_path = results / "mtp-retain-serving.json"
report_path.write_text(json.dumps(report,indent=2)+"\n")
source_names = ["docs/MTP.md","docs/MTP_TO_PROD.md",
    "tools/Invoke-MTPServingQualification.ps1","tools/mtp-lease-guard.sh",
    "tools/mtp_live_analyze.py","tools/mtp_diagnose.py","tools/mtp_serving_qualify.py"]
paths = [Path(n) for n in source_names]
paths += [p for p in run.iterdir() if p.is_file() and
          p.suffix in {".json",".log",".gz",".sh",".stdout",".stderr"}]
paths += [out / n for n in ("analyze-extra.py","publish-serving.py",
    "a038dec-live-analysis.json","a038dec-head-analysis.json","a038dec-live-analysis.log",
    "lease-grant-a038dec.json","lease-a038dec-console.log",
    "prepared.json","format-audit.json","release.tar.gz","source.tar.gz",
    "serving-analysis-tests.log","serving-local-weight-cleanup.json")]
paths += [results / "MTP_RETAIN_SERVING.md", report_path,
    Path(".build/mtp-live/runs/mtp-local-n4-20261016-1956/013-measure-n1-n4-transport.json")]
archive_path = results / "mtp-retain-serving-evidence.tar.gz"
assert not archive_path.exists()
with tarfile.open(archive_path,"w:gz") as t:
    for path in sorted(set(paths)):
        assert path.suffix not in {".fgme",".gguf",".fgw",".q8",".fgdv"}
        t.add(path,arcname=str(path),recursive=False)
publication = dict(tested_candidate=candidate,
    binary_sha256=report["prepared"]["binarySha256"],
    report_sha256=sha(report_path),report_md_sha256=sha(results/"MTP_RETAIN_SERVING.md"),
    archive_sha256=sha(archive_path),archive_bytes=archive_path.stat().st_size,
    source_sha256={name:sha(name) for name in source_names},
    released_verified=report["lease_released_verified"],
    release_verification_sha256=sha(run/"release-verified.json"),
    validation=report["validation"],promotion=False)
pub = results / "mtp-retain-serving-publication.json"
pub.write_text(json.dumps(publication,indent=2)+"\n")
canonical = Path(r"D:\looking-glass-labs\flash-gordon\results\hillclimb")
copies={}
for path in (results/"MTP_RETAIN_SERVING.md",report_path,archive_path,pub):
    destination=canonical/path.name
    assert not destination.exists()
    shutil.copyfile(path,destination)
    assert sha(path)==sha(destination)
    copies[path.name]=sha(path)
(out/"canonical-serving-publication.json").write_text(json.dumps(copies,indent=2)+"\n")
print(json.dumps(publication,indent=2))
