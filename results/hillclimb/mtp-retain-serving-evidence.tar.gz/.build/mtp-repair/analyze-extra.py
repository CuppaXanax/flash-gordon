import json
from pathlib import Path
import re
import statistics as st
import sys
import tarfile

sys.path.insert(0, "tools")
from mtp_diagnose import parse_trace

out = Path(".build") / "mtp-repair"
run = out / "runs" / "mtp-retain-a038dec-20261016-2103"
text = (run / "F3-rank-0.log").read_text()
pending, by_request, stages = [], {}, []
for line in text.splitlines():
    if line.startswith("MTP_STAGE "):
        pending.append(len(stages))
        stages.append(dict(re.findall(r"(\w+)=([^\s]+)", line)))
    match = re.search(r"API_TOKEN_HASH id=(\S+)", line)
    if match:
        by_request[match[1]], pending = pending, []
vocab, owners = {}, {}
for rank in range(8):
    with tarfile.open(run / f"evidence-192.168.42.{42+rank}.tar.gz") as t:
        log = t.extractfile(f"serving-F3-rank-{rank}.log").read().decode()
    parse = lambda prefix: [dict(re.findall(r"(\w+)=([^\s]+)", line))
        for line in log.splitlines() if line.startswith(prefix)]
    owners[rank] = parse("MTP_VERIFY_RANK ")
    rows = parse("MTP_VOCAB_STAGE ")
    if rows:
        assert len(rows) == len(stages)
        assert all(x["first"] == y["first"] and int(x["n"]) == int(y["k"])+1
            for x, y in zip(rows, stages))
        vocab[rank] = rows
perf = {p: json.loads((run / f"{p}-perf.json").read_text())["rows"]
        for p in ("A0", "F3", "A1")}
requests, extra = parse_trace(text), {}
for category in ("chat", "code"):
    selected = [x for x in perf["F3"] if x["category"] == category]
    all_ids = [i for x in selected for i in by_request[x["id"]]]
    ids = [i for i in all_ids if stages[i]["k"] == "3"]
    heads = [[float(rows[i]["compute_ms"]) for rows in vocab.values()] for i in ids]
    rounds = [x for row in selected for x in requests[row["id"]]["rounds"]]
    repaired = [x["milliseconds"] for x in rounds if x["consumed"] < x["k"]+1]
    full = [x["milliseconds"] for x in rounds if x["consumed"] == x["k"]+1]
    before = {(x["case"],x["repeat"]):x for x in perf["A0"]}
    after = {(x["case"],x["repeat"]):x for x in perf["A1"]}
    off = [st.mean((before[x["case"],x["repeat"]]["wall_tps"],
                    after[x["case"],x["repeat"]]["wall_tps"])) for x in selected]
    extra[category] = dict(n4_rounds=len(ids), head_ranks=list(vocab),
        head_compute_by_rank_ms={str(rank):st.mean(h[j] for h in heads)
                                for j,rank in enumerate(vocab)},
        head_compute_sum_ms=st.mean(map(sum,heads)),
        head_max_compute_ms=st.mean(map(max,heads)),
        head_scope="Overlapping worker compute sum/max, NOT extra disjoint verify latency",
        owner_all_round_compute_ms=st.mean(sum(float(owners[r][i]["compute_ms"])
                                               for r in range(8)) for i in all_ids),
        n4_stage_means_ms={key:st.mean(float(stages[i][key]) for i in ids)
            for key in ("draft_ms","verify_ms","total_ms")},
        repaired_rounds=len(repaired), repaired_round_mean_ms=st.mean(repaired),
        full_retention_rounds=len(full), full_retention_round_mean_ms=st.mean(full),
        off_wall_tps_median=st.median(off),
        mtp_wall_tps_median=st.median(x["wall_tps"] for x in selected))
(out / "a038dec-head-analysis.json").write_text(json.dumps(extra, indent=2) + "\n")
print(json.dumps(extra, indent=2))
