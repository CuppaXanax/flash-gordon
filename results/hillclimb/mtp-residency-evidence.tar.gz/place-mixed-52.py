import hashlib,json,shutil,subprocess,sys,tarfile
from pathlib import Path
root=Path('/home/xander/hc-mtp'); pack=root/'real-rank7'; manifest=root/'metadata/manifest.fgm'; placer=root/'residency-source/tools/mtp-real-place'
sys.path.insert(0,str(root/'residency-source/tools'))
from mtp_format_audit import load_manifest
m=load_manifest(manifest); assert m['sha256']=='0898fe90f71deb6e9498451bd5fb827a128079e9881f204787b94a933f8e5252'; records={t['name']:t for t in m['records']}; coverage=json.loads((root/'metadata/source-coverage.json').read_text()); required={e['target']['name'] for e in coverage['records'] if not e['same_format']}
archive=root/'rank7-mix04-source.tar.gz'; digest=hashlib.sha256()
with archive.open('rb') as file:
 for chunk in iter(lambda:file.read(8*1024*1024),b''):digest.update(chunk)
assert digest.hexdigest()=='1b3aa70dc7347abdc9f5645b9da06e48987662c3cbf93c48ee68ae3c82c031a2'
proofs=[]
with tarfile.open(archive) as bundle:
 metadata=json.load(bundle.extractfile('tensors.json')); assert metadata['source_sha256']=='e742dbf593f03c5c608de229329755e7cb19138e7b1c4031632eaf49f1acf4d1'
 assert hashlib.sha256(bundle.extractfile('gguf-header.bin').read()).hexdigest()==metadata['header_sha256']; assert hashlib.sha256(bundle.extractfile('dense-mixed-04.json').read()).hexdigest()==metadata['source_json_sha256']; assert len(metadata['records'])==50 and required<={t['name'] for t in metadata['records']}
 for original in metadata['records']:
  record=records[original['name']]; assert (record['type'],record['shape'])==(original['type'],original['shape']); data=bundle.extractfile(original['path']).read(); assert len(data)==original['bytes'] and hashlib.sha256(data).hexdigest()==original['sha256']; raw=pack/'mixed-tensor.raw';raw.write_bytes(data)
  result=subprocess.run([str(placer),str(manifest),record['name'],str(raw),str(pack/f"rank-{record['rank']:02d}.fgw")],check=True,capture_output=True,text=True); proof=json.loads(result.stdout); proof.update(source=original,manifest_sha256=record['sha256']); proofs.append(proof);raw.unlink(); print(record['name'],'SHA exact',flush=True)
public=[json.loads(line) for line in (pack/'public-source.jsonl').read_text().splitlines()]; names={x['tensor'] for x in public}|{x['tensor'] for x in proofs if records[x['tensor']]['rank']==7}; assert len(public)==104 and names=={x['target']['name'] for x in coverage['records']} and len(names)==152
(pack/'mixed-source.json').write_text(json.dumps(dict(metadata=metadata,proofs=proofs,rank7_all152_manifest_sha_exact=True),indent=2)+'\n');shutil.copyfile(manifest,pack/'manifest.fgm')
fixture=root/'place-tests';fixture.mkdir();record=next(e['target'] for e in coverage['records'] if e['target']['layout']==0 and e['target']['type']==0 and e['target']['bytes']<=1024)
try:
 with (pack/'rank-07.fgw').open('rb') as file:file.seek(record['offset']);data=file.read(record['bytes'])
 raw=fixture/'raw.bin';out=fixture/'rank-07.fgw';raw.write_bytes(data);args=[str(placer),str(manifest),record['name'],str(raw),str(out)];subprocess.run(args,check=True,capture_output=True);raw.write_bytes(bytes([data[0]^1])+data[1:]);assert subprocess.run(args,capture_output=True).returncode!=0;raw.write_bytes(data[:-1]);assert subprocess.run(args,capture_output=True).returncode!=0
 (pack/'placer-negative.json').write_text(json.dumps(dict(valid_exact=True,corrupt_rejected=True,truncated_rejected=True))+'\n')
finally:shutil.rmtree(fixture)
print('Complete real rank7:152/152 cooked tensor hashes exact; HC spans exact; corrupt/truncated placement rejected',flush=True)
