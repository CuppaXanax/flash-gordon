import concurrent.futures,hashlib,json,struct,subprocess,sys
from pathlib import Path
sys.path.insert(0,"/home/xander/hc-mtp/residency-source/tools")
from mtp_source import Source
from mtp_format_audit import gguf_header,load_manifest
root=Path("/home/xander/hc-mtp"); target=root/"real-rank7"; manifest=root/"metadata/manifest.fgm"
c=json.loads((root/"metadata/source-coverage.json").read_text()); source=Source(c["repo"],c["revision"]); m=load_manifest(manifest); records={t["name"]:t for t in m["records"]}; found={}
for index in (2,3,4):
 shard=f"UD-Q4_K_XL/Qwen3.8-Flash-Next-UD-Q4_K_XL-{index:05d}-of-00004.gguf"
 for t in gguf_header(source.read_range(shard,0,16*1024*1024))["records"]:
  if t["name"] in ("token_embd.weight","output_hc_norm.weight","output_hc_up.weight","per_layer_token_embd.weight"):found[t["name"]]=dict(t,shard=shard)
assert len(found)==4,found.keys()
chunk=16*1024*1024
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 def download(t,start,size,path):
  digest=hashlib.sha256()
  with path.open("xb") as output:
   for first in range(0,size,4*chunk):
    offsets=range(first,min(first+4*chunk,size),chunk)
    requests=[(start+i,min(chunk,size-i)) for i in offsets]
    for data in pool.map(lambda request:source.read_range(t["shard"],*request),requests):output.write(data);digest.update(data)
  return digest.hexdigest()
 proofs=[]
 for name in ("token_embd.weight","output_hc_norm.weight","output_hc_up.weight"):
  record=records[name];digest=hashlib.sha256()
  with (target/f"rank-{record['rank']:02d}.fgw").open("rb") as file:
   file.seek(record["offset"]);remaining=record["bytes"]
   while remaining:
    data=file.read(min(16*1024*1024,remaining));assert data;digest.update(data);remaining-=len(data)
  assert digest.hexdigest()==record["sha256"]
  proofs.append(dict(tensor=name,bytes=record["bytes"],manifest_tensor_sha_exact=True,manifest_sha256=record["sha256"],source=found[name]))
 begin=273334639;rows=46666897;size=rows*90
 t=found["per_layer_token_embd.weight"];assert t["type"]==20 and t["shape"]==[160,320001536] and begin+rows==320001536
 digest=download(t,t["file_offset"]+begin*90,size,target/"ngram-rank-07.iq4nl")
 proofs.append(dict(tensor="ngram-rank-07.iq4nl",bytes=size,sha256=digest,source=t,row_begin=begin,row_count=rows,manifest_digest_available=False));print("Original pinned ngram span fetched",digest,flush=True)
(target/"auxiliary-source.json").write_text(json.dumps(proofs,indent=2)+"\n")
